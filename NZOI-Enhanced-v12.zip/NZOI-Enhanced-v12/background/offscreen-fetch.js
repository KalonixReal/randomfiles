'use strict';

const PORT_NAME = 'nzoi-classifier-offscreen-fetch';
const HEARTBEAT_MS = 20_000;
let port = null;
let heartbeatTimer = null;
const activeRequests = new Map();
const completedResponses = new Map();
let pdfJsPromise = null;

function send(message) {
  if (!port) return false;
  try { port.postMessage(message); return true; } catch { return false; }
}

function syncHeartbeat() {
  if ((activeRequests.size || completedResponses.size) && !heartbeatTimer) {
    heartbeatTimer = setInterval(() => send({ type:'heartbeat' }), HEARTBEAT_MS);
  } else if (!activeRequests.size && !completedResponses.size && heartbeatTimer) {
    clearInterval(heartbeatTimer);
    heartbeatTimer = null;
  }
}

function readableBody(text, contentType) {
  if (!/text\/html/i.test(String(contentType || '')) || typeof DOMParser !== 'function') return text;
  const doc = new DOMParser().parseFromString(String(text || ''), 'text/html');
  return String(doc.body?.textContent || text || '').replace(/\s+/g, ' ').trim();
}

function parseNZOIHtml(text, pageUrl, mode, problemId='') {
  const doc = new DOMParser().parseFromString(String(text || ''), 'text/html');
  const base = new URL(pageUrl);
  const signIn = /\/accounts\/sign_in/i.test(base.pathname) || !!doc.querySelector('form[action*="sign_in"]');
  const progressFromRow = anchor => {
    const cell = anchor.closest('tr')?.children?.[1];
    const value = String(cell?.textContent || '').trim();
    const percent = value.match(/(\d+(?:\.\d+)?)\s*%/);
    if (percent) return Math.max(0, Math.min(100, Number(percent[1])));
    const ratio = value.match(/(\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)/);
    if (ratio && Number(ratio[2]) > 0) return Math.max(0, Math.min(100, Math.round(Number(ratio[1]) / Number(ratio[2]) * 100)));
    return 0;
  };
  const absolute = href => { try { return new URL(href || '', base).href; } catch { return ''; } };
  const scoreFromElement = element => {
    if (!element) return null;
    for (const node of [element, ...element.querySelectorAll('[class],[id]')]) {
      const classes = `${node.id || ''} ${typeof node.className === 'string' ? node.className : ''}`;
      const match = classes.match(/\bscore_(\d{1,2})x\b/i);
      if (match) return Math.max(0, Math.min(100, Number(match[1]) * 10));
    }
    const value = String(element.innerText || element.textContent || '');
    const percent = value.match(/\b(\d+(?:\.\d+)?)\s*%/);
    if (percent) return Math.max(0, Math.min(100, Number(percent[1])));
    const ratio = value.match(/\b(\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)/);
    if (ratio && Number(ratio[2]) > 0 && Number(ratio[1]) <= Number(ratio[2]) && Number(ratio[2]) <= 1000) {
      return Math.max(0, Math.min(100, Number(ratio[1]) / Number(ratio[2]) * 100));
    }
    if (/\b(?:accepted|fully correct|all tests passed)\b/i.test(value)) return 100;
    return null;
  };

  if (mode === 'discover') {
    const problems = new Map();
    doc.querySelectorAll('a[href*="/problems/"]').forEach(anchor => {
      const href = absolute(anchor.getAttribute('href'));
      const id = href.match(/\/problems\/(\d+)/)?.[1];
      if (!id || !/^\d+$/.test(id)) return;
      const problem = { id, name:String(anchor.textContent || '').trim(), href, progress:progressFromRow(anchor) };
      const old = problems.get(id);
      if (!old || problem.progress > old.progress || (!old.name && problem.name)) problems.set(id, problem);
    });
    const pagination = [];
    doc.querySelectorAll('a[href]').forEach(anchor => {
      const href = anchor.getAttribute('href') || '';
      if (!anchor.matches('[rel="next"],.pagination a,.pager a') && !/[?&]page=\d+/i.test(href)) return;
      const url = absolute(href);
      if (url) pagination.push(url);
    });
    const groups = [];
    const groupsSeen = new Set();
    if (base.pathname === '/' || base.pathname === '') {
      doc.querySelectorAll('a[href*="/groups/"]').forEach(anchor => {
        let url;
        try { url = new URL(anchor.getAttribute('href') || '', base); } catch { return; }
        if (url.origin !== base.origin) return;
        const parts = url.pathname.split('/').filter(Boolean);
        if (parts[0] !== 'groups' || parts.length < 2 || /^(?:new|search|join)$/i.test(parts[1])) return;
        const childRoutes = new Set(['problems','submissions','members','settings','edit','activity','leaderboard','solutions','results']);
        const childIndex = parts.findIndex((part,index)=>index>=2&&childRoutes.has(part.toLowerCase()));
        url.pathname = `/${(childIndex>=0?parts.slice(0,childIndex):parts).join('/')}`;
        url.search = ''; url.hash = '';
        const canonical = url.href.replace(/\/$/,'');
        if (groupsSeen.has(canonical)) return;
        groupsSeen.add(canonical);
        groups.push({ name:String(anchor.textContent||'').trim(), href:canonical });
      });
    }
    return { pageUrl:base.href, signIn, problems:[...problems.values()], pagination:[...new Set(pagination)], groups };
  }

  if (mode === 'question') {
    const statement = doc.querySelector('.problem-description,.problem-statement');
    const textContent = String(statement?.innerText || statement?.textContent || doc.body?.innerText || doc.body?.textContent || '').trim();
    const pdfLinks=[];
    const addPdf=(raw,label='',embedded=false)=>{
      try {
        const url=new URL(raw||'',base);
        if(url.protocol==='http:')url.protocol='https:';
        if(url.origin!=='https://train.nzoi.org.nz'||!/\.pdf(?:[?#]|$)/i.test(url.href))return;
        const eligible=embedded||/\/(?:files?|attachments?|downloads?)\//i.test(url.pathname)||/\b(?:pdf|download|attachment|problem statement)\b/i.test(label);
        if(eligible&&!pdfLinks.includes(url.href)&&pdfLinks.length<4)pdfLinks.push(url.href);
      } catch {}
    };
    doc.querySelectorAll('a[href],iframe[src],embed[src],object[data]').forEach(element=>{
      const tag=String(element.tagName||'').toLowerCase();
      addPdf(element.getAttribute('href')||element.getAttribute('src')||element.getAttribute('data'),
        `${element.textContent||''} ${element.getAttribute('title')||''} ${element.getAttribute('aria-label')||''}`,tag!=='a');
    });
    const pdfPattern=/(?:!?)\[([^\]\n]*)\]\(([^)\s<>"']+\.pdf(?:[?#][^)\s<>"']*)?)\)/gi;
    let pdfMatch;
    while((pdfMatch=pdfPattern.exec(textContent)))addPdf(pdfMatch[2],`${pdfMatch[1]} pdf`,false);
    return { pageUrl:base.href, signIn, title:String(doc.title||''), text:textContent, pdfLinks, sourceType:'html', contentType:'text/html' };
  }

  if (mode === 'submission-list') {
    const entries = new Map();
    const scoped = new RegExp(`/problems/${String(problemId).replace(/[^0-9]/g,'')}(/|$)`).test(base.pathname) ||
      ['problem_id','problem','id'].some(key=>base.searchParams.get(key)===String(problemId));
    doc.querySelectorAll('a[href]').forEach(anchor=>{
      const href=absolute(anchor.getAttribute('href'));
      let id='';
      try { id=new URL(href).pathname.match(/\/submissions?\/(\d+)(?:\/|$)/i)?.[1]||''; } catch { return; }
      if (!id) return;
      const row=anchor.closest('tr')||anchor.parentElement?.parentElement||anchor;
      if (!scoped && ![...row.querySelectorAll('a[href*="/problems/"]')]
        .some(link=>absolute(link.getAttribute('href')).match(/\/problems\/(\d+)/)?.[1]===String(problemId))) return;
      const scoreNode=row.querySelector('#submission_judged,[id*="score"],[class*="score_"]')||row;
      entries.set(id,{id,href,score:scoreFromElement(scoreNode)});
    });
    const pagination=[];
    const listingPath=base.pathname.replace(/\/+$/,'');
    doc.querySelectorAll('a[href]').forEach(anchor=>{
      const href=anchor.getAttribute('href')||'';
      if (anchor.matches('[rel="next"],.pagination a,.pager a')||/[?&]page=\d+/i.test(href)) pagination.push(absolute(href));
    });
    const safePagination=[...new Set(pagination)].filter(value=>{
      try { const url=new URL(value); return url.origin===base.origin&&url.pathname.replace(/\/+$/,'')===listingPath&&/[?&]page=\d+/i.test(url.href); }
      catch { return false; }
    });
    return { pageUrl:base.href, signIn, entries:[...entries.values()], pagination:safePagination };
  }

  if (mode === 'submission-detail') {
    const selectors=['#main-container > .highlight pre','#main-container .highlight pre','.submission-source pre','.submission-source','#source pre','#source','.highlight pre','pre[class*="language-"]'];
    let source='';
    for (const selector of selectors) { source=doc.querySelector(selector)?.textContent||''; if (source.trim()) break; }
    if (!source.trim()) {
      const fallback=[...doc.querySelectorAll('#main-container pre,pre')]
        .filter(node=>!node.closest('table.results,.results,.test-output'))
        .sort((a,b)=>(b.textContent||'').length-(a.textContent||'').length)[0];
      source=fallback?.textContent||'';
    }
    source=source.replace(/\r\n/g,'\n');
    const marked=[...doc.querySelectorAll('select[name*="language"] option:checked,[data-language],.submission-language,#submission_language')]
      .map(node=>node.value||node.getAttribute('data-language')||node.textContent||'').join(' ');
    const metadata=[...doc.querySelectorAll('tr,dl,li,p')].filter(node=>/\blanguage\b/i.test(node.textContent||'')).map(node=>node.textContent||'').join(' ');
    const hint=`${marked} ${metadata}`;
    let language='text';
    if (/\bpython\b|\bpy3\b/i.test(hint)||/^\s*(?:from\s+\w+\s+import|import\s+\w+|def\s+\w+\s*\(|print\s*\(|if\s+__name__\s*==)|\binput\s*\(/m.test(source)) language='python';
    else if (/\bc\s*\+\+|\bg\+\+|\bclang\b/i.test(hint)||/#include\s*[<"]|\busing\s+namespace\s+std|\bint\s+main\s*\(/m.test(source)) language='cpp';
    else if (/\bjava\b/i.test(hint)||/\bpublic\s+class\s+\w+|\bSystem\.out\./m.test(source)) language='java';
    return { pageUrl:base.href, signIn, source, language, score:scoreFromElement(doc.querySelector('#submission_judged,[id*="submission_judged"]')) };
  }
  throw new Error(`Unknown NZOI parse mode: ${mode}`);
}

async function extractPdfText(buffer) {
  if(!pdfJsPromise) pdfJsPromise=import(chrome.runtime.getURL('libs/pdfjs/pdf.min.mjs'))
    .then(pdfjs=>{pdfjs.GlobalWorkerOptions.workerSrc=chrome.runtime.getURL('libs/pdfjs/pdf.worker.min.mjs');return pdfjs;})
    .catch(error=>{pdfJsPromise=null;throw error;});
  const pdfjs=await pdfJsPromise;
  const pdf=await pdfjs.getDocument({data:new Uint8Array(buffer),useWorkerFetch:false,isEvalSupported:false}).promise;
  const pages=[];let used=0;
  for(let pageNumber=1;pageNumber<=Math.min(pdf.numPages,100)&&used<180_000;pageNumber++){
    const page=await pdf.getPage(pageNumber),content=await page.getTextContent();
    const line=content.items.map(item=>String(item.str||'')).join(' ').replace(/\s+/g,' ').trim();
    if(line){pages.push(line.slice(0,Math.max(0,180_000-used)));used+=pages[pages.length-1].length;}
  }
  return pages.join('\n').slice(0,180_000);
}

async function enrichQuestionWithPdfs(parsed) {
  const parts=[];let used=0;
  for(let index=0;index<(parsed.pdfLinks||[]).length&&used<180_000;index++){
    const url=parsed.pdfLinks[index];
    try {
      const response=await fetch(url,{credentials:'include',cache:'no-store'});
      if(!response.ok)throw new Error(`HTTP ${response.status}`);
      const length=Number(response.headers.get('content-length')||0);
      if(length>8_000_000)throw new Error(`PDF too large: ${length} bytes`);
      const bytes=await response.arrayBuffer();
      if(bytes.byteLength>8_000_000)throw new Error(`PDF too large: ${bytes.byteLength} bytes`);
      const remaining=180_000-used;
      const text=(await extractPdfText(bytes)).slice(0,remaining);
      if(text){parts.push(`\n\n[PDF attachment ${index+1}: ${url}]\n${text}`);used+=text.length;}
    } catch(error) { console.warn('[NZOI Enhanced background] Optional PDF skipped:',url,error?.message||error); }
  }
  if(parts.length)parsed.text+=`\n\n=== Attached PDF Text For Classification ===${parts.join('')}`;
  return parsed;
}

function cacheAndSend(result) {
  completedResponses.set(result.requestId, result);
  syncHeartbeat();
  send(result);
}

async function runFetch(message) {
  const requestId = String(message.requestId || '');
  if (!requestId) return;
  if (completedResponses.has(requestId)) {
    send(completedResponses.get(requestId));
    return;
  }
  if (activeRequests.has(requestId)) return;

  const controller = new AbortController();
  const timeoutMs = Math.max(1_000, Number(message.timeoutMs) || 600_000);
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  activeRequests.set(requestId, controller);
  syncHeartbeat();
  try {
    const response = await fetch(String(message.url || ''), {
      ...(message.init || {}),
      signal:controller.signal,
    });
    const contentType=response.headers.get('content-type')||'';
    let text;
    if(message.parseMode==='question'&&(/application\/pdf/i.test(contentType)||/\.pdf(?:[?#]|$)/i.test(response.url||message.url||''))){
      const buffer=await response.arrayBuffer();
      if(buffer.byteLength>8_000_000)throw new Error(`Problem PDF too large: ${buffer.byteLength} bytes`);
      const pdfText=await extractPdfText(buffer);
      text=JSON.stringify({pageUrl:response.url||message.url,signIn:false,title:'',text:`[Problem PDF: ${response.url||message.url}]\n${pdfText}`,pdfLinks:[response.url||message.url],sourceType:'pdf',contentType});
    } else {
      const rawText=await response.text();
      let parsed=message.parseMode?parseNZOIHtml(rawText,response.url||message.url,message.parseMode,message.problemId):null;
      if(message.parseMode==='question'&&parsed&&!parsed.signIn)parsed=await enrichQuestionWithPdfs(parsed);
      text=message.parseMode?JSON.stringify(parsed):readableBody(rawText,contentType);
    }
    cacheAndSend({
      type:'fetch-result',
      requestId,
      response:{
        status:response.status,
        statusText:response.statusText,
        headers:{ 'retry-after':response.headers.get('retry-after') || '' },
        text,
      },
    });
  } catch (error) {
    cacheAndSend({
      type:'fetch-result',
      requestId,
      error:{
        name:String(error?.name || 'Error'),
        message:String(error?.message || error || 'Network request failed'),
        timedOut:controller.signal.aborted,
      },
    });
  } finally {
    clearTimeout(timer);
    activeRequests.delete(requestId);
    syncHeartbeat();
  }
}

function handleMessage(message) {
  if (message?.type === 'fetch') {
    void runFetch(message);
    return;
  }
  if (message?.type === 'cancel') {
    activeRequests.get(String(message.requestId || ''))?.abort();
    return;
  }
  if (message?.type === 'ack') {
    completedResponses.delete(String(message.requestId || ''));
    syncHeartbeat();
  }
}

function connect() {
  try {
    const next = chrome.runtime.connect({ name:PORT_NAME });
    port = next;
    next.onMessage.addListener(handleMessage);
    next.onDisconnect.addListener(() => {
      if (port === next) port = null;
      setTimeout(connect, 1_000);
    });
    next.postMessage({ type:'ready' });
    for (const result of completedResponses.values()) next.postMessage(result);
  } catch {
    port = null;
    setTimeout(connect, 1_000);
  }
}

connect();

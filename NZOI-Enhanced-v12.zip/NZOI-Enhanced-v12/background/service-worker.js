/**
 * NZOI Enhanced — Background Service Worker v12
 */
'use strict';

const LOG = (...a) => console.log('[NZOI Enhanced BG]', ...a);
const ERR = (...a) => console.error('[NZOI Enhanced BG]', ...a);

const store = {
  get:    k  => new Promise(r => chrome.storage.local.get(k, r)),
  set:    d  => new Promise(r => chrome.storage.local.set(d, r)),
  remove: k  => new Promise(r => chrome.storage.local.remove(k, r)),
};
function localStorageKeys() {
  return new Promise(resolve=>{
    if (typeof chrome.storage.local.getKeys==='function') {
      chrome.storage.local.getKeys(keys=>resolve(Array.isArray(keys)?keys:[]));
      return;
    }
    chrome.storage.local.get(null,data=>resolve(Object.keys(data||{})));
  });
}

// ── GitHub Gist ───────────────────────────────────────────────────────────────

const GITHUB_MIN_REQUEST_INTERVAL_MS = 1_100;
const GITHUB_RATE_STATE_KEY = 'nzoiGitHubRateStateV1';
let githubRequestTail = Promise.resolve();
let githubNextRequestAt = 0;

function serializeGithubRequest(task) {
  const run = githubRequestTail.catch(() => {}).then(async () => {
    const saved = (await store.get(GITHUB_RATE_STATE_KEY))[GITHUB_RATE_STATE_KEY] || {};
    githubNextRequestAt = Math.max(githubNextRequestAt, Number(saved.nextRequestAt) || 0);
    const waitMs = githubNextRequestAt - Date.now();
    if (waitMs > 0) await new Promise(resolve => setTimeout(resolve, waitMs));
    githubNextRequestAt = Date.now() + GITHUB_MIN_REQUEST_INTERVAL_MS;
    await store.set({ [GITHUB_RATE_STATE_KEY]: { nextRequestAt:githubNextRequestAt } });
    return task();
  });
  githubRequestTail = run.catch(() => {});
  return run;
}

async function ghFetch(token, method, path, body) {
  if (!token) throw new Error('No GitHub token');
  return serializeGithubRequest(async () => {
    const res = await fetch('https://api.github.com' + path, {
      method,
      headers: {
        'Authorization': 'token ' + token,
        'Content-Type':  'application/json',
        'Accept':        'application/vnd.github.v3+json',
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    const text = await res.text();
    if (!res.ok) {
      const remainingHeader = res.headers?.get?.('x-ratelimit-remaining');
      const resetHeader = res.headers?.get?.('x-ratelimit-reset');
      const retryHeader = res.headers?.get?.('retry-after');
      const remaining = remainingHeader == null ? null : Number(remainingHeader);
      const resetAt = Number(resetHeader) * 1000;
      const message = 'GitHub ' + res.status + ': ' + text.slice(0, 200);
      const rateLimited = res.status === 429 ||
        (res.status === 403 && (remaining === 0 || /rate limit|secondary rate limit|abuse detection/i.test(text)));
      let retryAfterMs = parseRetryAfterMs(retryHeader);
      if (!retryAfterMs && res.status === 403 && remaining === 0 && Number.isFinite(resetAt)) {
        retryAfterMs = Math.max(1_000, resetAt - Date.now() + 1_000);
      }
      if (!retryAfterMs && rateLimited) retryAfterMs = 60_000;
      if (rateLimited && retryAfterMs > 0) {
        githubNextRequestAt = Math.max(githubNextRequestAt, Date.now() + retryAfterMs);
        await store.set({ [GITHUB_RATE_STATE_KEY]: { nextRequestAt:githubNextRequestAt } });
      }
      const error = new Error(message);
      error.status = res.status;
      error.retryAfterMs = retryAfterMs;
      error.retryable = rateLimited;
      throw error;
    }
    return JSON.parse(text);
  });
}

async function getOrCreateGist(token) {
  const { gistId } = await store.get(['gistId']);
  if (gistId) return gistId;
  const data = await ghFetch(token, 'POST', '/gists', {
    description: 'NZOI Enhanced Code Storage',
    public: false,
    files: { 'init.txt': { content: 'NZOI Enhanced' } },
  });
  await store.set({ gistId: data.id });
  return data.id;
}

const gistFilesInFlight = new Map();
async function fetchGistFiles(token) {
  const { gistId, gistCache, gistCacheTime } = await store.get(['gistId', 'gistCache', 'gistCacheTime']);
  if (!gistId) return {};
  if (gistCache && Date.now() - (gistCacheTime || 0) < 30_000) return gistCache;
  if (gistFilesInFlight.has(gistId)) return gistFilesInFlight.get(gistId);
  const pending=ghFetch(token, 'GET', '/gists/' + gistId).then(async data=>{
    const files=data.files || {};
    await store.set({ gistCache:files, gistCacheTime:Date.now() });
    return files;
  }).finally(()=>gistFilesInFlight.delete(gistId));
  gistFilesInFlight.set(gistId,pending);
  return pending;
}

async function saveFileToGist(token, filename, content) {
  const gistId = await getOrCreateGist(token);
  await ghFetch(token, 'PATCH', '/gists/' + gistId, { files: { [filename]: { content: content || ' ' } } });
  await store.remove(['gistCache', 'gistCacheTime']);
}

async function deleteFileFromGist(token, filename) {
  const { gistId } = await store.get(['gistId']);
  if (!gistId) return;
  await ghFetch(token, 'PATCH', '/gists/' + gistId, { files: { [filename]: null } });
  await store.remove(['gistCache', 'gistCacheTime']);
}

async function deleteGeneratedHighestAnswerJson(token, problemId) {
  const id = String(problemId || '').trim();
  if (!/^\d+$/.test(id)) throw new Error('Invalid problem ID for generated answer cleanup');
  await deleteFileFromGist(token, `NZOI_${id}__highest-answer.json`);
}

async function testGistToken(token) {
  const res = await fetch('https://api.github.com/user', {
    headers: { 'Authorization': 'token ' + token, 'Accept': 'application/vnd.github.v3+json' },
  });
  if (!res.ok) throw new Error('Invalid token (HTTP ' + res.status + ')');
  const user = await res.json();
  const { gistId } = await store.get(['gistId']);
  let fileCount = 0;
  if (gistId) {
    try { const g = await ghFetch(token, 'GET', '/gists/' + gistId); fileCount = Object.keys(g.files || {}).length; } catch {}
  }
  return { login: user.login, gistId: gistId || null, fileCount };
}

async function listGists(token) {
  const gists = await ghFetch(token, 'GET', '/gists?per_page=50');
  return gists.map(g => ({
    id:          g.id,
    description: g.description || '(no description)',
    fileCount:   Object.keys(g.files).length,
    files:       Object.keys(g.files).slice(0, 6).join(', '),
    updatedAt:   g.updated_at,
  }));
}

// ── Classification Gist sync ──────────────────────────────────────────────────

const CLASSIFICATIONS_FILE = 'nzoi_classifications.json';
const QUESTIONS_FILE = 'questions.txt';

let classificationGistChain=Promise.resolve();
function withClassificationGistLock(task) {
  const result=classificationGistChain.then(task,task);
  classificationGistChain=result.catch(()=>{});
  return result;
}
async function writeClassificationsToGist(token, data) {
  const gistId = await getOrCreateGist(token);
  await ghFetch(token, 'PATCH', '/gists/' + gistId, {
    files: { [CLASSIFICATIONS_FILE]: { content: JSON.stringify(data, null, 2) } },
  });
  await store.remove(['gistCache', 'gistCacheTime']);
}
function saveClassificationsToGist(token, data) {
  return withClassificationGistLock(()=>writeClassificationsToGist(token,data));
}

function classificationQualityForGist(value) {
  if (!Array.isArray(value?.tags) || !value.tags.length || typeof value.rating!=='number') return 0;
  if (value.classifiedBy==='manual') return 2;
  return value.classifiedBy && value.classifiedBy!=='fallback' ? 1 : 0;
}
async function mergeClassificationRecordsLocked(token, incoming) {
  const existing=await loadClassificationsFromGist(token), merged={...existing}, pulledDown={};
  let changed=false;
  for (const [key,value] of Object.entries(incoming || {})) {
    if (!/^nztags_\d+$/.test(key)) continue;
    const current=existing[key];
    const incomingValid=Array.isArray(value?.tags)&&value.tags.length>0&&typeof value.rating==='number';
    const currentValid=Array.isArray(current?.tags)&&current.tags.length>0&&typeof current.rating==='number';
    const incomingQuality=classificationQualityForGist(value), currentQuality=classificationQualityForGist(current);
    const better=incomingValid&&(!currentValid||incomingQuality>currentQuality||
      (incomingQuality===currentQuality&&(value.tags?.length||0)>=(current.tags?.length||0)));
    if (better) {
      if (JSON.stringify(current)!==JSON.stringify(value)) { merged[key]=value; changed=true; }
    } else if (current && JSON.stringify(current)!==JSON.stringify(value)) pulledDown[key]=current;
  }
  if (changed) await writeClassificationsToGist(token,merged);
  return {pulledDown,changed,total:Object.keys(merged).length};
}
function mergeClassificationRecordsToGist(token, incoming) {
  return withClassificationGistLock(()=>mergeClassificationRecordsLocked(token,incoming));
}

async function loadClassificationsFromGist(token) {
  const files = await fetchGistFiles(token);
  const f = files[CLASSIFICATIONS_FILE];
  if (!f) return {};
  const text = f.truncated ? await fetch(f.raw_url).then(r => r.text()) : f.content;
  try {
    const parsed=JSON.parse(text);
    if (!parsed || typeof parsed!=='object' || Array.isArray(parsed)) throw new Error('classification data is not an object');
    return parsed;
  } catch (error) {
    throw new Error('Existing classification file is not valid JSON; leaving it unchanged ('+error.message+')');
  }
}

function emptyQuestionArchive() {
  return { format: 'nzoi-questions-v6', updatedAt: null, questions: {} };
}

function normalizeQuestionArchive(value) {
  const archive = emptyQuestionArchive();
  if (!value || typeof value !== 'object') return archive;
  const source = value.questions && typeof value.questions === 'object'
    ? value.questions
    : value;
  for (const [key, question] of Object.entries(source)) {
    if (!question || typeof question !== 'object') continue;
    const id = String(question.id || key || '').trim();
    if (!/^\d+$/.test(id)) continue;
    archive.questions[id] = { ...question, id };
  }
  archive.updatedAt = typeof value.updatedAt === 'string' ? value.updatedAt : null;
  return archive;
}

async function readGistFileText(token, file) {
  if (!file) return '';
  if (!file.truncated) return file.content || '';
  const res = await fetch(file.raw_url, {
    headers: { 'Authorization': 'token ' + token, 'Accept': 'application/vnd.github.raw' },
  });
  if (!res.ok) throw new Error('GitHub raw file ' + res.status);
  return res.text();
}

async function loadQuestionsFromGist(token) {
  const files = await fetchGistFiles(token);
  const file = files[QUESTIONS_FILE];
  if (!file) return emptyQuestionArchive();
  try {
    return normalizeQuestionArchive(JSON.parse(await readGistFileText(token, file)));
  } catch (e) {
    LOG('Could not parse existing questions.txt; leaving it untouched:', e.message);
    throw new Error('Existing questions.txt is not valid NZOI question archive JSON');
  }
}

// Serialise archive merges so parallel content-script messages cannot overwrite
// one another with stale reads. Existing IDs are deliberately preserved: this
// file is an append/backfill archive, not a reflection of classification edits.
let questionMergeChain = Promise.resolve();

function comparableQuestion(value) {
  return {
    parserVersion: Number(value?.parserVersion || 0),
    title: value?.title || '',
    url: value?.url || '',
    resolvedUrl: value?.resolvedUrl || '',
    group: value?.group || '',
    progress: Number.isFinite(value?.progress) ? value.progress : null,
    sourceType: value?.sourceType || '',
    contentType: value?.contentType || '',
    pdfLinks: Array.isArray(value?.pdfLinks) ? value.pdfLinks : [],
    fetchError: value?.fetchError || '',
    text: value?.text || '',
    extractionMode: value?.extractionMode || '',
  };
}

function mergeQuestionsToGist(token, incoming) {
  const run = async () => {
    const archive = await loadQuestionsFromGist(token);
    let added = 0;
    let updated = 0;
    for (const question of Array.isArray(incoming) ? incoming : []) {
      const id = String(question?.id || '').trim();
      if (!/^\d+$/.test(id)) continue;
      const existing = archive.questions[id];
      const incomingVersion = Number(question.parserVersion || 0);
      const existingVersion = Number(existing?.parserVersion || 0);
      if (existing && incomingVersion < existingVersion) continue;
      if (existing && incomingVersion === existingVersion) {
        if (JSON.stringify(comparableQuestion(existing)) === JSON.stringify(comparableQuestion(question))) continue;
      }
      archive.questions[id] = { ...question, id };
      if (existing) updated++;
      else added++;
    }
    if (!added && !updated) return { added: 0, updated: 0, total: Object.keys(archive.questions).length };
    archive.format = 'nzoi-questions-v6';
    archive.updatedAt = new Date().toISOString();
    const gistId = await getOrCreateGist(token);
    await ghFetch(token, 'PATCH', '/gists/' + gistId, {
      files: { [QUESTIONS_FILE]: { content: JSON.stringify(archive, null, 2) } },
    });
    await store.remove(['gistCache', 'gistCacheTime']);
    return { added, updated, total: Object.keys(archive.questions).length };
  };
  const result = questionMergeChain.then(run, run);
  questionMergeChain = result.catch(() => {});
  return result;
}

// ── AI ────────────────────────────────────────────────────────────────────────

// One extension-wide lane covers every tab and the popup. This is deliberately
// in the service worker (rather than only in dashboard.js), so two open NZOI
// tabs cannot accidentally issue concurrent provider requests.
let aiRequestChain = Promise.resolve();
const AI_PACING_KEY = 'nzoiAIProviderPacingV1';
const GOOGLE_ONLY_MIGRATION_KEY = 'nzoiGoogleOnlyClassifierMigrationV2';
const GOOGLE_FREE_CLASSIFIER_MODEL_IDS = new Set([
  'gemini-3.8-flash',
  'gemini-3.7-flash',
  'gemini-3.6-flash',
  'gemini-3.5-flash',
  'gemini-3.5-flash-lite',
  'gemini-3.1-flash-lite',
]);
const GOOGLE_DEFAULT_CLASSIFIER_MODELS = ['gemini-3.8-flash','gemini-3.7-flash'];
// Classification runs in durable batches, so a modest spacing avoids bursty
// free-tier traffic without making a full scan needlessly sluggish.
const AI_PROVIDER_MIN_INTERVAL_MS = { google:4_000 };
function providerPacingState(saved, provider) {
  const current=saved?.[provider];
  if (current && typeof current==='object') return {
    nextAt:Number(current.nextAt)||0,
    cooldownUntil:Number(current.cooldownUntil)||0,
    modelCooldowns:current.modelCooldowns&&typeof current.modelCooldowns==='object'?current.modelCooldowns:{},
  };
  // Read the numeric format written by earlier builds.
  return { nextAt:Number(current)||0, cooldownUntil:0, modelCooldowns:{} };
}
async function waitForProviderSlot(provider, model='') {
  const interval = AI_PROVIDER_MIN_INTERVAL_MS[provider] || 0;
  if (!interval) return;
  const saved = (await store.get(AI_PACING_KEY))[AI_PACING_KEY] || {};
  const now = Date.now();
  const state=providerPacingState(saved,provider);
  const modelCooldown=Number(state.modelCooldowns[model])||0;
  const nextAt = Math.max(state.nextAt,state.cooldownUntil,modelCooldown,now);
  const waitMs=nextAt-now;
  if (waitMs > 0) await new Promise(resolve => setTimeout(resolve, waitMs));
  const sentAt=Date.now();
  await store.set({ [AI_PACING_KEY]: { ...saved, [provider]:{
    nextAt:Math.max(nextAt,sentAt)+interval,
    cooldownUntil:state.cooldownUntil,
    modelCooldowns:state.modelCooldowns,
  } } });
}
async function deferProviderAfterRateLimit(provider, error, model='') {
  if (!provider || Number(error?.status)!==429) return;
  const retryAfterMs=Math.max(0,Number(error?.retryAfterMs)||0);
  if (!retryAfterMs) return;
  const saved=(await store.get(AI_PACING_KEY))[AI_PACING_KEY] || {};
  const state=providerPacingState(saved,provider);
  if (error?.modelScopedRateLimit && model) {
    const modelCooldowns={...state.modelCooldowns,[model]:Math.max(Number(state.modelCooldowns[model])||0,Date.now()+retryAfterMs)};
    await store.set({[AI_PACING_KEY]:{...saved,[provider]:{
      nextAt:state.nextAt,
      cooldownUntil:state.cooldownUntil,
      modelCooldowns,
    }}});
    return;
  }
  const cooldownUntil=Math.max(state.cooldownUntil,Date.now()+retryAfterMs);
  await store.set({ [AI_PACING_KEY]: { ...saved, [provider]:{
    nextAt:Math.max(state.nextAt,cooldownUntil),
    cooldownUntil,
    modelCooldowns:state.modelCooldowns,
  } } });
}
function serializeAIRequest(task, provider='', model='') {
  const run = aiRequestChain.catch(() => {}).then(async () => {
    await waitForProviderSlot(provider,model);
    try {
      return await task();
    } catch (error) {
      await deferProviderAfterRateLimit(provider,error,model);
      throw error;
    }
  });
  aiRequestChain = run.catch(() => {});
  return run;
}

let googleOnlyMigrationPromise=null;
function migrateGoogleOnlySettings() {
  if (googleOnlyMigrationPromise) return googleOnlyMigrationPromise;
  googleOnlyMigrationPromise=(async()=>{
    const keys=[GOOGLE_ONLY_MIGRATION_KEY,'nzoiGoogleOnlyClassifierMigrationV1','classifierPromptTemplate','mistralTier1PromptTemplate',AI_PACING_KEY];
    const saved=await store.get(keys);
    if (saved[GOOGLE_ONLY_MIGRATION_KEY]) return;
    // Preserve a user's shared prompt, migrating the old provider-specific
    // prompt only when no shared prompt has been saved yet.
    if (!saved.classifierPromptTemplate && typeof saved.mistralTier1PromptTemplate==='string' && saved.mistralTier1PromptTemplate.trim()) {
      await store.set({classifierPromptTemplate:saved.mistralTier1PromptTemplate});
    }
    const pacing=saved[AI_PACING_KEY];
    if (pacing && typeof pacing==='object' && (Object.hasOwn(pacing,'mistral')||Object.hasOwn(pacing,'groq'))) {
      const remainingPacing={...pacing};
      delete remainingPacing.mistral;
      delete remainingPacing.groq;
      await store.set({[AI_PACING_KEY]:remainingPacing});
    }
    await store.remove(['mistralKeys','mistralKey','mistralModels','mistralModel','mistralTier1PromptTemplate',
      'groqKeys','groqKey','groqModels','groqModel','classifierConfidenceThreshold','nzoiGoogleOnlyClassifierMigrationV1']);
    await store.set({[GOOGLE_ONLY_MIGRATION_KEY]:true});
  })().finally(()=>{googleOnlyMigrationPromise=null;});
  return googleOnlyMigrationPromise;
}

function parseRetryAfterMs(value) {
  if (!value) return 0;
  const seconds = Number(value);
  if (Number.isFinite(seconds)) return Math.max(0, Math.ceil(seconds * 1000));
  const date = Date.parse(value);
  return Number.isFinite(date) ? Math.max(0, date - Date.now()) : 0;
}

function googleRetryDelayMs(text) {
  try {
    const data = JSON.parse(text);
    const details = data?.error?.details || [];
    const retry = details.find(item => /RetryInfo$/i.test(String(item?.['@type'] || '')))?.retryDelay;
    const match = String(retry || '').match(/^(\d+(?:\.\d+)?)s$/);
    return match ? Math.ceil(Number(match[1]) * 1000) : 0;
  } catch {
    return 0;
  }
}
function googleDailyRpdQuota(text) {
  try {
    const details=JSON.parse(text)?.error?.details || [];
    return details.some(detail=>/QuotaFailure$/i.test(String(detail?.['@type']||'')) &&
      (detail.violations||[]).some(violation=>{
        const quotaId=String(violation?.quotaId||'');
        const quotaMetric=String(violation?.quotaMetric||violation?.metric||'');
        const description=String(violation?.description||'');
        const quotaIdentity=`${quotaId} ${quotaMetric} ${description}`;
        return /per[\s_-]*day/i.test(quotaIdentity) || /daily/i.test(quotaIdentity) || /\bRPD\b/i.test(quotaIdentity);
      }));
  } catch {
    return false;
  }
}
function pacificParts(timestamp) {
  const fields=new Intl.DateTimeFormat('en-US',{
    timeZone:'America/Los_Angeles',year:'numeric',month:'2-digit',day:'2-digit',
    hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23',
  }).formatToParts(new Date(timestamp));
  const values=Object.fromEntries(fields.filter(part=>part.type!=='literal').map(part=>[part.type,Number(part.value)]));
  return {year:values.year,month:values.month,day:values.day,hour:values.hour===24?0:values.hour,minute:values.minute,second:values.second};
}
function nextPacificMidnightMs(now=Date.now()) {
  const local=pacificParts(now);
  const targetDate=new Date(Date.UTC(local.year,local.month-1,local.day+1));
  const targetLocal=Date.UTC(targetDate.getUTCFullYear(),targetDate.getUTCMonth(),targetDate.getUTCDate(),0,0,0);
  // Solve local midnight as an epoch timestamp. Re-evaluating the UTC offset
  // handles Pacific daylight-saving transitions without assuming a fixed offset.
  let candidate=targetLocal;
  for (let attempt=0;attempt<4;attempt++) {
    const atCandidate=pacificParts(candidate);
    const representedLocal=Date.UTC(atCandidate.year,atCandidate.month-1,atCandidate.day,atCandidate.hour,atCandidate.minute,atCandidate.second);
    const adjusted=candidate+(targetLocal-representedLocal);
    if (Math.abs(adjusted-candidate)<1_000) { candidate=adjusted; break; }
    candidate=adjusted;
  }
  return candidate>now?candidate:now+1_000;
}
function googleRetryAfterMs(text, retryAfterHeader='') {
  const retryAfterMs=parseRetryAfterMs(retryAfterHeader);
  const retryInfoMs=googleRetryDelayMs(text);
  if (googleDailyRpdQuota(text)) {
    // Daily requests quotas reset at Pacific midnight. Keep the queue asleep
    // until that reset even if a short per-minute RetryInfo is also present.
    return Math.max(retryAfterMs,retryInfoMs,nextPacificMidnightMs()-Date.now());
  }
  return Math.max(retryAfterMs,retryInfoMs);
}
function googleModelScopedRateLimit(text) {
  try {
    const details=JSON.parse(text)?.error?.details || [];
    return details.some(detail=>/QuotaFailure$/i.test(String(detail?.['@type']||'')) &&
      (detail.violations||[]).some(violation=>{
        const dimensions=violation?.quotaDimensions || {};
        const quotaId=String(violation?.quotaId||'');
        const description=String(violation?.description||'');
        return Object.keys(dimensions).some(key=>/model/i.test(key)) ||
          /per[_\s-]*model/i.test(quotaId) || /per model|model-specific/i.test(description);
      }));
  } catch {
    return false;
  }
}

const CLASSIFIER_REQUEST_TIMEOUT_MS = 10 * 60_000;
const CLASSIFIER_OFFSCREEN_PATH = 'background/offscreen-fetch.html';
const CLASSIFIER_OFFSCREEN_CLOSE_ALARM = 'nzoi-classifier-offscreen-close-v1';
let classifierOffscreenPort = null;
let classifierOffscreenReady = false;
let classifierOffscreenCreating = null;
const classifierOffscreenReadyWaiters = new Set();
const classifierOffscreenRequests = new Map();

function waitForClassifierOffscreenPort(timeoutMs=15_000) {
  if (classifierOffscreenPort && classifierOffscreenReady) return Promise.resolve(classifierOffscreenPort);
  return new Promise((resolve,reject)=>{
    const waiter=()=>{clearTimeout(timer); classifierOffscreenReadyWaiters.delete(waiter); resolve(classifierOffscreenPort);};
    const timer=setTimeout(()=>{
      classifierOffscreenReadyWaiters.delete(waiter);
      reject(new Error('The hidden Gemini request document did not connect in time.'));
    },timeoutMs);
    classifierOffscreenReadyWaiters.add(waiter);
  });
}

async function classifierOffscreenDocumentExists() {
  const url=chrome.runtime.getURL(CLASSIFIER_OFFSCREEN_PATH);
  if (typeof chrome.runtime.getContexts==='function') {
    const contexts=await chrome.runtime.getContexts({contextTypes:['OFFSCREEN_DOCUMENT'],documentUrls:[url]});
    return contexts.length>0;
  }
  if (typeof self.clients?.matchAll==='function') {
    const clients=await self.clients.matchAll({includeUncontrolled:true,type:'window'});
    return clients.some(client=>client.url===url);
  }
  return false;
}

async function ensureClassifierOffscreen() {
  if (!chrome.offscreen?.createDocument) throw new Error('Long Gemini requests require Chrome 109 or newer with Offscreen Documents enabled.');
  if (!classifierOffscreenCreating) {
    classifierOffscreenCreating=(async()=>{
      if (!await classifierOffscreenDocumentExists()) {
        await chrome.offscreen.createDocument({
          url:CLASSIFIER_OFFSCREEN_PATH,
          reasons:['DOM_PARSER'],
          justification:'Complete long-running Gemini classification requests while the dashboard is closed and parse readable diagnostics from HTML error responses.',
        });
      }
    })().finally(()=>{classifierOffscreenCreating=null;});
  }
  await classifierOffscreenCreating;
  return waitForClassifierOffscreenPort();
}

function handleClassifierOffscreenMessage(port,message) {
  if (message?.type==='ready') {
    classifierOffscreenReady=true;
    for (const waiter of [...classifierOffscreenReadyWaiters]) waiter();
    return;
  }
  if (message?.type==='heartbeat') return;
  if (message?.type!=='fetch-result') return;
  const requestId=String(message.requestId||'');
  const pending=classifierOffscreenRequests.get(requestId);
  try { port.postMessage({type:'ack',requestId}); } catch {}
  if (!pending) {
    if (!classifierOffscreenRequests.size) chrome.alarms.create(CLASSIFIER_OFFSCREEN_CLOSE_ALARM,{delayInMinutes:1});
    return;
  }
  classifierOffscreenRequests.delete(requestId);
  clearTimeout(pending.timer);
  if (message.error) {
    const error=new Error(String(message.error.message||'Gemini request failed in the hidden document.'));
    error.name=message.error.timedOut?'AbortError':String(message.error.name||'Error');
    pending.reject(error);
  } else {
    pending.resolve(message.response);
  }
  if (!classifierOffscreenRequests.size) {
  chrome.alarms.create(CLASSIFIER_OFFSCREEN_CLOSE_ALARM,{delayInMinutes:1});
  }
}

chrome.runtime.onConnect.addListener(port=>{
  if (port.name!=='nzoi-classifier-offscreen-fetch') return;
  if (!String(port.sender?.url||'').startsWith(chrome.runtime.getURL(CLASSIFIER_OFFSCREEN_PATH))) {
    port.disconnect();
    return;
  }
  classifierOffscreenPort=port;
  classifierOffscreenReady=false;
  port.onMessage.addListener(message=>handleClassifierOffscreenMessage(port,message));
  port.onDisconnect.addListener(()=>{
    if (classifierOffscreenPort===port) classifierOffscreenPort=null;
    classifierOffscreenReady=false;
  });
});

async function fetchClassifierOffscreen(url,init,label,timeoutMs,parseMode='',problemId='') {
  const port=await ensureClassifierOffscreen();
  chrome.alarms.clear(CLASSIFIER_OFFSCREEN_CLOSE_ALARM);
  const requestId=`${Date.now().toString(36)}-${Math.random().toString(36).slice(2,10)}`;
  return new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>{
      classifierOffscreenRequests.delete(requestId);
      try { port.postMessage({type:'cancel',requestId}); } catch {}
      const error=new Error(`${label} timed out after ${Math.round(timeoutMs/1000)} seconds`);
      error.name='AbortError'; error.retryable=true;
      reject(error);
      if (!classifierOffscreenRequests.size) chrome.alarms.create(CLASSIFIER_OFFSCREEN_CLOSE_ALARM,{delayInMinutes:1});
    },timeoutMs);
    classifierOffscreenRequests.set(requestId,{resolve,reject,timer});
    try {
      port.postMessage({type:'fetch',requestId,url,init,timeoutMs,parseMode,problemId});
    } catch (error) {
      clearTimeout(timer);
      classifierOffscreenRequests.delete(requestId);
      if (!classifierOffscreenRequests.size) chrome.alarms.create(CLASSIFIER_OFFSCREEN_CLOSE_ALARM,{delayInMinutes:1});
      reject(error);
    }
  });
}

async function fetchAIText(url, init, label, timeoutMs=25_000, useOffscreen=false, offscreenOptions={}) {
  if (useOffscreen) {
    try {
      const response=await fetchClassifierOffscreen(url,init,label,timeoutMs,offscreenOptions.parseMode||'',offscreenOptions.problemId||'');
      const text=String(response?.text||'');
      const res=new Response(text,{status:Number(response?.status)||200,statusText:String(response?.statusText||''),headers:response?.headers||{}});
      return {res,text};
    } catch (cause) {
      const timedOut=cause?.name==='AbortError';
      const error=new Error(timedOut
        ? (cause.message||`${label} timed out after ${Math.round(timeoutMs/1000)} seconds`)
        : `${label} network error: ${cause?.message||cause}`);
      error.retryable=true; error.cause=cause;
      throw error;
    }
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...init, signal:controller.signal });
    return { res, text:await res.text() };
  } catch (cause) {
    const timedOut = cause?.name === 'AbortError';
    const error = new Error(timedOut
      ? `${label} timed out after ${Math.round(timeoutMs / 1000)} seconds`
      : `${label} network error: ${cause?.message || cause}`);
    error.retryable = true;
    error.cause = cause;
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function fetchNZOIParsedPage(url,parseMode,problemId='') {
  const {res,text}=await fetchAIText(url,{
    method:'GET',credentials:'include',cache:'no-store',
    headers:{'Accept':'text/html,application/xhtml+xml'},
  },'NZOI background page',25_000,true,{parseMode,problemId});
  if (!res.ok) {
    const error=new Error(`NZOI page request failed with HTTP ${res.status}`);
    error.status=res.status;
    error.retryable=res.status===429||res.status>=500;
    const retryAfter=String(res.headers.get('retry-after')||'');
    error.retryAfterMs=Number(retryAfter)*1000||Math.max(0,Date.parse(retryAfter)-Date.now())||0;
    throw error;
  }
  let parsed;
  try { parsed=JSON.parse(text); }
  catch { throw new Error('NZOI background parser returned invalid page data.'); }
  if (parsed.signIn) {
    const error=new Error('NZOI session is no longer available. Sign in again and reopen the dashboard.');
    error.code='nzoI_session_expired';
    error.retryable=true;
    throw error;
  }
  return parsed;
}

async function fetchProviderJson(url, apiKey, label, extraHeaders = {}) {
  const { res, text } = await fetchAIText(url, {
    method: 'GET',
    headers: {
      ...(apiKey ? { 'Authorization': 'Bearer ' + apiKey } : {}),
      'Accept': 'application/json',
      ...extraHeaders,
    },
  }, label);
  if (!res.ok) {
    const retryAfter = res.headers.get('retry-after');
    const isGoogle=label.startsWith('Google');
    const dailyQuotaReset=res.status===429 && isGoogle && googleDailyRpdQuota(text);
    const retryAfterMs = isGoogle ? googleRetryAfterMs(text,retryAfter) : parseRetryAfterMs(retryAfter);
    const retryHint = retryAfter ? ` [retry-after: ${retryAfter}]` : '';
    const err = new Error(label + ' ' + res.status + retryHint + ': ' + text.slice(0, 300));
    err.status = res.status;
    err.retryAfterMs = retryAfterMs;
    err.dailyQuotaReset=dailyQuotaReset;
    err.retryable = res.status === 429 || res.status >= 500;
    throw err;
  }
  try {
    return JSON.parse(text);
  } catch {
    throw new Error(label + ' returned non-JSON response: ' + text.slice(0, 120));
  }
}

function normalizeModelList(models) {
  const seen = new Set();
  return models
    .map(model => {
      const id = String(model?.id || model?.name || '').replace(/^models\//, '').trim();
      if (!id || seen.has(id)) return null;
      seen.add(id);
      return {
        id,
        name: String(model?.displayName || model?.name || model?.id || id).replace(/^models\//, ''),
        contextWindowTokens: Number(model?.inputTokenLimit || model?.maxInputTokens || model?.context_length || model?.max_context_length || 0) || undefined,
        outputWindowTokens: Number(model?.outputTokenLimit || model?.maxOutputTokens || 0) || undefined,
        reasoning: model?.reasoning === true || model?.thinking === true || undefined,
      };
    })
    .filter(Boolean)
    .sort((a, b) => a.id.localeCompare(b.id));
}

function isTextChatModel(model) {
  const id = String(model?.id || model?.name || '').replace(/^models\//, '').toLowerCase();
  return !!id && !/(?:embedding|embed-|moderation|transcri|speech|(?:^|-)tts(?:-|$)|(?:^|-)live(?:-|$)|(?:^|-)image(?:-|$)|imagen|veo|lyria|aqa|(?:^|-)ocr(?:-|$)|rerank)/i.test(id);
}

function canonicalAIModel(provider, value) {
  return String(value || '').replace(/^models\//, '').trim();
}

async function listAIModels(provider, apiKey) {
  if (!apiKey) throw new Error('Enter an API key before loading models');
  if (provider === 'google') {
    const models = [];
    let pageToken = '';
    do {
      const params = new URLSearchParams({ pageSize: '1000' });
      if (pageToken) params.set('pageToken', pageToken);
      const data = await fetchProviderJson(
        'https://generativelanguage.googleapis.com/v1beta/models?' + params.toString(),
        '',
        'Google models',
        { 'x-goog-api-key': apiKey }
      );
      for (const model of Array.isArray(data?.models) ? data.models : []) {
        const actions = model?.supportedGenerationMethods || model?.supportedActions || [];
        if (actions.includes('generateContent') && isTextChatModel(model)) models.push(model);
      }
      pageToken = String(data?.nextPageToken || '');
    } while (pageToken);
    return normalizeModelList(models);
  }
  throw new Error('Unsupported AI provider: ' + provider);
}

async function callAI(provider, apiKey, model, prompt, options = {}) {
  if (!apiKey) throw new Error('No API key for ' + provider);
  if (provider !== 'google') throw new Error('Unsupported AI provider: ' + provider);
  model = canonicalAIModel(provider, model);
  if (!model) throw new Error('No model configured for ' + provider);

  const messages = Array.isArray(options.messages) && options.messages.length
    ? options.messages
    : [{ role: 'user', content: prompt || '' }];
  const maxTokens = Number.isFinite(options.maxTokens) ? options.maxTokens : 900;

  if (provider === 'google') {
    const systemText = messages
      .filter(m => m.role === 'system')
      .map(m => m.content || '')
      .filter(Boolean)
      .join('\n\n');
    const userText = messages
      .filter(m => m.role !== 'system')
      .map(m => `${String(m.role || 'user').toUpperCase()}:\n${m.content || ''}`)
      .join('\n\n') || prompt || '';
    const isGemini3 = /^gemini-3(?:[.\-]|$)/i.test(model);
    const isGemini25 = /^gemini-2\.5(?:[.\-]|$)/i.test(model);
    const generationConfig = {
      maxOutputTokens: isGemini3 ? Math.max(maxTokens, 16_384) : maxTokens,
      ...(isGemini3
        // Gemini 3 uses thinkingLevel; HIGH is supported by the curated Flash
        // and Flash-Lite models selected for classification.
        ? { thinkingConfig: { thinkingLevel: options.thinkingLevel || 'HIGH' } }
        // Gemini 2.5 uses thinkingBudget instead of thinkingLevel. -1 enables
        // dynamic thinking, which lets it spend more effort on harder tasks.
        : isGemini25 ? { thinkingConfig: { thinkingBudget: -1 } } : {}),
    };
    const body = {
      contents: [{ role: 'user', parts: [{ text: userText }] }],
      generationConfig,
    };
    if (systemText) body.systemInstruction = { parts: [{ text: systemText }] };
    if (options.responseSchema) {
      body.generationConfig.responseMimeType = 'application/json';
      body.generationConfig.responseSchema = options.responseSchema;
    } else if (options.responseFormat) {
      body.generationConfig.responseMimeType = 'application/json';
    }
    if (options.thinkingConfig) body.generationConfig.thinkingConfig = options.thinkingConfig;

    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
    const sendGoogle = async payload => fetchAIText(url, {
      method: 'POST',
      headers: {
        'x-goog-api-key': apiKey,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    }, 'Google/' + model, Number(options.timeoutMs)||25_000, !!options.useOffscreen);
    let { res, text } = await sendGoogle(body);
    if (!res.ok && res.status === 400 && options.responseSchema) {
      const schemaRejected = /response_?schema|generationConfig\.responseSchema|responseSchema/i.test(text);
      if (schemaRejected) {
        const bodyWithoutSchema = {
          ...body,
          generationConfig: {
            ...body.generationConfig,
            responseMimeType: 'application/json',
          },
        };
        delete bodyWithoutSchema.generationConfig.responseSchema;
        ({ res, text } = await sendGoogle(bodyWithoutSchema));
      }
    }
    if (!res.ok) {
      const retryAfter = res.headers.get('retry-after');
      const dailyQuotaReset=res.status===429 && googleDailyRpdQuota(text);
      const retryAfterMs = googleRetryAfterMs(text,retryAfter);
      const retryHint = retryAfterMs ? ` [retry-after-ms: ${retryAfterMs}]` : '';
      const err = new Error('Google/' + model + ' ' + res.status + retryHint + ': ' + text.slice(0, 300));
      err.status = res.status;
      err.body = text;
      err.retryAfterMs = retryAfterMs;
      err.modelScopedRateLimit = res.status===429 && googleModelScopedRateLimit(text);
      err.dailyQuotaReset=dailyQuotaReset;
      err.retryable = res.status === 429 || res.status >= 500;
      throw err;
    }
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      throw new Error('Google/' + model + ' returned non-JSON response: ' + text.slice(0, 120));
    }
    const parts = data?.candidates?.[0]?.content?.parts || [];
    const out = parts
      .filter(part => !part.thought)
      .map(part => part.text || '')
      .join('')
      .trim();
    if (out) return out;
    const blockReason = data?.promptFeedback?.blockReason || data?.candidates?.[0]?.finishReason || 'unknown';
    const err = new Error('Google/' + model + ' empty response (' + blockReason + ')');
    err.status = ['SAFETY','RECITATION','PROHIBITED_CONTENT','BLOCKLIST','SPII'].includes(blockReason) ? 422 : 503;
    err.retryable = err.status >= 500;
    throw err;
  }

  throw new Error('Unsupported AI provider: ' + provider);
}

// ── Code execution ────────────────────────────────────────────────────────────

async function runCode(source, languageId, stdin) {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 12_000);
    const res = await fetch('https://ce.judge0.com/submissions?base64_encoded=true&wait=true', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        source_code: btoa(unescape(encodeURIComponent(source))),
        language_id: languageId,
        stdin:       btoa(unescape(encodeURIComponent(stdin || ''))),
      }),
      signal: ctrl.signal,
    });
    clearTimeout(t);
    if (res.ok) {
      const d = await res.json();
      const decode = b64 => { try { return atob(b64); } catch { return ''; } };
      const compile = d.compile_output ? decode(d.compile_output) : '';
      const stderr  = d.stderr  ? decode(d.stderr)  : '';
      const stdout  = d.stdout  ? decode(d.stdout)  : '';
      const isCompileErr = d.status?.id === 6;
      const out = isCompileErr ? compile : (stderr || stdout || compile || 'No output');
      return { output: out.trim(), error: isCompileErr ? compile.trim() : null };
    }
  } catch(e) { LOG('Judge0 failed, falling back to Piston:', e.message); }

  const PISTON = { 54:'c++', 71:'python', 62:'java' };
  const lang = PISTON[languageId];
  if (!lang) return { output: '', error: 'Unsupported language: ' + languageId };
  // Piston fallback: abort + check res.ok so a 4xx/5xx/html response doesn't
  // surface as a confusing JSON-parse SyntaxError (the Judge0 path above
  // already has both guards).
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 12_000);
  let res;
  try {
    res = await fetch('https://emkc.org/api/v2/piston/execute', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ language: lang, version: '*', files: [{ content: source }], stdin: stdin || '' }),
      signal: ctrl.signal,
    });
  } catch (e) {
    clearTimeout(t);
    return { output: '', error: 'Piston request failed: ' + (e?.message || e) };
  }
  clearTimeout(t);
  if (!res.ok) return { output: '', error: 'Piston HTTP ' + res.status };
  let d;
  try { d = await res.json(); }
  catch { return { output: '', error: 'Piston returned non-JSON response' }; }
  const ce = d.compile?.stderr?.trim();
  const out = ce || d.run?.stdout?.trim() || d.run?.stderr?.trim() || 'No output';
  return { output: out, error: ce || null };
}

// ── Monaco injection ──────────────────────────────────────────────────────────
//
// ARCHITECTURE (MV3 world isolation):
//   Chrome MV3 content scripts run in an ISOLATED world. executeScript(world:'MAIN')
//   runs in the PAGE's MAIN world. These two worlds DO NOT share JS object references —
//   DOM expando properties set in MAIN are invisible to ISOLATED world code.
//
//   So we cannot pass the `monaco` object through a DOM property.
//
//   SOLUTION: The MAIN world injection creates the Monaco editor itself and owns it.
//   Content.js (ISOLATED) communicates with it entirely via window.postMessage,
//   using the prefix 'nzoi:ed:' to distinguish these messages.
//
//   Messages content.js → MAIN world editor:
//     { _nzoi:'cmd', cmd:'create',       containerId, value, language }
//     { _nzoi:'cmd', cmd:'getValue' }
//     { _nzoi:'cmd', cmd:'setValue',     value }
//     { _nzoi:'cmd', cmd:'setLanguage',  language }
//     { _nzoi:'cmd', cmd:'setMarkers',   source, markers }
//     { _nzoi:'cmd', cmd:'clearMarkers', source }
//     { _nzoi:'cmd', cmd:'addCommand',   key, action }   (key = 'save'|'run'|'submit')
//
//   Messages MAIN world editor → content.js:
//     { _nzoi:'evt', evt:'ready' }
//     { _nzoi:'evt', evt:'change',        value }
//     { _nzoi:'evt', evt:'getValue.reply', value }
//     { _nzoi:'evt', evt:'cmd.save' }
//     { _nzoi:'evt', evt:'cmd.run' }
//     { _nzoi:'evt', evt:'cmd.submit' }

const _monacoCache = new Map();
const MONACO_BASE = chrome.runtime.getURL('libs/monaco');

async function fetchMonacoText(url) {
  if (_monacoCache.has(url)) return _monacoCache.get(url);
  LOG('Fetching', url.split('/').pop(), '...');
  const res = await fetch(url);
  if (!res.ok) throw new Error('Fetch failed: ' + res.status + ' ' + url);
  const text = await res.text();
  _monacoCache.set(url, text);
  LOG('Fetched', url.split('/').pop(), Math.round(text.length / 1024) + 'KB');
  return text;
}

async function fetchBinaryResource(url, maxBytes = 12 * 1024 * 1024) {
  const parsed = new URL(String(url || ''));
  if (!/^https?:$/.test(parsed.protocol)) throw new Error('Only HTTP(S) resources can be fetched');
  const limit = Math.max(1, Math.min(Number(maxBytes) || 12 * 1024 * 1024, 20 * 1024 * 1024));
  let res;
  try {
    res = await fetch(parsed.href, { credentials: 'include', cache: 'no-store', redirect: 'follow' });
  } catch (error) {
    throw new Error(`Fetch failed for ${parsed.protocol}//${parsed.host}: ${error?.message || error}`);
  }
  if (!res.ok) throw new Error('HTTP ' + res.status + ' fetching ' + parsed.hostname);
  const declared = Number(res.headers.get('content-length') || 0);
  if (declared && declared > limit) throw new Error('Resource too large: ' + declared + ' bytes');
  const buffer = await res.arrayBuffer();
  if (buffer.byteLength > limit) throw new Error('Resource too large: ' + buffer.byteLength + ' bytes');
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let offset = 0; offset < bytes.length; offset += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(offset, Math.min(offset + 0x8000, bytes.length)));
  }
  return {
    url: res.url || parsed.href,
    contentType: res.headers.get('content-type') || '',
    bytes: buffer.byteLength,
    base64: btoa(binary),
  };
}

async function injectMonacoIntoTab(tabId, nonce) {
  LOG('Loading Monaco for tab', tabId, '...');
  const [loaderCode, editorCode, workerCode, editorCss] = await Promise.all([
    fetchMonacoText(chrome.runtime.getURL('libs/monaco/loader.min.js')),
    fetchMonacoText(chrome.runtime.getURL('libs/monaco/editor/editor.main.js')),
    fetchMonacoText(chrome.runtime.getURL('libs/monaco/base/worker/workerMain.js')),
    fetchMonacoText(chrome.runtime.getURL('libs/monaco/editor/editor.main.css')),
  ]);
  LOG('Monaco total size:', Math.round((loaderCode.length + editorCode.length + workerCode.length + editorCss.length) / 1024) + 'KB');

  // This runs in the PAGE's MAIN world — it has access to window.monaco after loading,
  // and communicates with the isolated content script via window.postMessage.
  //
  // SECURITY: the MAIN world shares `window` with the page's own scripts, so
  // every bridge message in BOTH directions carries `nonce` and is validated
  // against it. A page script cannot guess the nonce (generated per session in
  // the isolated content script), so it cannot forge `cmd.*` requests nor read
  // or spoof `evt.*` / semantic-token replies.
  await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func: (loaderSrc, editorSrc, vsBase, workerSrc, cssSrc, nonce) => {
      // Guard against double injection
      if (window.__nzoi_editor_ready) {
        window.postMessage({ _nzoi: 'evt', n: nonce, evt: 'ready' }, '*');
        return;
      }
      if (window.__nzoi_editor_injecting) return;
      window.__nzoi_editor_injecting = true;

      // Pin the per-session nonce (passed in from the isolated content script)
      // so every listener/helper below can validate and echo it. `const NONCE`
      // is captured by the closures defined further down.
      const NONCE = nonce;

      console.log('[NZOI Enhanced MAIN] Starting Monaco injection via script tags...');

      function fail(msg) {
        window.__nzoi_editor_injecting = false;
        console.error('[NZOI Enhanced MAIN] Error:', msg);
        window.postMessage({ _nzoi: 'evt', n: NONCE, evt: 'error', message: msg }, '*');
      }

      // Worker environment: build a self-contained blob with the full worker code
      // already inlined — no importScripts() or cross-origin fetches needed.
      // This sidesteps both COEP credentialless restrictions AND any CSP worker-src rules.
      const _workerBlobUrl = URL.createObjectURL(
        new Blob([
          'const __nzoiFetch = self.fetch.bind(self);\n' +
          'self.fetch = (input, init) => {\n' +
          '  if (typeof input === "string") input = input.replace(/^(?:\\.\\.\\/)+(?=chrome-extension:\\/\\/)/, "");\n' +
          '  return __nzoiFetch(input, init);\n' +
          '};\n',
          'self.require = { baseUrl: ' + JSON.stringify(vsBase + '/') +
          ', paths: { vs: ' + JSON.stringify(vsBase) + ' } };\n',
          workerSrc,
        ], { type: 'application/javascript' })
      );
      window.MonacoEnvironment = {
        getWorker() { return new Worker(_workerBlobUrl, { name: 'monaco-editor-worker' }); },
        getWorkerUrl() { return _workerBlobUrl; },
      };

      if (!document.getElementById('nzoi-monaco-css')) {
        const style = document.createElement('style');
        style.id = 'nzoi-monaco-css';
        style.textContent = cssSrc + `
.monaco-editor .nzoi-sem-namespace,.monaco-editor .nzoi-sem-class,.monaco-editor .nzoi-sem-interface,.monaco-editor .nzoi-sem-enum,.monaco-editor .nzoi-sem-type,.monaco-editor .nzoi-sem-typeParameter{color:#4ec9b0!important}
.monaco-editor .nzoi-sem-enumMember{color:#b5cea8!important}
.monaco-editor .nzoi-sem-parameter,.monaco-editor .nzoi-sem-variable,.monaco-editor .nzoi-sem-property{color:#9cdcfe!important}
.monaco-editor .nzoi-sem-function,.monaco-editor .nzoi-sem-method{color:#dcdcaa!important}
.monaco-editor .nzoi-sem-decorator,.monaco-editor .nzoi-sem-macro{color:#c586c0!important}
.monaco-editor.vs .nzoi-sem-namespace,.monaco-editor.vs .nzoi-sem-class,.monaco-editor.vs .nzoi-sem-interface,.monaco-editor.vs .nzoi-sem-enum,.monaco-editor.vs .nzoi-sem-type,.monaco-editor.vs .nzoi-sem-typeParameter{color:#267f99!important}
.monaco-editor.vs .nzoi-sem-enumMember{color:#098658!important}
.monaco-editor.vs .nzoi-sem-parameter,.monaco-editor.vs .nzoi-sem-variable,.monaco-editor.vs .nzoi-sem-property{color:#001080!important}
.monaco-editor.vs .nzoi-sem-function,.monaco-editor.vs .nzoi-sem-method{color:#795e26!important}
.monaco-editor.vs .nzoi-sem-decorator,.monaco-editor.vs .nzoi-sem-macro{color:#af00db!important}
.monaco-editor .nzoi-sem-declaration{font-weight:600!important}
.monaco-editor .nzoi-sem-readonly,.monaco-editor .nzoi-sem-static{font-style:italic!important}
.monaco-hover,.monaco-editor-hover,.monaco-editor .suggest-widget,.monaco-editor .parameter-hints-widget,.monaco-editor .overflowingContentWidgets,.context-view,.monaco-menu-container,.quick-input-widget{z-index:2147483647!important}
.monaco-editor .overflowingContentWidgets{overflow:visible!important}
`;
        (document.head || document.documentElement).appendChild(style);
      }

      // Inject as script tags so document.currentScript is set correctly,
      // which Monaco's AMD loader needs to resolve its own base path.
      function injectScript(code, onDone, onFail) {
        const s = document.createElement('script');
        const u = URL.createObjectURL(new Blob([code], { type: 'text/javascript' }));
        s.src = u;
        s.onload  = () => { URL.revokeObjectURL(u); onDone(); };
        s.onerror = () => { URL.revokeObjectURL(u); onFail('script tag load failed'); };
        (document.head || document.documentElement).appendChild(s);
      }

      let _editor = null;
      let _semDecorationIds = [];

// ── Semantic tokens: legend + request/response bridge ─────────────────
      // MUST match SEM_TOKEN_TYPES / SEM_TOKEN_MODIFIERS in content.js exactly
      // (index positions are the wire format for the LSP semanticTokens data array).
      const SEM_TYPES = ['namespace','class','interface','enum','enumMember','type','typeParameter','parameter','variable','property','function','method','decorator','macro'];
      const SEM_MODS  = ['declaration','readonly','static','defaultLibrary','async'];
      const _semPending = {};
      let _semIdCtr = 0;
      const _semanticProviderListeners = new Map();

      function fireSemanticTokenChange(lang) {
        const listeners = _semanticProviderListeners.get(lang);
        if (listeners) for (const listener of [...listeners]) listener();
      }

      window.addEventListener('message', e => {
        if (!e.data || e.data._nzoiSem !== 'res') return;
        // Only accept semantic-token replies that carry our session nonce.
        if (e.data.n !== NONCE) return;
        const cb = _semPending[e.data.id];
        if (cb) { cb(e.data.data || []); delete _semPending[e.data.id]; }
      });

      function requestSemTokens(lang, value) {
        return new Promise(resolve => {
          const id = 'msem-' + (++_semIdCtr);
          _semPending[id] = resolve;
          window.postMessage({ _nzoiSem:'req', n: NONCE, lang, id, value }, '*');
          // Safety timeouts — never let a stuck request hang Monaco's highlighter
          setTimeout(() => { if (_semPending[id]) { resolve([]); delete _semPending[id]; } }, 30000);
        });
      }

      function registerSemanticTokens(lang) {
        window.monaco.languages.registerDocumentSemanticTokensProvider(lang, {
          onDidChange: (listener, thisArgs, disposables) => {
            const listeners = _semanticProviderListeners.get(lang) || new Set();
            _semanticProviderListeners.set(lang, listeners);
            const wrapped = thisArgs ? listener.bind(thisArgs) : listener;
            listeners.add(wrapped);
            const disposable = { dispose:() => listeners.delete(wrapped) };
            if (disposables) disposables.push(disposable);
            return disposable;
          },
          getLegend: () => ({ tokenTypes: SEM_TYPES, tokenModifiers: SEM_MODS }),
          provideDocumentSemanticTokens: async (model) => ({
            data: new Uint32Array(await requestSemTokens(lang, model.getValue())),
          }),
          releaseDocumentSemanticTokens: () => {},
        });
      }

      function themeName(theme) {
        return theme === 'vs' || theme === 'light' || theme === 'nzoi-light' ? 'nzoi-light' : 'nzoi-dark';
      }

      function clearSemanticDecorations() {
        if (_editor && _semDecorationIds.length) {
          _semDecorationIds = _editor.deltaDecorations(_semDecorationIds, []);
        } else {
          _semDecorationIds = [];
        }
      }

      function setSemanticDecorations(tokens) {
        if (!_editor) return;
        const range = window.monaco.Range;
        const stickiness = window.monaco.editor.TrackedRangeStickiness.NeverGrowsWhenTypingAtEdges;
        const decorations = (tokens || [])
          .filter(t => Array.isArray(t) && t[2] > 0 && SEM_TYPES.includes(t[3]))
          .map(([line, col, length, type, mods]) => ({
            range: new range(line + 1, col + 1, line + 1, col + length + 1),
            options: {
              inlineClassName: ['nzoi-sem-' + type].concat((mods || []).map(m => 'nzoi-sem-' + m)).join(' '),
              stickiness,
            },
          }));
        _semDecorationIds = _editor.deltaDecorations(_semDecorationIds, decorations);
      }

      function refreshEditorTokens() {
        if (!_editor) return;
        _editor.updateOptions({ 'semanticHighlighting.enabled': true });
        const model = _editor.getModel();
        if (model?.tokenization?.forceTokenization) model.tokenization.forceTokenization(model.getLineCount());
        if (typeof _editor.render === 'function') _editor.render(true);
      }

      function ensureLanguage(id, aliases, extensions) {
        if (!window.monaco.languages.getLanguages().some(l => l.id === id)) {
          window.monaco.languages.register({ id, aliases, extensions });
        }
      }

      // editor.main.js registers C++ as a lazy language, but this packaged
      // extension intentionally carries no vs/basic-languages/cpp module.
      // Install an in-memory tokenizer so the visible C++ editor always gets
      // syntax colors without an iframe or a network-loaded grammar.
      function installCppLanguage() {
        ensureLanguage('cpp', ['C++', 'Cpp', 'cpp'], ['.cpp', '.cc', '.cxx', '.hpp', '.h']);
        window.monaco.languages.setLanguageConfiguration('cpp', {
          comments: { lineComment: '//', blockComment: ['/*', '*/'] },
          brackets: [['{','}'], ['[',']'], ['(',')']],
          autoClosingPairs: [
            { open:'{', close:'}' }, { open:'[', close:']' }, { open:'(', close:')' },
            { open:'"', close:'"', notIn:['string','comment'] },
            { open:"'", close:"'", notIn:['string','comment'] },
          ],
          surroundingPairs: [
            { open:'{', close:'}' }, { open:'[', close:']' }, { open:'(', close:')' },
            { open:'"', close:'"' }, { open:"'", close:"'" },
          ],
        });
        window.monaco.languages.setMonarchTokensProvider('cpp', {
          defaultToken: '',
          tokenPostfix: '.cpp',
          keywords: [
            'alignas','alignof','asm','auto','bool','break','case','catch','char','char8_t','char16_t','char32_t',
            'class','concept','const','consteval','constexpr','constinit','const_cast','continue','co_await',
            'co_return','co_yield','decltype','default','delete','do','double','dynamic_cast','else','enum',
            'explicit','export','extern','false','final','float','for','friend','goto','if','inline','int',
            'long','mutable','namespace','new','noexcept','nullptr','operator','override','private','protected',
            'public','register','reinterpret_cast','requires','return','short','signed','sizeof','static',
            'static_assert','static_cast','struct','switch','template','this','thread_local','throw','true',
            'try','typedef','typeid','typename','union','unsigned','using','virtual','void','volatile','wchar_t',
            'while','and','or','not','xor','bitand','bitor','compl','and_eq','or_eq','xor_eq','not_eq',
          ],
          types: ['size_t','string','vector','array','map','unordered_map','set','unordered_set','pair','tuple','queue','stack','deque','list','optional','variant','string_view'],
          tokenizer: {
            root: [
              [/^\s*#\s*(?:include|import)\b/, { token:'keyword.directive', next:'@includes' }],
              [/^\s*#\s*[a-zA-Z_]\w*/, 'keyword.directive'],
              { include:'@whitespace' },
              [/[a-zA-Z_]\w*(?=\s*\()/, { cases:{ '@keywords':'keyword', '@types':'type.identifier', '@default':'function.identifier' } }],
              [/[a-zA-Z_]\w*/, { cases:{ '@keywords':'keyword', '@types':'type.identifier', '@default':'identifier' } }],
              [/\d[\w'.]*/, 'number'],
              [/"/, 'string', '@string'],
              [/'/, 'string', '@char'],
              [/[{}()[\]]/, '@brackets'],
              [/[;,.]/, 'delimiter'],
              [/[<>=!~?:&|+\-*\/%^]+/, 'operator'],
            ],
            includes: [
              [/\s+/, 'white'],
              [/<[^>\r\n]+>/, 'string', '@pop'],
              [/"[^"\r\n]+"/, 'string', '@pop'],
              [/$/, '', '@pop'],
              [/./, 'identifier'],
            ],
            whitespace: [
              [/\s+/, 'white'],
              [/\/\*/, 'comment', '@comment'],
              [/\/\/.*$/, 'comment'],
            ],
            comment: [
              [/[^/*]+/, 'comment'],
              [/\*\//, 'comment', '@pop'],
              [/[/*]/, 'comment'],
            ],
            string: [
              [/[^\\"]+/, 'string'],
              [/\\./, 'string.escape'],
              [/"/, 'string', '@pop'],
            ],
            char: [
              [/[^\\']+/, 'string'],
              [/\\./, 'string.escape'],
              [/'/, 'string', '@pop'],
            ],
          },
        });
      }

      function installPythonLanguage() {
        ensureLanguage('python', ['Python', 'py'], ['.py']);
        window.monaco.languages.setLanguageConfiguration('python', {
          comments: { lineComment: '#', blockComment: ["'''", "'''"] },
          brackets: [['{','}'], ['[',']'], ['(',')']],
          autoClosingPairs: [
            { open:'{', close:'}' }, { open:'[', close:']' }, { open:'(', close:')' },
            { open:'"', close:'"', notIn:['string'] }, { open:"'", close:"'", notIn:['string','comment'] },
          ],
          surroundingPairs: [
            { open:'{', close:'}' }, { open:'[', close:']' }, { open:'(', close:')' },
            { open:'"', close:'"' }, { open:"'", close:"'" },
          ],
        });
        window.monaco.languages.setMonarchTokensProvider('python', {
          defaultToken: '',
          tokenPostfix: '.python',
          keywords: [
            'and','as','assert','async','await','break','class','continue','def','del','elif','else',
            'except','finally','for','from','global','if','import','in','is','lambda','nonlocal','not',
            'or','pass','raise','return','try','while','with','yield','True','False','None',
          ],
          builtins: [
            'abs','all','any','bool','dict','enumerate','float','int','len','list','map','max','min',
            'open','pow','print','range','reversed','set','sorted','str','sum','tuple','zip','input',
          ],
          tokenizer: {
            root: [
              [/^\s*@[\w.]+/, 'annotation'],
              [/[a-zA-Z_]\w*/, { cases: { '@keywords':'keyword', '@builtins':'predefined', '@default':'identifier' } }],
              [/\d+(\.\d+)?([eE][\-+]?\d+)?/, 'number'],
              [/[{}()\[\]]/, '@brackets'],
              [/#.*$/, 'comment'],
              [/'''/, 'string', '@tqs'],
              [/"""/, 'string', '@tqd'],
              [/'/, 'string', '@sq'],
              [/"/, 'string', '@dq'],
            ],
            tqs: [[/[^']+/, 'string'], [/'''/, 'string', '@pop'], [/'/, 'string']],
            tqd: [[/[^"]+/, 'string'], [/"""/, 'string', '@pop'], [/"/, 'string']],
            sq: [[/\\./, 'string.escape'], [/[^\\']+/, 'string'], [/'/, 'string', '@pop']],
            dq: [[/\\./, 'string.escape'], [/[^\\"]+/, 'string'], [/"/, 'string', '@pop']],
          },
        });
      }

      function installJavaLanguage() {
        ensureLanguage('java', ['Java'], ['.java']);
        window.monaco.languages.setLanguageConfiguration('java', {
          comments: { lineComment: '//', blockComment: ['/*', '*/'] },
          brackets: [['{','}'], ['[',']'], ['(',')']],
          autoClosingPairs: [
            { open:'{', close:'}' }, { open:'[', close:']' }, { open:'(', close:')' },
            { open:'"', close:'"', notIn:['string'] }, { open:"'", close:"'", notIn:['string','comment'] },
          ],
          surroundingPairs: [
            { open:'{', close:'}' }, { open:'[', close:']' }, { open:'(', close:')' },
            { open:'"', close:'"' }, { open:"'", close:"'" },
          ],
        });
        window.monaco.languages.setMonarchTokensProvider('java', {
          defaultToken: '',
          tokenPostfix: '.java',
          keywords: [
            'abstract','assert','boolean','break','byte','case','catch','char','class','const','continue',
            'default','do','double','else','enum','extends','final','finally','float','for','goto','if',
            'implements','import','instanceof','int','interface','long','native','new','package','private',
            'protected','public','return','short','static','strictfp','super','switch','synchronized','this',
            'throw','throws','transient','try','void','volatile','while','var','record','sealed','permits',
            'true','false','null',
          ],
          tokenizer: {
            root: [
              [/[A-Z][\w$]*/, 'type.identifier'],
              [/[a-zA-Z_$][\w$]*/, { cases: { '@keywords':'keyword', '@default':'identifier' } }],
              [/\d+(\.\d+)?([eE][\-+]?\d+)?[fFdDlL]?/, 'number'],
              [/[{}()\[\]]/, '@brackets'],
              [/\/\/.*$/, 'comment'],
              [/\/\*/, 'comment', '@comment'],
              [/"/, 'string', '@string'],
              [/'([^'\\]|\\.)*$/, 'string.invalid'],
              [/'/, 'string', '@char'],
              [/@[a-zA-Z_$][\w$]*/, 'annotation'],
            ],
            comment: [[/[^\/*]+/, 'comment'], [/\*\//, 'comment', '@pop'], [/[\/*]/, 'comment']],
            string: [[/[^\\"]+/, 'string'], [/\\./, 'string.escape'], [/"/, 'string', '@pop']],
            char: [[/[^\\']+/, 'string'], [/\\./, 'string.escape'], [/'/, 'string', '@pop']],
          },
        });
      }

      function installNZOIThemes() {
        const semanticDark = {
          namespace: '#4ec9b0',
          class: '#4ec9b0',
          interface: '#4ec9b0',
          enum: '#4ec9b0',
          enumMember: '#b5cea8',
          type: '#4ec9b0',
          typeParameter: '#4ec9b0',
          parameter: '#9cdcfe',
          variable: '#9cdcfe',
          property: '#9cdcfe',
          function: '#dcdcaa',
          method: '#dcdcaa',
          decorator: '#c586c0',
          macro: '#c586c0',
          'variable.defaultLibrary': '#4fc1ff',
          'function.defaultLibrary': '#dcdcaa',
          '*.declaration': { foreground: '#ffffff', fontStyle: 'bold' },
          '*.readonly': { fontStyle: 'italic' },
          '*.static': { fontStyle: 'italic' },
        };
        const semanticLight = {
          namespace: '#267f99',
          class: '#267f99',
          interface: '#267f99',
          enum: '#267f99',
          enumMember: '#098658',
          type: '#267f99',
          typeParameter: '#267f99',
          parameter: '#001080',
          variable: '#001080',
          property: '#001080',
          function: '#795e26',
          method: '#795e26',
          decorator: '#af00db',
          macro: '#af00db',
          'variable.defaultLibrary': '#0070c1',
          'function.defaultLibrary': '#795e26',
          '*.declaration': { foreground: '#000000', fontStyle: 'bold' },
          '*.readonly': { fontStyle: 'italic' },
          '*.static': { fontStyle: 'italic' },
        };
        window.monaco.editor.defineTheme('nzoi-dark', {
          base: 'vs-dark',
          inherit: true,
          semanticHighlighting: true,
          rules: [
            { token: 'keyword', foreground: '569cd6' },
            { token: 'keyword.directive', foreground: 'c586c0' },
            { token: 'string', foreground: 'ce9178' },
            { token: 'comment', foreground: '6a9955' },
            { token: 'number', foreground: 'b5cea8' },
            { token: 'annotation', foreground: 'c586c0' },
            { token: 'predefined', foreground: '4fc1ff' },
            { token: 'identifier', foreground: '9cdcfe' },
            { token: 'type.identifier', foreground: '4ec9b0' },
            { token: 'function.identifier', foreground: 'dcdcaa' },
            { token: 'string.escape', foreground: 'd7ba7d' },
          ],
          colors: { 'editor.background': '#1e1e1e' },
          semanticTokenColors: semanticDark,
        });
        window.monaco.editor.defineTheme('nzoi-light', {
          base: 'vs',
          inherit: true,
          semanticHighlighting: true,
          rules: [
            { token: 'keyword', foreground: '0000ff' },
            { token: 'keyword.directive', foreground: 'af00db' },
            { token: 'string', foreground: 'a31515' },
            { token: 'comment', foreground: '008000' },
            { token: 'number', foreground: '098658' },
            { token: 'annotation', foreground: 'af00db' },
            { token: 'predefined', foreground: '0070c1' },
            { token: 'identifier', foreground: '001080' },
            { token: 'type.identifier', foreground: '267f99' },
            { token: 'function.identifier', foreground: '795e26' },
            { token: 'string.escape', foreground: '811f3f' },
          ],
          colors: { 'editor.background': '#ffffff' },
          semanticTokenColors: semanticLight,
        });
      }

      // Handle commands from isolated-world content.js
      window.addEventListener('message', function onMsg(e) {
        if (!e.data || e.data._nzoi !== 'cmd') return;
        const d = e.data;
        // Reject commands that don't carry our per-session nonce — only the
        // isolated content script that requested this injection knows it, so a
        // page script cannot drive the editor (create/setValue/setMarkers/...).
        if (d.n !== NONCE) return;
        if (d.cmd === 'create') {
          const container = document.getElementById(d.containerId);
          if (!container) { fail('Monaco container #' + d.containerId + ' not found'); return; }
          container.innerHTML = '';
          _editor = window.monaco.editor.create(container, {
            value:    d.value || '',
            language: d.language || 'cpp',
            theme:    themeName(d.theme),
            automaticLayout:         true,
            fontSize:                14,
            lineHeight:              21,
            fontFamily:              "'JetBrains Mono', 'Fira Code', 'Cascadia Code', 'Courier New', monospace",
            fontLigatures:           true,
            minimap:                 { enabled: false },
            scrollBeyondLastLine:    false,
            wordWrap:                'off',
            tabSize:                 4,
            insertSpaces:            true,
            renderWhitespace:        'selection',
            bracketPairColorization: { enabled: true },
            guides:                  { bracketPairs: true },
            smoothScrolling:         true,
            cursorSmoothCaretAnimation: 'on',
            suggest:                 { showMethods: true, showFunctions: true, showClasses: true },
            quickSuggestions:        { other: true, comments: false, strings: false },
            fixedOverflowWidgets:    true,
            hover:                   { enabled: true, above: false, sticky: true },
            padding:                 { top: 8, bottom: 8 },
            'semanticHighlighting.enabled': true,
          });
          _editor.onDidChangeModelContent(() => {
            window.postMessage({ _nzoi: 'evt', n: NONCE, evt: 'change', value: _editor.getValue() }, '*');
          });
          _editor.addCommand(window.monaco.KeyMod.CtrlCmd | window.monaco.KeyCode.KeyS,
            () => window.postMessage({ _nzoi: 'evt', n: NONCE, evt: 'cmd.save' }, '*'));
          _editor.addCommand(window.monaco.KeyMod.Alt | window.monaco.KeyCode.KeyR,
            () => window.postMessage({ _nzoi: 'evt', n: NONCE, evt: 'cmd.run' }, '*'));
          _editor.addCommand(window.monaco.KeyMod.Alt | window.monaco.KeyCode.KeyS,
            () => window.postMessage({ _nzoi: 'evt', n: NONCE, evt: 'cmd.submit' }, '*'));
          window.postMessage({ _nzoi: 'evt', n: NONCE, evt: 'ready' }, '*');
        } else if (d.cmd === 'getValue') {
          window.postMessage({ _nzoi: 'evt', n: NONCE, evt: 'getValue.reply', value: _editor ? _editor.getValue() : '' }, '*');
        } else if (d.cmd === 'setValue') {
          if (_editor) { _editor.setValue(d.value || ''); clearSemanticDecorations(); }
        } else if (d.cmd === 'setLanguage') {
          if (_editor) { window.monaco.editor.setModelLanguage(_editor.getModel(), d.language); clearSemanticDecorations(); }
        } else if (d.cmd === 'setMarkers') {
          if (_editor) {
            const sev = s => s === 8 ? window.monaco.MarkerSeverity.Error : window.monaco.MarkerSeverity.Warning;
            window.monaco.editor.setModelMarkers(_editor.getModel(), d.source,
              (d.markers || []).map(m => ({ ...m, severity: sev(m.severity), source: d.source })));
          }
        } else if (d.cmd === 'clearMarkers') {
          if (_editor) window.monaco.editor.setModelMarkers(_editor.getModel(), d.source, []);
        } else if (d.cmd === 'setTheme') {
          window.monaco.editor.setTheme(themeName(d.theme));
          refreshEditorTokens();
        } else if (d.cmd === 'refreshSemanticTokens') {
          refreshEditorTokens();
        } else if (d.cmd === 'refreshSemanticProvider') {
          fireSemanticTokenChange(d.language || _editor?.getModel()?.getLanguageId());
          refreshEditorTokens();
        } else if (d.cmd === 'setSemanticDecorations') {
          setSemanticDecorations(d.tokens);
        } else if (d.cmd === 'clearSemanticDecorations') {
          clearSemanticDecorations();
        }
      });

      // Step 1: load AMD loader
      injectScript(loaderSrc, () => {
        if (!window.require) { fail('loader.min.js did not set window.require'); return; }
        window.require.config({ paths: { vs: vsBase } });
        console.log('[NZOI Enhanced MAIN] AMD loader ready, loading editor bundle...');

        // Step 2: load editor bundle, then call require() to initialise monaco
        injectScript(editorSrc, () => {
          console.log('[NZOI Enhanced MAIN] Editor bundle loaded, calling require...');
          window.require(['vs/editor/editor.main'], () => {
            if (!window.monaco) { fail('require callback fired but window.monaco not set'); return; }
            console.log('[NZOI Enhanced MAIN] window.monaco ready ✓');
            // Real LSP semantic-tokens providers (textDocument/semanticTokens) —
            // backed by genuine ast/lexical analysis in the isolated content
            // script via the _nzoiSem bridge above, not Monarch/regex re-styling.
            try {
              installCppLanguage();
              installPythonLanguage();
              installJavaLanguage();
              installNZOIThemes();
              registerSemanticTokens('python');
              registerSemanticTokens('java');
              registerSemanticTokens('cpp');
            } catch (e) {
              console.warn('[NZOI Enhanced MAIN] semantic tokens registration failed:', e && e.message);
            }
            window.__nzoi_editor_ready     = true;
            window.__nzoi_editor_injecting = false;
            // Signal isolated world that Monaco is ready to receive 'create' command
            window.postMessage({ _nzoi: 'evt', n: NONCE, evt: 'monaco-loaded' }, '*');
          }, (err) => fail('require failed: ' + (err && err.message || err)));
        }, fail);
      }, fail);
    },
    args: [loaderCode, editorCode, MONACO_BASE, workerCode, editorCss, nonce],
  });

  LOG('Monaco injection dispatched for tab', tabId);
}

// ── Durable Google classification queue ───────────────────────────────────────
const CLASSIFIER_DB = 'nzoi-classifier-queue-v1';
const CLASSIFIER_ALARM = 'nzoi-classifier-queue';
const CLASSIFIER_MAX_BATCH_ITEMS = 15;
const QUESTION_DB = 'nzoi-question-archive-queue-v1';
const QUESTION_ALARM = 'nzoi-question-archive-queue';
let classifierDrain = null;
let questionArchiveDrain = null;
const CLASSIFIER_DIFFS = ['beginner','easy','medium','hard','very_hard','hardcore','olympiad_hard'];
const CLASSIFIER_TAGS = new Set([
  '2-satisfiability','binary search','bitmasks','brute force','chinese remainder theorem','combinatorics',
  'constructive algorithms','data structures','depth-first search and similar','divide and conquer',
  'dynamic programming','disjoint set union','expression parsing','fast fourier transform','flows',
  'game theory','geometry','graph matchings','graphs','greedy algorithms','hashing','implementation',
  'linear algebra','meet-in-the-middle','number theory','probabilities','scheduling','shortest paths',
  'sorting','string suffix structures','strings','ternary search','trees','two pointers','io',
]);

// Persistent question discovery. The site scan is kept in IndexedDB so Chrome
// can suspend the service worker or the dashboard tab without losing pages.
const DISCOVERY_DB = 'nzoi-background-discovery-v1';
const DISCOVERY_ALARM = 'nzoi-background-discovery';
const PROBLEM_WORK_ALARM = 'nzoi-background-problem-work';
const BEST_ANSWER_ALARM = 'nzoi-background-best-answers';
const DISCOVERY_STATUS_KEY = 'nzoiProblemDiscoveryProgressV1';
const PROBLEM_WORK_STATUS_KEY = 'nzoiBackgroundProblemWorkProgressV1';
const BEST_ANSWER_STATUS_KEY = 'nzoiBestSubmissionProgress';
const DISCOVERY_MAX_PAGES = 3_000;
const DISCOVERY_PAGE_WORKERS = 4;
const DISCOVERY_MAX_ATTEMPTS = 10;
let discoveryDrain = null;
let problemWorkDrain = null;
let bestAnswerDrain = null;
let backgroundWorkEpoch=0;
function ensureBackgroundWorkActive(epoch){
  if(epoch===backgroundWorkEpoch)return;
  const error=new Error('Background work was cleared from the extension data manager.');
  error.code='background-work-cleared';
  throw error;
}

function backgroundWorkDB() {
  return new Promise((resolve,reject)=>{
    const request=indexedDB.open(DISCOVERY_DB,1);
    request.onupgradeneeded=()=>{
      const db=request.result;
      if (!db.objectStoreNames.contains('state')) db.createObjectStore('state',{keyPath:'id'});
      if (!db.objectStoreNames.contains('pages')) db.createObjectStore('pages',{keyPath:'id'});
      if (!db.objectStoreNames.contains('problems')) db.createObjectStore('problems',{keyPath:'id'});
      if (!db.objectStoreNames.contains('problemTasks')) db.createObjectStore('problemTasks',{keyPath:'id'});
      if (!db.objectStoreNames.contains('answerTasks')) db.createObjectStore('answerTasks',{keyPath:'id'});
    };
    request.onsuccess=()=>resolve(request.result);
    request.onerror=()=>reject(request.error||new Error('Could not open the background discovery queue'));
  });
}
async function backgroundWorkGet(storeName,key) {
  const db=await backgroundWorkDB();
  try { return await new Promise((resolve,reject)=>{
    const request=db.transaction(storeName,'readonly').objectStore(storeName).get(key);
    request.onsuccess=()=>resolve(request.result||null); request.onerror=()=>reject(request.error);
  }); } finally { db.close(); }
}
async function backgroundWorkAll(storeName) {
  const db=await backgroundWorkDB();
  try { return await new Promise((resolve,reject)=>{
    const request=db.transaction(storeName,'readonly').objectStore(storeName).getAll();
    request.onsuccess=()=>resolve(request.result||[]); request.onerror=()=>reject(request.error);
  }); } finally { db.close(); }
}
async function backgroundWorkGetMany(storeName,keys) {
  const unique=[...new Set((keys||[]).map(String))];
  if(!unique.length)return [];
  const db=await backgroundWorkDB();
  try{return await new Promise((resolve,reject)=>{
    const tx=db.transaction(storeName,'readonly'),store=tx.objectStore(storeName),results=[];
    unique.forEach((key,index)=>{const request=store.get(key);request.onsuccess=()=>{if(request.result)results.push(request.result);};request.onerror=()=>reject(request.error);});
    tx.oncomplete=()=>resolve(results);tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error);
  });}finally{db.close();}
}
async function backgroundWorkPut(storeName,value) {
  const db=await backgroundWorkDB();
  try { await new Promise((resolve,reject)=>{
    const transaction=db.transaction(storeName,'readwrite');
    transaction.objectStore(storeName).put(value);
    transaction.oncomplete=()=>resolve(); transaction.onerror=()=>reject(transaction.error); transaction.onabort=()=>reject(transaction.error);
  }); } finally { db.close(); }
}
async function backgroundWorkAdd(storeName,value) {
  const db=await backgroundWorkDB();
  try { return await new Promise((resolve,reject)=>{
    const transaction=db.transaction(storeName,'readwrite');
    const request=transaction.objectStore(storeName).add(value);
    let added=true;
    request.onerror=event=>{
      if(request.error?.name==='ConstraintError'){
        added=false;
        event.preventDefault();
        event.stopPropagation();
      }
    };
    transaction.oncomplete=()=>resolve(added);
    transaction.onerror=()=>reject(transaction.error);
    transaction.onabort=()=>reject(transaction.error);
  }); } finally { db.close(); }
}
async function backgroundWorkPutMany(storeName,values) {
  if(!values?.length)return;
  const db=await backgroundWorkDB();
  try{await new Promise((resolve,reject)=>{
    const tx=db.transaction(storeName,'readwrite'),store=tx.objectStore(storeName);
    for(const value of values)store.put(value);
    tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error);
  });}finally{db.close();}
}
async function backgroundWorkDelete(storeName,key) {
  const db=await backgroundWorkDB();
  try { await new Promise((resolve,reject)=>{
    const transaction=db.transaction(storeName,'readwrite');
    transaction.objectStore(storeName).delete(key);
    transaction.oncomplete=()=>resolve(); transaction.onerror=()=>reject(transaction.error); transaction.onabort=()=>reject(transaction.error);
  }); } finally { db.close(); }
}
async function backgroundWorkClear(storeName) {
  const db=await backgroundWorkDB();
  try { await new Promise((resolve,reject)=>{
    const transaction=db.transaction(storeName,'readwrite');
    transaction.objectStore(storeName).clear();
    transaction.oncomplete=()=>resolve(); transaction.onerror=()=>reject(transaction.error); transaction.onabort=()=>reject(transaction.error);
  }); } finally { db.close(); }
}
function canonicalNZOIPage(value,base='https://train.nzoi.org.nz/') {
  try {
    const url=new URL(value,base);
    if (url.origin!=='https://train.nzoi.org.nz') return '';
    url.hash='';
    const params=[...url.searchParams.entries()].sort(([ak,av],[bk,bv])=>ak.localeCompare(bk)||av.localeCompare(bv));
    url.search=''; params.forEach(([key,val])=>url.searchParams.append(key,val));
    return url.href;
  } catch { return ''; }
}
function backgroundGroupBase(value) {
  const canonical=canonicalNZOIPage(value);
  if (!canonical) return '';
  const url=new URL(canonical), parts=url.pathname.split('/').filter(Boolean);
  if (parts[0]!=='groups'||parts.length<2||/^(?:new|search|join)$/i.test(parts[1])) return '';
  const childRoutes=new Set(['problems','submissions','members','settings','edit','activity','leaderboard','solutions','results']);
  const childIndex=parts.findIndex((part,index)=>index>=2&&childRoutes.has(part.toLowerCase()));
  url.pathname=`/${(childIndex>=0?parts.slice(0,childIndex):parts).join('/')}`;
  url.search=''; url.hash='';
  return url.href.replace(/\/$/,'');
}
async function discoveryPageCount(runId) {
  return (await backgroundWorkAll('pages')).filter(page=>page.runId===runId).length;
}
async function discoveryQueuePage(state,entry) {
  const href=canonicalNZOIPage(entry.url,state.homeUrl);
  if (!href) return false;
  const family=entry.family==='group'?'group':'home';
  const familyBase=family==='group'?backgroundGroupBase(entry.familyBase||href):canonicalNZOIPage(state.homeUrl);
  if (!familyBase) return false;
  const url=new URL(href), base=new URL(familyBase);
  const inFamily=family==='group'
    ? url.pathname.replace(/\/$/,'')===base.pathname.replace(/\/$/,'')||url.pathname.startsWith(base.pathname.replace(/\/$/,'')+'/')
    : url.pathname.replace(/\/$/,'')===base.pathname.replace(/\/$/,'');
  if (!inFamily) return false;
  const id=`${state.runId}|${href}`;
  if (!Number.isFinite(Number(state.pageCount))) state.pageCount=await discoveryPageCount(state.runId);
  if (Number(state.pageCount)>=DISCOVERY_MAX_PAGES) { state.limitHit=true; return false; }
  const added=await backgroundWorkAdd('pages',{id,runId:state.runId,url:href,family,familyBase,groupName:String(entry.groupName||''),status:'queued',attempts:0,nextAttemptAt:0,createdAt:Date.now()});
  if(added)state.pageCount++;
  return added;
}
async function discoveryPublish(state,activity='Finding problems',newProblems=[],lastError='') {
  const pages=(await backgroundWorkAll('pages')).filter(page=>page.runId===state.runId);
  const records=await backgroundWorkAll('problems');
  const pending=pages.filter(page=>['queued','working'].includes(page.status)).length;
  const failed=pages.filter(page=>page.status==='failed').length;
  state.pendingPages=pending;
  state.failedPages=failed;
  state.pageCount=pages.length;
  state.discoveredCount=records.length;
  state.updatedAt=Date.now();
  await backgroundWorkPut('state',state);
  await store.set({[DISCOVERY_STATUS_KEY]:{
    runId:state.runId,status:state.status,activity,processedPages:Number(state.processedPages)||0,
    pendingPages:pending,failedPages:failed,discoveredCount:records.length,
    limitHit:!!state.limitHit,lastError:String(lastError||state.lastError||''),
    newProblems:(newProblems||[]).slice(0,1_000),updatedAt:state.updatedAt,
  }});
}
async function upsertDiscoveredProblems(incoming) {
  const changed=[];
  const values=(incoming||[]).filter(value=>/^\d+$/.test(String(value?.id||''))&&canonicalNZOIPage(value?.href));
  const oldRows=await backgroundWorkGetMany('problems',values.map(value=>String(value.id)));
  const oldById=new Map(oldRows.map(row=>[String(row.id),row]));
  const writes=[];
  for (const value of values) {
    const id=String(value?.id||'');
    const href=canonicalNZOIPage(value?.href);
    if (!href) continue;
    const old=oldById.get(id);
    const next={
      ...(old||{}),...value,id,href,
      name:String(value.name||old?.name||`Problem ${id}`),
      group:String(value.group||old?.group||'Public'),
      progress:Math.max(Number(old?.progress)||0,Number(value.progress)||0),
    };
    writes.push(next);
    if (!old||next.progress>Number(old.progress||0)||next.name!==old.name||next.href!==old.href||next.group!==old.group) changed.push(next);
  }
  await backgroundWorkPutMany('problems',writes);
  return changed;
}
async function getProblemDiscoverySnapshot() {
  const [state,problems]=await Promise.all([backgroundWorkGet('state','active'),backgroundWorkAll('problems')]);
  return {runId:state?.runId||'',status:state?.status||'idle',discoveredCount:problems.length,problems};
}
async function startProblemDiscovery(message={}) {
  const homeUrl=canonicalNZOIPage(message.homeUrl||'https://train.nzoi.org.nz/');
  if (!homeUrl) throw new Error('Open the NZOI training homepage before starting background discovery.');
  let state=await backgroundWorkGet('state','active');
  if (!state||['complete','complete-with-errors','needs-login','failed'].includes(state.status)) {
    await backgroundWorkClear('pages');
    state={id:'active',runId:`discovery-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`,
      homeUrl,status:'running',processedPages:0,failedPages:0,discoveredCount:0,pageCount:0,startedAt:Date.now(),lastError:'',limitHit:false};
  } else {
    state.status='running';
    state.homeUrl=homeUrl;
  }
  const initial=Array.isArray(message.problems)?message.problems:[];
  const changed=await upsertDiscoveredProblems(initial);
  for (const group of Array.isArray(message.groups)?message.groups:[]) {
    const base=backgroundGroupBase(group?.href);
    if (base) await discoveryQueuePage(state,{url:base,family:'group',familyBase:base,groupName:group.name});
  }
  await discoveryQueuePage(state,{url:homeUrl,family:'home',familyBase:homeUrl,groupName:'Public'});
  await queueBackgroundProblemWork(initial);
  await queueBackgroundBestAnswers(initial);
  await discoveryPublish(state,'Finding problems',changed);
  discoverySchedule(0);
  void runProblemDiscoveryQueue();
  const problems=await backgroundWorkAll('problems');
  return {runId:state.runId,discoveredCount:problems.length,problems,status:state.status};
}
function discoverySchedule(delay=30_000) {
  chrome.alarms.create(DISCOVERY_ALARM,{delayInMinutes:Math.max(0.5,delay/60_000)});
}
async function processDiscoveryPage(entry,state,epoch=backgroundWorkEpoch) {
  const parsed=await fetchNZOIParsedPage(entry.url,'discover');
  ensureBackgroundWorkActive(epoch);
  const finalUrl=canonicalNZOIPage(parsed.pageUrl||entry.url);
  const current=new URL(finalUrl), base=new URL(entry.familyBase);
  const valid=entry.family==='group'
    ? current.origin===base.origin&&(current.pathname.replace(/\/$/,'')===base.pathname.replace(/\/$/,'')||current.pathname.startsWith(base.pathname.replace(/\/$/,'')+'/'))
    : current.origin===base.origin&&current.pathname.replace(/\/$/,'')===base.pathname.replace(/\/$/,'');
  if (!valid) throw new Error('NZOI redirected away from the expected problem-list page.');
  const parsedProblems=(parsed.problems||[]).map(problem=>({...problem,group:entry.groupName||'Public'}));
  const changed=await upsertDiscoveredProblems(parsedProblems);
  ensureBackgroundWorkActive(epoch);
  for (const next of parsed.pagination||[]) {
    const url=canonicalNZOIPage(next,entry.url);
    if (!url) continue;
    await discoveryQueuePage(state,{url,family:entry.family,familyBase:entry.familyBase,groupName:entry.groupName});
  }
  if (entry.family==='home') for (const group of parsed.groups||[]) {
    const baseUrl=backgroundGroupBase(group.href);
    if (baseUrl) await discoveryQueuePage(state,{url:baseUrl,family:'group',familyBase:baseUrl,groupName:group.name});
  }
  ensureBackgroundWorkActive(epoch);
  await queueBackgroundProblemWork(parsedProblems);
  await queueBackgroundBestAnswers(parsedProblems);
  return changed;
}
async function runProblemDiscoveryQueue() {
  if (discoveryDrain) return discoveryDrain;
  const epoch=backgroundWorkEpoch;
  discoveryDrain=(async()=>{
    let state=await backgroundWorkGet('state','active');
    if (!state||['complete','complete-with-errors','needs-login','failed'].includes(state.status)) return;
    state.status='running';
    const allPages=(await backgroundWorkAll('pages')).filter(page=>page.runId===state.runId);
    const staleBefore=Date.now()-90_000;
    for (const page of allPages) if (page.status==='working'&&Number(page.leaseAt||0)<staleBefore) {
      page.status='queued'; page.nextAttemptAt=0; await backgroundWorkPut('pages',page);
    }
    while (true) {
      const pages=(await backgroundWorkAll('pages')).filter(page=>page.runId===state.runId);
      const due=pages.filter(page=>page.status==='queued'&&(Number(page.nextAttemptAt)||0)<=Date.now())
        .sort((a,b)=>(a.createdAt||0)-(b.createdAt||0)).slice(0,DISCOVERY_PAGE_WORKERS);
      if (!due.length) {
        const waiting=pages.filter(page=>page.status==='queued'||page.status==='working');
        if (waiting.length) {
          const nextAt=Math.min(...waiting.map(page=>page.status==='working'?Date.now()+30_000:Number(page.nextAttemptAt)||0));
          state.status='running';
          await discoveryPublish(state,'Waiting to retry problem pages');
          discoverySchedule(Math.max(30_000,nextAt-Date.now()));
          return;
        }
        state.status=pages.some(page=>page.status==='failed')||state.limitHit?'complete-with-errors':'complete';
        await discoveryPublish(state,state.status==='complete'?'Found all available problems':'Some problem pages need attention');
        chrome.alarms.clear(DISCOVERY_ALARM);
        void runBackgroundProblemWork();
        return;
      }
      for (const page of due) {
        page.status='working'; page.leaseAt=Date.now();
        await backgroundWorkPut('pages',page);
      }
      state.status='running';
      await discoveryPublish(state,'Finding problems');
      const outcomes=await Promise.allSettled(due.map(page=>processDiscoveryPage(page,state,epoch)));
      ensureBackgroundWorkActive(epoch);
      for (let index=0;index<due.length;index++) {
        const page=due[index],outcome=outcomes[index];
        if (outcome.status==='fulfilled') {
          page.status='done'; page.completedAt=Date.now(); page.lastError='';
          state.processedPages=(Number(state.processedPages)||0)+1;
          await backgroundWorkPut('pages',page);
          await discoveryPublish(state,'Finding problems',outcome.value);
        } else {
          const error=outcome.reason||new Error('Problem page fetch failed');
          page.attempts=(Number(page.attempts)||0)+1;
          page.lastError=String(error.message||error).slice(0,300);
          if (error.code==='nzoI_session_expired') {
            page.status='queued'; page.nextAttemptAt=0; state.status='needs-login'; state.lastError=page.lastError;
            await backgroundWorkPut('pages',page);
            await discoveryPublish(state,'Error',[],page.lastError);
            chrome.alarms.clear(DISCOVERY_ALARM);
            return;
          }
          if (page.attempts>=DISCOVERY_MAX_ATTEMPTS) page.status='failed';
          else {
            page.status='queued';
            page.nextAttemptAt=Date.now()+Math.max(Number(error.retryAfterMs)||0,Math.min(60*60_000,5_000*2**Math.min(page.attempts-1,8)));
          }
          await backgroundWorkPut('pages',page);
          ERR('Background problem page failed',{url:page.url,attempt:page.attempts,message:page.lastError,error});
          await discoveryPublish(state,'Retrying problem page');
        }
      }
      discoverySchedule(30_000);
    }
  })().catch(async error=>{
    if(error?.code==='background-work-cleared')return;
    ERR('Background problem discovery stopped:',error.message,error);
    const state=await backgroundWorkGet('state','active').catch(()=>null);
    if (state) { state.status='running'; state.lastError=String(error.message||error); await discoveryPublish(state,'Error',[],state.lastError); discoverySchedule(60_000); }
  }).finally(()=>{discoveryDrain=null;});
  return discoveryDrain;
}
async function recoverProblemDiscovery() {
  try {
    const state=await backgroundWorkGet('state','active');
    if (!state||['complete','complete-with-errors','needs-login','failed'].includes(state.status)) return;
    const pages=(await backgroundWorkAll('pages')).filter(page=>page.runId===state.runId);
    if (pages.some(page=>page.status==='queued'||page.status==='working')) {
      const earliest=Math.min(...pages.filter(page=>page.status==='queued').map(page=>Number(page.nextAttemptAt)||0),Date.now());
      discoverySchedule(Math.max(0,earliest-Date.now()));
      if (!pages.some(page=>page.status==='working')) void runProblemDiscoveryQueue();
    }
  } catch(error) { ERR('Background problem discovery recovery failed:',error.message); }
}

function backgroundClassificationValid(value) {
  return Array.isArray(value?.tags)&&value.tags.length>0&&Number.isFinite(Number(value?.rating))&&Number(value.rating)>=500;
}
async function ensureBackgroundClassificationIndex() {
  const state=await backgroundWorkGet('state','active');
  if (!state||state.classificationIndexLoaded) return state?.knownClassificationIds||[];
  const {githubToken}=await store.get('githubToken');
  if (!githubToken) return state.knownClassificationIds||[];
  let ids=[];
  if (githubToken) {
    try {
      const classes=await loadClassificationsFromGist(githubToken);
      ids=Object.entries(classes||{}).filter(([key,value])=>/^nztags_\d+$/.test(key)&&backgroundClassificationValid(value))
        .map(([key])=>key.slice('nztags_'.length));
    } catch(error) { LOG('Background Gist classification index unavailable; local checks will be used:',error.message); }
  }
  state.knownClassificationIds=ids;
  state.classificationIndexLoaded=true;
  state.classificationIndexUpdatedAt=Date.now();
  await backgroundWorkPut('state',state);
  return ids;
}
async function queueBackgroundProblemWork(problems) {
  const incoming=[...new Map((problems||[]).map(problem=>[String(problem?.id||''),problem])
    .filter(([id,problem])=>/^\d+$/.test(id)&&canonicalNZOIPage(problem?.href))).values()];
  if(!incoming.length)return {queued:0};
  const discovery=await backgroundWorkGet('state','active');
  const runId=discovery?.runId||'';
  const oldRows=await backgroundWorkGetMany('problemTasks',incoming.map(problem=>String(problem.id)));
  const oldById=new Map(oldRows.map(row=>[String(row.id),row]));
  const writes=[];
  let queued=0;
  for (const problem of incoming) {
    const id=String(problem.id),old=oldById.get(id);
    if(old&&['queued','working','ready','classificationQueued'].includes(old.status))continue;
    if(old?.status==='complete'&&Number(old.parsed?.parserVersion)>=8)continue;
    if(old?.status==='failed'&&old.runId===runId&&Number(old.attempts)>=DISCOVERY_MAX_ATTEMPTS)continue;
    writes.push({...(old||{}),id,problem:{...problem,id},status:'queued',attempts:0,nextAttemptAt:0,
      classificationRequested:true,runId,createdAt:Date.now(),lastError:''});
    queued++;
  }
  await backgroundWorkPutMany('problemTasks',writes);
  if (queued) {
    chrome.alarms.create(PROBLEM_WORK_ALARM,{delayInMinutes:0.5});
    void runBackgroundProblemWork();
  }
  return {queued};
}
function sanitizeBackgroundQuestion(value) {
  return String(value||'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ')
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g,'')
    .split('\n').map(line=>line.replace(/[ \t]+$/g,'')).join('\n').replace(/\n{4,}/g,'\n\n\n').trim();
}
async function backgroundBuildClassifierMessages(tasks) {
  const settings=await store.get(['classifierPromptTemplate']);
  const candidate=settings.classifierPromptTemplate;
  const template=typeof candidate==='string'&&candidate.trim()&&['{{TEXT}}','{{TAGS}}','{{PREVIOUS}}'].every(token=>candidate.includes(token))
    ? candidate
    : 'Classify each competitive-programming problem from its statement and constraints. Use the supplied tags. Return the required JSON fields for each item.\n\nAllowed tags: {{TAGS}}\nPrevious classification: {{PREVIOUS}}\nTitle: {{TITLE}}\nURL: {{URL}}\nStatement: {{TEXT}}';
  const replacements={TAGS:[...CLASSIFIER_TAGS].join(', '),PREVIOUS:'Use each item.previous_classification.',
    TITLE:'Use each item.title.',URL:'Use each item.url.',TEXT:'Use each item.problem_text.'};
  const policy=template.replace(/\{\{(TAGS|PREVIOUS|TITLE|URL|TEXT)\}\}/g,(_,key)=>replacements[key]);
  const perItemCharBudget=Math.max(16_000,Math.floor((64_000-12_000)/Math.max(1,tasks.length))*4);
  const payload=tasks.map(task=>({
    batch_id:String(task.id),title:task.problem?.name||'',url:task.problem?.href||'',
    previous_classification:task.previous?{difficulty:task.previous.difficulty,rating:task.previous.rating,tags:task.previous.tags,
      confidence:task.previous.confidence,provider:task.previous.source_provider||task.previous.classifiedBy,model:task.previous.source_model}:null,
    problem_text:String(task.parsed?.text||'').slice(0,perItemCharBudget),
  }));
  return [
    {role:'system',content:[
      'You are the sole competitive-programming classifier for NZOI Training. Return only valid JSON with one result per input item.',
      'Do not provide a solution, walkthrough, pseudocode, or code. Inspect constraints carefully.',
      'Difficulty enum: beginner, easy, medium, hard, very_hard, hardcore, olympiad_hard.',
      'Ratings are 500–3000, rounded to nearest 100. Reserve 500 for direct I/O without problem-specific computation; 600–700 trivial; 800–900 easy; 1000–1500 medium; 1600–1700 difficult; 1800–2100 very hard; 2200–3000 IOI-level.',
      'A required observation, branch, loop, simulation, or case handling scores at least 900. Use tags from the provided allowed tag list.',
      'Keep reasoning_summary brief and high-level; do not reveal hidden reasoning.',
    ].join('\n')},
    {role:'user',content:[
      'Classify every input item independently. Return only {"results":[...]}, with exactly one result per item and batch_id copied exactly.',
      'Policy/template:',policy,'Input items JSON:',JSON.stringify(payload),
      'Each result requires batch_id, difficulty, estimated_rating, primary_skill, skills, reasoning_summary, risk_of_misclassification, confidence.',
    ].join('\n')},
  ];
}
let backgroundClassificationEnqueue=null;
async function enqueueReadyBackgroundClassifications() {
  if(backgroundClassificationEnqueue)return backgroundClassificationEnqueue;
  backgroundClassificationEnqueue=enqueueReadyBackgroundClassificationsOnce().finally(()=>{backgroundClassificationEnqueue=null;});
  return backgroundClassificationEnqueue;
}
async function enqueueReadyBackgroundClassificationsOnce() {
  const tasks=(await backgroundWorkAll('problemTasks')).filter(task=>task.status==='ready'&&task.classificationRequested!==false);
  if (!tasks.length) return 0;
  const settings=await store.get(['googleKeys','googleKey','geminiKey','googleModels','googleModel']);
  const provider=classifierProviderSettings(settings);
  if (!provider.keys.length||!provider.models.length) return 0;
  await ensureBackgroundClassificationIndex();
  const discovery=await backgroundWorkGet('state','active');
  const allProblemTasks=await backgroundWorkAll('problemTasks');
  const parsePending=allProblemTasks.some(task=>['queued','working'].includes(task.status));
  const scanPending=discovery&&['queued','running'].includes(discovery.status);
  const batchCount=tasks.length>=CLASSIFIER_MAX_BATCH_ITEMS?CLASSIFIER_MAX_BATCH_ITEMS:
    (!parsePending&&!scanPending?tasks.length:0);
  if (!batchCount) return 0;
  const batch=tasks.slice(0,batchCount);
  const ids=batch.map(task=>String(task.id));
  const local=await store.get(ids.map(id=>`nztags_${id}`));
  const classifierTasks=await store.get(ids.map(id=>`nzoiClassifierTask_${id}`));
  const known=new Set((discovery?.knownClassificationIds||[]).map(String));
  const classify=[];
  for (const task of batch) {
    const existing=local[`nztags_${task.id}`];
    const queuedClassifier=classifierTasks[`nzoiClassifierTask_${task.id}`];
    if (backgroundClassificationValid(existing)||known.has(String(task.id))) {
      task.status='complete';task.classificationSkipped='existing classification';
      await backgroundWorkPut('problemTasks',task);
      continue;
    }
    if(['queued','running'].includes(queuedClassifier?.status)){
      task.status='classificationQueued';task.classificationQueuedAt=queuedClassifier.updatedAt||Date.now();
      await backgroundWorkPut('problemTasks',task);
      continue;
    }
    task.previous=existing||null;
    classify.push(task);
  }
  if (!classify.length) return batch.length;
  const messages=await backgroundBuildClassifierMessages(classify);
  const runId=`background-${discovery?.runId||Date.now().toString(36)}`;
  const jobId=`nzoi-bg-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`;
  const items=classify.map(task=>({id:String(task.id),prob:{id:String(task.id),name:task.problem?.name||'',href:task.problem?.href||''},
    cacheMeta:{question_parser_version:Number(task.parsed?.parserVersion)||7}}));
  await enqueueClassifierJobs([{id:jobId,items,messages,runId}],runId);
  for (const task of classify) {
    const latest=await backgroundWorkGet('problemTasks',String(task.id));
    if(latest?.status==='ready'){
      latest.status='classificationQueued';latest.classificationQueuedAt=Date.now();
      await backgroundWorkPut('problemTasks',latest);
    }
  }
  return batch.length;
}
async function processBackgroundProblemTask(task,epoch=backgroundWorkEpoch) {
  const problem=task.problem||{};
  const parsed=await fetchNZOIParsedPage(problem.href,'question');
  ensureBackgroundWorkActive(epoch);
  const text=sanitizeBackgroundQuestion(parsed.text);
  if (!text) throw new Error(`Problem ${task.id} returned no readable statement.`);
  const statement={
    id:String(task.id),parserVersion:8,title:problem.name||parsed.title||'',url:problem.href||parsed.pageUrl||'',
    resolvedUrl:parsed.pageUrl||problem.href||'',group:problem.group||'',progress:Number(problem.progress)||0,
    sourceType:parsed.sourceType||'html',contentType:parsed.contentType||'text/html',pdfLinks:Array.isArray(parsed.pdfLinks)?parsed.pdfLinks:[],
    capturedAt:new Date().toISOString(),fetchError:'',text,extractionMode:'parser-only',
  };
  ensureBackgroundWorkActive(epoch);
  await enqueueQuestionArchiveRecords([statement]);
  ensureBackgroundWorkActive(epoch);
  const existing=await store.get(`nztags_${task.id}`);
  ensureBackgroundWorkActive(epoch);
  const updated={...task,problem:{...problem,id:String(task.id)},parsed:{...statement,parserVersion:8},
    previous:existing[`nztags_${task.id}`]||null,status:'ready',parsedAt:Date.now(),lastError:''};
  await backgroundWorkPut('problemTasks',updated);
  return updated;
}
async function publishBackgroundProblemWork(activity='Processing discovered questions',lastError='') {
  const tasks=await backgroundWorkAll('problemTasks');
  const queued=tasks.filter(task=>task.status==='queued'||task.status==='working').length;
  const ready=tasks.filter(task=>task.status==='ready').length;
  const classificationQueued=tasks.filter(task=>task.status==='classificationQueued').length;
  await store.set({[PROBLEM_WORK_STATUS_KEY]:{activity,queued,ready,classificationQueued,
    completed:tasks.filter(task=>task.status==='complete').length,failed:tasks.filter(task=>task.status==='failed').length,
    lastError:String(lastError||''),updatedAt:Date.now()}});
}
async function runBackgroundProblemWork() {
  if (problemWorkDrain) return problemWorkDrain;
  const epoch=backgroundWorkEpoch;
  problemWorkDrain=(async()=>{
    let tasks=(await backgroundWorkAll('problemTasks')).filter(task=>task.status==='queued'||task.status==='working');
    for (const task of tasks) if (task.status==='working'&&Date.now()-Number(task.leaseAt||0)>90_000) {
      task.status='queued';task.nextAttemptAt=0;await backgroundWorkPut('problemTasks',task);
    }
    while (true) {
      tasks=(await backgroundWorkAll('problemTasks')).filter(task=>task.status==='queued'&&(Number(task.nextAttemptAt)||0)<=Date.now())
        .sort((a,b)=>(a.createdAt||0)-(b.createdAt||0)).slice(0,4);
      if (!tasks.length) break;
      for (const task of tasks) { task.status='working';task.leaseAt=Date.now();await backgroundWorkPut('problemTasks',task); }
      await publishBackgroundProblemWork('Parsing questions');
      const results=await Promise.allSettled(tasks.map(task=>processBackgroundProblemTask(task,epoch)));
      ensureBackgroundWorkActive(epoch);
      for (let index=0;index<tasks.length;index++) {
        const task=tasks[index],result=results[index];
        if (result.status==='fulfilled') continue;
        const error=result.reason||new Error('Problem statement parsing failed');
        task.attempts=(Number(task.attempts)||0)+1;task.lastError=String(error.message||error).slice(0,300);
        if (error.code==='nzoI_session_expired') {
          task.status='queued';task.nextAttemptAt=Date.now()+10*60_000;
        } else if (task.attempts>=DISCOVERY_MAX_ATTEMPTS) task.status='failed';
        else { task.status='queued';task.nextAttemptAt=Date.now()+Math.min(60*60_000,5_000*2**Math.min(task.attempts-1,8)); }
        await backgroundWorkPut('problemTasks',task);
        ERR('Background question parsing failed',{problemId:task.id,attempt:task.attempts,message:task.lastError,error});
      }
      await enqueueReadyBackgroundClassifications();
      await publishBackgroundProblemWork('Saving parsed questions');
      chrome.alarms.create(PROBLEM_WORK_ALARM,{delayInMinutes:0.5});
    }
    await enqueueReadyBackgroundClassifications();
    const pending=(await backgroundWorkAll('problemTasks')).some(task=>task.status==='queued'||task.status==='working');
    if (pending) {
      const waiting=(await backgroundWorkAll('problemTasks')).filter(task=>task.status==='queued');
      const nextAt=Math.min(...waiting.map(task=>Number(task.nextAttemptAt)||0),Date.now()+30_000);
      chrome.alarms.create(PROBLEM_WORK_ALARM,{delayInMinutes:Math.max(0.5,(nextAt-Date.now())/60_000)});
    } else {
      chrome.alarms.clear(PROBLEM_WORK_ALARM);
      const finalTasks=await backgroundWorkAll('problemTasks');
      const waitingForModel=finalTasks.some(task=>task.status==='ready');
      const settings=await store.get(['googleKeys','googleKey','geminiKey','googleModels','googleModel']);
      const provider=classifierProviderSettings(settings);
      await publishBackgroundProblemWork(waitingForModel&&(!provider.keys.length||!provider.models.length)
        ? 'Waiting for Gemini API key':'Background question processing complete');
    }
  })().catch(error=>{
    if(error?.code==='background-work-cleared')return;
    ERR('Background question processing stopped:',error.message,error);
    chrome.alarms.create(PROBLEM_WORK_ALARM,{delayInMinutes:1});
  }).finally(()=>{problemWorkDrain=null;});
  return problemWorkDrain;
}
async function recoverBackgroundProblemWork() {
  try {
    const tasks=await backgroundWorkAll('problemTasks');
    const reconcile=tasks.filter(task=>task.status==='classificationQueued');
    if(reconcile.length){
      const keys=reconcile.flatMap(task=>[`nztags_${task.id}`,`nzoiClassifierTask_${task.id}`]);
      const saved=await store.get(keys);
      for(const task of reconcile){
        if(backgroundClassificationValid(saved[`nztags_${task.id}`])){task.status='complete';task.classificationCompletedAt=Date.now();}
        else if(['queued','running'].includes(saved[`nzoiClassifierTask_${task.id}`]?.status))continue;
        else task.status='ready';
        await backgroundWorkPut('problemTasks',task);
      }
    }
    if (tasks.some(task=>['queued','working','ready','classificationQueued'].includes(task.status))) {
      chrome.alarms.create(PROBLEM_WORK_ALARM,{delayInMinutes:0.5});
      void runBackgroundProblemWork();
    }
  } catch(error) { ERR('Background question work recovery failed:',error.message); }
}

async function publishBestAnswerProgress(activity='Checking completed problems',lastError='') {
  const tasks=await backgroundWorkAll('answerTasks');
  const pending=tasks.filter(task=>['queued','working'].includes(task.status));
  const done=tasks.filter(task=>task.status==='done');
  const failed=tasks.filter(task=>task.status==='failed');
  const status=lastError==='needs-token'?'needs-token':pending.length?'scanning':failed.length?'complete-with-errors':'complete';
  const problem=pending[0]?.problem||tasks.at(-1)?.problem||null;
  await store.set({[BEST_ANSWER_STATUS_KEY]:{
    total:tasks.length,completed:done.length+failed.length,saved:done.length,failed:failed.length,
    status,activity,lastProblem:problem?`${problem.id} · ${problem.name||''}`:'',
    pending:pending.length,lastError:lastError==='needs-token'?'Add a GitHub token to save best answers to Gist.':String(lastError||''),updatedAt:Date.now(),
  }});
}
function bestAnswerSchedule(delay=30_000) {
  chrome.alarms.create(BEST_ANSWER_ALARM,{delayInMinutes:Math.max(0.5,delay/60_000)});
}
async function queueBackgroundBestAnswers(problems) {
  const incoming=[...new Map((problems||[]).map(raw=>[String(raw?.id||''),raw])
    .filter(([id,raw])=>/^\d+$/.test(id)&&(Number(raw?.progress)||0)>0&&canonicalNZOIPage(raw?.href))).values()];
  if(!incoming.length)return {queued:0};
  const discovery=await backgroundWorkGet('state','active');
  const runId=discovery?.runId||'';
  const [oldRows,savedRows]=await Promise.all([
    backgroundWorkGetMany('answerTasks',incoming.map(raw=>String(raw.id))),
    store.get(incoming.map(raw=>`nzoiBestSubmission_${raw.id}`)),
  ]);
  const oldById=new Map(oldRows.map(row=>[String(row.id),row]));
  const writes=[];
  let queued=0;
  for(const raw of incoming){
    const id=String(raw?.id||''),progress=Number(raw?.progress)||0,href=canonicalNZOIPage(raw?.href);
    if(!/^\d+$/.test(id)||progress<=0||!href)continue;
    const problem={...raw,id,href,progress};
    const old=oldById.get(id),record=savedRows[`nzoiBestSubmission_${id}`];
    if(Number(old?.checkedProgress)>=progress&&old?.status==='done')continue;
    if(record?.status==='saved'&&Number(old?.checkedProgress||record.progress||0)>=progress){
      if(!old||old.status!=='done')writes.push({...(old||{}),id,problem,checkedProgress:progress,status:'done',savedAt:record.syncedAt||Date.now()});
      continue;
    }
    if(old&&['queued','working'].includes(old.status)){
      old.problem={...(old.problem||{}),...problem,progress:Math.max(Number(old.problem?.progress)||0,progress)};
      old.checkedProgress=Math.max(Number(old.checkedProgress)||0,progress);
      writes.push(old);
      continue;
    }
    if(old?.status==='failed'&&old.runId===runId&&Number(old.attempts)>=DISCOVERY_MAX_ATTEMPTS)continue;
    const retry=old?.status==='failed';
    writes.push({
      ...(old||{}),id,problem,runId,checkedProgress:progress,status:'queued',attempts:retry?0:Number(old?.attempts)||0,
      nextAttemptAt:0,createdAt:Date.now(),lastError:'',
      listingCandidates:[],candidateIndex:0,listingQueue:[],listingVisited:[],entries:[],detailIndex:0,best:null,
    });
    queued++;
  }
  await backgroundWorkPutMany('answerTasks',writes);
  if(queued){await publishBestAnswerProgress('Checking completed problems');bestAnswerSchedule(0);void runBestAnswerQueue();}
  return {queued};
}
function backgroundSubmissionCandidates(problem) {
  const origin='https://train.nzoi.org.nz';
  return [...new Set([
    problem.href,
    `${origin}/problems/${problem.id}/submissions`,
    `${origin}/problems/${problem.id}/solutions`,
    `${origin}/submissions?problem_id=${encodeURIComponent(problem.id)}`,
    `${origin}/submissions?problem=${encodeURIComponent(problem.id)}`,
  ].map(value=>canonicalNZOIPage(value)).filter(Boolean))];
}
function mergeBackgroundSubmissionEntries(task,entries) {
  const byId=new Map((task.entries||[]).map(entry=>[String(entry.id),entry]));
  for(const entry of entries||[]){
    const id=String(entry?.id||'');if(!/^\d+$/.test(id))continue;
    const prior=byId.get(id);
    if(!prior||(entry.score!=null&&(prior.score==null||Number(entry.score)>Number(prior.score))))byId.set(id,{...entry,id});
  }
  task.entries=[...byId.values()];
}
async function fetchBackgroundSubmissionList(url,problemId) {
  return fetchNZOIParsedPage(url,'submission-list',problemId);
}
async function fetchBackgroundSubmissionDetail(url,problemId) {
  return fetchNZOIParsedPage(url,'submission-detail',problemId);
}
async function processBestAnswerTask(task,epoch=backgroundWorkEpoch) {
  ensureBackgroundWorkActive(epoch);
  const {githubToken}=await store.get('githubToken');
  if(!githubToken){const error=new Error('GitHub token is missing.');error.code='needs-token';throw error;}
  const problem=task.problem||{};
  if(!task.listingCandidates?.length){task.listingCandidates=backgroundSubmissionCandidates(problem);task.candidateIndex=0;}
  if(!task.listingQueue?.length&&!task.entries?.length){
    while(Number(task.candidateIndex||0)<task.listingCandidates.length){
      const candidate=task.listingCandidates[task.candidateIndex++];
      let page;
      try{page=await fetchBackgroundSubmissionList(candidate,task.id);ensureBackgroundWorkActive(epoch);}
      catch(error){
        if(error?.code==='background-work-cleared')throw error;
        if([404,410].includes(Number(error.status))){await backgroundWorkPut('answerTasks',task);continue;}
        throw error;
      }
      mergeBackgroundSubmissionEntries(task,page.entries);
      const canonical=canonicalNZOIPage(page.pageUrl||candidate,candidate);
      if(task.entries.length){
        task.listingBase=canonical;task.listingVisited=[canonical];
        task.listingQueue=(page.pagination||[]).map(value=>canonicalNZOIPage(value,candidate)).filter(Boolean);
        await backgroundWorkPut('answerTasks',task);
        break;
      }
      await backgroundWorkPut('answerTasks',task);
    }
    if(!task.entries.length){const error=new Error(`No submission history was found for problem ${task.id} after checking every listing route.`);error.permanent=true;throw error;}
  }
  const pageLimit=500;
  while((task.listingQueue||[]).length&&(task.listingVisited||[]).length<pageLimit){
    const next=task.listingQueue.shift();
    if((task.listingVisited||[]).includes(next))continue;
    task.listingVisited.push(next);
    const page=await fetchBackgroundSubmissionList(next,task.id);
    ensureBackgroundWorkActive(epoch);
    mergeBackgroundSubmissionEntries(task,page.entries);
    for(const value of page.pagination||[]){
      const url=canonicalNZOIPage(value,next);
      if(url&&!task.listingVisited.includes(url)&&!task.listingQueue.includes(url))task.listingQueue.push(url);
    }
    await backgroundWorkPut('answerTasks',task);
  }
  if(task.listingQueue?.length){const error=new Error(`Submission history for problem ${task.id} exceeded the ${pageLimit}-page safety limit.`);error.permanent=true;throw error;}
  const allScoresKnown=task.entries.length>0&&task.entries.every(entry=>entry.score!=null);
  let candidates=[...task.entries];
  if(allScoresKnown){const high=Math.max(...candidates.map(entry=>Number(entry.score)));candidates=candidates.filter(entry=>Number(entry.score)===high);}
  candidates.sort((a,b)=>{
    if(allScoresKnown&&Number(a.score)!==Number(b.score))return Number(b.score)-Number(a.score);
    return Number(b.id)-Number(a.id);
  });
  if(Number(task.detailIndex||0)>candidates.length)task.detailIndex=0;
  while(Number(task.detailIndex||0)<candidates.length){
    const entry=candidates[Number(task.detailIndex)||0];
    const detail=await fetchBackgroundSubmissionDetail(entry.href,task.id);
    ensureBackgroundWorkActive(epoch);
    const source=String(detail.source||'');
    if(source.trim()){
      const score=detail.score==null?entry.score:detail.score;
      const candidate={...entry,score,source,language:detail.language,url:detail.pageUrl||entry.href};
      const previous=task.best;
      const scoreValue=value=>value?.score==null?Number(problem.progress)||0:Number(value.score);
      if(!previous||scoreValue(candidate)>scoreValue(previous)||(scoreValue(candidate)===scoreValue(previous)&&Number(candidate.id)>Number(previous.id)))task.best=candidate;
    }
    task.detailIndex=(Number(task.detailIndex)||0)+1;
    await backgroundWorkPut('answerTasks',task);
    if(allScoresKnown&&task.best&&task.detailIndex>=candidates.length)break;
  }
  if(!task.best)throw new Error(`No submission source was readable for problem ${task.id}.`);
  const extension=({cpp:'cpp',python:'py',java:'java'})[task.best.language];
  if(!extension){const error=new Error(`Unsupported highest-submission language (${task.best.language||'unknown'}) for problem ${task.id}.`);error.permanent=true;throw error;}
  const latest=await backgroundWorkGet('answerTasks',String(task.id));
  const newestProgress=Math.max(Number(problem.progress)||0,Number(latest?.problem?.progress)||0,Number(latest?.checkedProgress)||0);
  if(newestProgress>(Number(problem.progress)||0)){
    const restarted={...(latest||task),problem:{...(problem||{}),...(latest?.problem||{}),progress:newestProgress},
      checkedProgress:newestProgress,status:'queued',attempts:0,nextAttemptAt:0,
      listingCandidates:[],candidateIndex:0,listingQueue:[],listingVisited:[],entries:[],detailIndex:0,best:null,lastError:''};
    await backgroundWorkPut('answerTasks',restarted);
    LOG('A higher problem completion percentage appeared during the scan; restarting its highest-answer check',{problemId:task.id,progress:newestProgress});
    return restarted;
  }
  const filename=`NZOI_${task.id}__highest-answer.${extension}`;
  const legacyJsonFilename=`NZOI_${task.id}__highest-answer.json`;
  const key=`nzoiBestSubmission_${task.id}`;
  const previous=(await store.get(key))[key];
  const unchanged=previous?.submissionId===String(task.best.id)&&previous?.filename===filename&&Number(previous.score)===Number(task.best.score);
  if(!unchanged)await saveFileToGist(githubToken,filename,task.best.source);
  ensureBackgroundWorkActive(epoch);
  if(previous?.filename===legacyJsonFilename||previous?.legacyJsonFilename===legacyJsonFilename){
    try{await deleteGeneratedHighestAnswerJson(githubToken,task.id);}catch(error){task.legacyJsonFilename=legacyJsonFilename;LOG(`Saved ${filename}; old generated JSON cleanup will retry:`,error.message);}
  }
  const record={status:'saved',submissionId:String(task.best.id),score:task.best.score==null?Number(problem.progress)||0:task.best.score,
    language:task.best.language,filename,progress:newestProgress,syncedAt:Date.now(),...(task.legacyJsonFilename?{legacyJsonFilename:task.legacyJsonFilename}:{})};
  await store.set({[key]:record});
  task.best={id:String(task.best.id),score:task.best.score,language:task.best.language,url:task.best.url};
  task.entries=[];task.listingCandidates=[];task.listingQueue=[];
  task.status='done';task.checkedProgress=Math.max(Number(task.checkedProgress)||0,Number(problem.progress)||0);task.completedAt=Date.now();task.lastError='';
  await backgroundWorkPut('answerTasks',task);
  return task;
}
async function runBestAnswerQueue() {
  if(bestAnswerDrain)return bestAnswerDrain;
  const epoch=backgroundWorkEpoch;
  bestAnswerDrain=(async()=>{
    const {githubToken}=await store.get('githubToken');
    const all=await backgroundWorkAll('answerTasks');
    if(!all.some(task=>['queued','working'].includes(task.status))){chrome.alarms.clear(BEST_ANSWER_ALARM);await publishBestAnswerProgress('Best answers up to date');return;}
    if(!githubToken){await publishBestAnswerProgress('Waiting for GitHub token','needs-token');bestAnswerSchedule(5*60_000);return;}
    for(const task of all)if(task.status==='working'&&Date.now()-Number(task.leaseAt||0)>90_000){task.status='queued';task.nextAttemptAt=0;await backgroundWorkPut('answerTasks',task);}
    const due=(await backgroundWorkAll('answerTasks')).filter(task=>task.status==='queued'&&(Number(task.nextAttemptAt)||0)<=Date.now())
      .sort((a,b)=>(a.createdAt||0)-(b.createdAt||0)).slice(0,2);
    if(!due.length){const waiting=(await backgroundWorkAll('answerTasks')).filter(task=>task.status==='queued');
      const nextAt=Math.min(...waiting.map(task=>Number(task.nextAttemptAt)||0),Date.now()+30_000);await publishBestAnswerProgress('Waiting to retry best answers');bestAnswerSchedule(Math.max(30_000,nextAt-Date.now()));return;}
    for(const task of due){task.status='working';task.leaseAt=Date.now();await backgroundWorkPut('answerTasks',task);}
    await publishBestAnswerProgress('Checking highest submissions');
    const results=await Promise.allSettled(due.map(task=>processBestAnswerTask(task,epoch)));
    ensureBackgroundWorkActive(epoch);
    for(let index=0;index<due.length;index++){
      const task=due[index],result=results[index];if(result.status==='fulfilled')continue;
      const latest=await backgroundWorkGet('answerTasks',String(task.id));
      if(latest){
        const problem={...(task.problem||{}),...(latest.problem||{}),progress:Math.max(Number(task.problem?.progress)||0,Number(latest.problem?.progress)||0)};
        Object.assign(task,latest,{problem});
      }
      const error=result.reason||new Error('Best answer archive failed');task.lastError=String(error.message||error).slice(0,300);
      if(error.code==='needs-token'){task.status='queued';task.nextAttemptAt=Date.now()+5*60_000;}
      else if(error.code==='nzoI_session_expired'){task.status='queued';task.nextAttemptAt=Date.now()+10*60_000;}
      else if(error.permanent||Number(error.status)===404||Number(error.status)===410||Number(task.attempts||0)+1>=DISCOVERY_MAX_ATTEMPTS){task.status='failed';task.attempts=(Number(task.attempts)||0)+1;}
      else{task.status='queued';task.attempts=(Number(task.attempts)||0)+1;task.nextAttemptAt=Date.now()+Math.max(Number(error.retryAfterMs)||0,Math.min(60*60_000,5_000*2**Math.min(task.attempts-1,8)));}
      await backgroundWorkPut('answerTasks',task);ERR('Background best-answer archive failed',{problemId:task.id,attempt:task.attempts,message:task.lastError,error});
    }
    const remaining=(await backgroundWorkAll('answerTasks')).filter(task=>['queued','working'].includes(task.status));
    if(remaining.length){const queued=remaining.filter(task=>task.status==='queued');const nextAt=Math.min(...queued.map(task=>Number(task.nextAttemptAt)||0),Date.now()+30_000);bestAnswerSchedule(Math.max(30_000,nextAt-Date.now()));}
    else chrome.alarms.clear(BEST_ANSWER_ALARM);
    await publishBestAnswerProgress(remaining.length?'Checking highest submissions':'Best answers up to date');
    if(remaining.some(task=>task.status==='queued'&&(Number(task.nextAttemptAt)||0)<=Date.now()))setTimeout(()=>void runBestAnswerQueue(),0);
  })().catch(error=>{if(error?.code==='background-work-cleared')return;ERR('Background best-answer queue stopped:',error.message,error);bestAnswerSchedule(60_000);})
    .finally(()=>{bestAnswerDrain=null;});
  return bestAnswerDrain;
}
async function recoverBackgroundBestAnswers() {
  try{const tasks=await backgroundWorkAll('answerTasks');if(tasks.some(task=>['queued','working'].includes(task.status))){bestAnswerSchedule(30_000);void runBestAnswerQueue();}}
  catch(error){ERR('Background best-answer recovery failed:',error.message);}
}

function backgroundWorkCount(storeName,statuses) {
  return backgroundWorkAll(storeName).then(items=>items.filter(item=>statuses.includes(item.status)).length);
}

function classifierDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(CLASSIFIER_DB, 1);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains('batches')) request.result.createObjectStore('batches', { keyPath:'id' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Could not open the background queue'));
  });
}
async function classifierBatches() {
  const db = await classifierDB();
  try { return await new Promise((resolve, reject) => {
    const req = db.transaction('batches', 'readonly').objectStore('batches').getAll();
    req.onsuccess = () => resolve(req.result || []); req.onerror = () => reject(req.error);
  }); } finally { db.close(); }
}
async function classifierBatchCount() {
  const db = await classifierDB();
  try { return await new Promise((resolve, reject) => {
    const req = db.transaction('batches', 'readonly').objectStore('batches').count();
    req.onsuccess = () => resolve(Number(req.result) || 0); req.onerror = () => reject(req.error);
  }); } finally { db.close(); }
}
async function classifierSave(job, remove=false) {
  const db = await classifierDB();
  try { await new Promise((resolve, reject) => {
    const store = db.transaction('batches', 'readwrite').objectStore('batches');
    const req = remove ? store.delete(job.id) : store.put(job);
    req.onsuccess = () => resolve(); req.onerror = () => reject(req.error);
  }); } finally { db.close(); }
}
async function classifierClear() {
  const db=await classifierDB();
  try { await new Promise((resolve,reject)=>{
    const req=db.transaction('batches','readwrite').objectStore('batches').clear();
    req.onsuccess=()=>resolve(); req.onerror=()=>reject(req.error);
  }); } finally { db.close(); }
  chrome.alarms.clear(CLASSIFIER_ALARM);
}
async function classifierJobExists(id) {
  return (await classifierBatches()).some(job=>job.id===id);
}
async function classifierSetProgress(patch, reset=false) {
  const saved = (await store.get('nzoiClassifierProgress')).nzoiClassifierProgress || {};
  const base = reset ? { total:0, completed:0, googleCompleted:0, failed:0 } : saved;
  const progress = { ...base, ...patch, updatedAt:Date.now() };
  await store.set({ nzoiClassifierProgress:progress });
  return progress;
}
function classifierSchedule(delay=30_000) {
  chrome.alarms.create(CLASSIFIER_ALARM, { delayInMinutes:Math.max(0.5, delay / 60_000) });
}
function questionArchiveSchedule(delay=30_000) {
  chrome.alarms.create(QUESTION_ALARM, { delayInMinutes:Math.max(0.5, delay / 60_000) });
}
function questionQueueDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(QUESTION_DB, 1);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains('records')) request.result.createObjectStore('records', { keyPath:'id' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Could not open the question archive queue'));
  });
}
async function questionQueueRecords() {
  const db = await questionQueueDB();
  try { return await new Promise((resolve, reject) => {
    const req = db.transaction('records', 'readonly').objectStore('records').getAll();
    req.onsuccess = () => resolve(req.result || []); req.onerror = () => reject(req.error);
  }); } finally { db.close(); }
}
async function questionQueueCount() {
  const db = await questionQueueDB();
  try { return await new Promise((resolve, reject) => {
    const req = db.transaction('records', 'readonly').objectStore('records').count();
    req.onsuccess = () => resolve(Number(req.result) || 0); req.onerror = () => reject(req.error);
  }); } finally { db.close(); }
}
async function questionQueueSave(record, remove=false) {
  const db = await questionQueueDB();
  try { await new Promise((resolve, reject) => {
    const records = db.transaction('records', 'readwrite').objectStore('records');
    const req = remove ? records.delete(String(record.id)) : records.put(record);
    req.onsuccess = () => resolve(); req.onerror = () => reject(req.error);
  }); } finally { db.close(); }
}
async function questionQueueClear() {
  const db = await questionQueueDB();
  try { await new Promise((resolve, reject) => {
    const req = db.transaction('records', 'readwrite').objectStore('records').clear();
    req.onsuccess = () => resolve(); req.onerror = () => reject(req.error);
  }); } finally { db.close(); }
}
async function enqueueQuestionArchiveRecords(incoming) {
  let queued = 0;
  const existingRecords = await questionQueueRecords();
  const byId = new Map(existingRecords.map(item => [String(item.id), item]));
  for (const value of Array.isArray(incoming) ? incoming : []) {
    const id = String(value?.id || '').trim();
    if (!/^\d+$/.test(id) || !String(value?.text || '').trim()) continue;
    const existing = byId.get(id);
    const record = { ...value, id };
    if (existing && Number(existing.parserVersion || 0) > Number(record.parserVersion || 0)) continue;
    const queuedRecord={ id, record, attempts:existing?.attempts || 0, nextAttemptAt:existing?.nextAttemptAt || 0 };
    await questionQueueSave(queuedRecord); byId.set(id,queuedRecord);
    queued++;
  }
  const pending=byId.size;
  await store.set({nzoiQuestionArchiveQueueStatus:{pending, lastError:'',activity:pending?'Saving questions to Gist':'Question statements saved to Gist',updatedAt:Date.now()}});
  if (queued) { questionArchiveSchedule(0); void runQuestionArchiveQueue(); }
  return { queued, pending };
}
async function runQuestionArchiveQueue() {
  if (questionArchiveDrain) return questionArchiveDrain;
  questionArchiveDrain = (async () => {
    const records = (await questionQueueRecords()).sort((a,b)=>(a.nextAttemptAt||0)-(b.nextAttemptAt||0));
    if (!records.length) { chrome.alarms.clear(QUESTION_ALARM); return; }
    const due = records.filter(item => (Number(item.nextAttemptAt) || 0) <= Date.now()).slice(0, 10);
    if (!due.length) {
      await store.set({nzoiQuestionArchiveQueueStatus:{pending:records.length,lastError:'',activity:'Waiting for Gist',updatedAt:Date.now()}});
      questionArchiveSchedule(Math.max(30_000, Math.min(...records.map(item => item.nextAttemptAt - Date.now())))); return;
    }
    const { githubToken } = await store.get('githubToken');
    if (!githubToken) {
      await store.set({nzoiQuestionArchiveQueueStatus:{pending:records.length,lastError:'Add a GitHub token to sync pending question statements.',activity:'Error',updatedAt:Date.now()}});
      questionArchiveSchedule(5 * 60_000); return;
    }
    try {
      await store.set({nzoiQuestionArchiveQueueStatus:{pending:records.length,lastError:'',activity:'Saving questions to Gist',updatedAt:Date.now()}});
      await mergeQuestionsToGist(githubToken, due.map(item => item.record));
      for (const item of due) await questionQueueSave(item, true);
      const remaining = await questionQueueRecords();
      if (remaining.length) questionArchiveSchedule(0); else chrome.alarms.clear(QUESTION_ALARM);
      await store.set({ nzoiQuestionArchiveQueueStatus:{ pending:remaining.length, lastSuccessAt:Date.now(), lastError:'',activity:remaining.length?'Saving questions to Gist':'Question statements saved to Gist',updatedAt:Date.now() } });
    } catch (error) {
      const nextAttemptAt = Date.now() + Math.max(Number(error.retryAfterMs) || 0, Math.min(30 * 60_000, 15_000 * 2 ** Math.min(Math.max(...due.map(item => item.attempts || 0)), 6)));
      const attemptedIds=new Set(due.map(item=>String(item.id)));
      for (const item of records) await questionQueueSave({
        ...item,
        attempts:(item.attempts || 0)+(attemptedIds.has(String(item.id))?1:0),
        nextAttemptAt:Math.max(Number(item.nextAttemptAt)||0,nextAttemptAt),
        lastError:String(error.message || error).slice(0, 300),
      });
      await store.set({ nzoiQuestionArchiveQueueStatus:{ pending:records.length, nextAttemptAt, lastError:String(error.message || error).slice(0, 300),activity:'Error',updatedAt:Date.now() } });
      questionArchiveSchedule(nextAttemptAt - Date.now());
      (error.retryable ? LOG : ERR)('Question archive sync deferred:', error.message);
    }
  })().finally(() => {
    questionArchiveDrain = null;
    void questionQueueRecords().then(records=>{
      if (!records.length) return;
      const nextAt=Math.min(...records.map(item=>Number(item.nextAttemptAt)||0));
      const delay=Math.max(0,nextAt-Date.now());
      questionArchiveSchedule(delay);
      if (!delay) setTimeout(()=>void runQuestionArchiveQueue(),0);
    }).catch(error=>ERR('Could not reschedule question archive queue:',error.message));
  });
  return questionArchiveDrain;
}
async function recoverQuestionArchiveQueue() {
  try {
    const records=await questionQueueRecords();
    if (!records.length) return;
    const nextAt=Math.min(...records.map(item=>Number(item.nextAttemptAt)||0));
    const delay=Math.max(0,nextAt-Date.now());
    questionArchiveSchedule(delay);
    if (!delay) void runQuestionArchiveQueue();
  } catch(error) { ERR('Question archive queue recovery failed:',error.message); }
}
function parseClassifierJson(raw) {
  try { const parsed=JSON.parse(String(raw || '').trim().replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,''));
    return parsed && typeof parsed==='object' && !Array.isArray(parsed) ? parsed : null;
  } catch { return null; }
}
function classifierDifficultyFromRating(value) {
  const rating=classifierRound(value);
  if (rating<600) return 'beginner';
  if (rating<1000) return 'easy';
  if (rating<1600) return 'medium';
  if (rating<1800) return 'hard';
  if (rating<2200) return 'very_hard';
  if (rating<2600) return 'hardcore';
  return 'olympiad_hard';
}
function validClassifierResults(parsed, ids) {
  if (!Array.isArray(parsed?.results) || parsed.results.length !== ids.length) return null;
  const map=new Map();
  for (const raw of parsed.results) {
    const id=String(raw?.batch_id || ''), ratings=raw?.estimated_rating, confidence=Number(raw?.confidence);
    const difficulty=String(raw?.difficulty||'').toLowerCase();
    if (!ids.includes(id) || map.has(id) || !CLASSIFIER_DIFFS.includes(difficulty) ||
      !ratings || !['codeforces','atcoder','usaco','nzoi'].every(k=>Number.isFinite(Number(ratings[k]))&&Number(ratings[k])>=500&&Number(ratings[k])<=3000&&Number(ratings[k])%100===0) ||
      difficulty!==classifierDifficultyFromRating(ratings?.nzoi) ||
      typeof raw?.primary_skill!=='string' || !raw.primary_skill.trim() || !Array.isArray(raw?.skills) || !raw.skills.length ||
      typeof raw?.reasoning_summary!=='string' || !raw.reasoning_summary.trim() || !['low','medium','high'].includes(raw?.risk_of_misclassification) ||
      !Number.isFinite(confidence) || confidence<0 || confidence>1) return null;
    map.set(id,raw);
  }
  return map.size===ids.length ? map : null;
}
function classifierRound(value) { return Math.round(Math.max(500,Math.min(3000,Number(value)||500))/100)*100; }
function canonicalClassifierTag(value) {
  const original=String(value||'').trim().toLowerCase();
  if (CLASSIFIER_TAGS.has(original)) return original;
  const normalized=original.replace(/[_-]+/g,' ');
  if (CLASSIFIER_TAGS.has(normalized)) return normalized;
  const aliases={
    '2 sat':'2-satisfiability','2-sat':'2-satisfiability','dfs':'depth-first search and similar',
    'dsu':'disjoint set union','union find':'disjoint set union','dp':'dynamic programming',
    'implementation and simulation':'implementation','suffix structures':'string suffix structures',
    'meet in the middle':'meet-in-the-middle','io':'io','input output':'io',
  };
  return aliases[normalized]||'';
}
function normalizeBackgroundClassification(raw, item, model, provider='google') {
  const ratings=raw.estimated_rating || {}, base=classifierRound(ratings.codeforces || 1400);
  const estimated={ codeforces:classifierRound(ratings.codeforces||base), atcoder:classifierRound(ratings.atcoder||ratings.codeforces||base),
    usaco:classifierRound(ratings.usaco||ratings.codeforces||base), nzoi:classifierRound(ratings.nzoi||ratings.codeforces||base) };
  const skills=[raw.primary_skill,...raw.skills].map(canonicalClassifierTag);
  const tags=[...new Set(skills.filter(Boolean))].slice(0,4);
  if (!tags.length) tags.push('implementation');
  const primary=canonicalClassifierTag(raw.primary_skill);
  const cache=item.cacheMeta || {};
  return { difficulty:classifierDifficultyFromRating(estimated.nzoi), estimated_rating:estimated,
    primary_skill:CLASSIFIER_TAGS.has(primary)?primary:tags[0], skills:tags,
    reasoning_summary:String(raw.reasoning_summary||'').replace(/\s+/g,' ').trim().slice(0,280),
    risk_of_misclassification:raw.risk_of_misclassification, confidence:Number(raw.confidence),
    source_provider:provider, source_model:model,
    tags, rating:estimated.nzoi, classifiedBy:provider, classifiedAt:Date.now(),
    cache_key:cache.cache_key||'', problem_hash:cache.problem_hash||'', question_parser_version:cache.question_parser_version||7,
    problem_url:item.prob?.href||'', problem_title:item.prob?.name||'' };
}
function classifierProviderMessages(messages) {
  const prepared=(Array.isArray(messages)?messages:[]).map(message=>({...message,content:String(message?.content||'')}));
  const instruction=[
    'Google Gemini is the sole classifier for this job; classify the entire supplied batch directly in one pass.',
    'Return exactly one result for every supplied batch_id in the requested JSON schema.',
    'Use the authoritative 500–3000 rating scale, rounded to the nearest 100; round half-way values up and never go below 500 or above 3000.',
    'Reserve 500 only for the most basic I/O: the output follows directly from input, with no problem-specific computation or extra solution logic.',
    'Use 600–700 for trivial, 800–900 for easy, 1000–1500 for medium, 1600–1700 for difficult, 1800–2100 for very hard, and 2200–3000 for IOI-level problems. Boundaries belong to the band starting at that rating.',
    'Derive difficulty from estimated_rating.nzoi: beginner for 500; easy for 600–900; medium for 1000–1500; hard for 1600–1700; very_hard for 1800–2100; hardcore for 2200–2500; olympiad_hard for 2600–3000. Both final categories are IOI-level.',
    'A required observation, branch, loop, simulation, or case handling must score above 800 (at least 900 after rounding).',
    'These current rating rules replace any conflicting legacy prompt text. Use high reasoning effort where supported; do not reveal hidden reasoning.',
  ].join(' ');
  if (!prepared.some(message=>message.role==='system'&&message.content.includes('Google Gemini is the sole classifier for this job'))) {
    prepared.push({role:'system',content:instruction});
  }
  return prepared;
}
function classifierProviderSettings(settings) {
  const storedKeys=settings.googleKeys;
  const legacyKey=settings.googleKey||settings.geminiKey;
  const storedModels=settings.googleModels;
  const legacyModel=settings.googleModel;
  const configuredModels=Array.isArray(storedModels)&&storedModels.length?storedModels:[legacyModel||''];
  const freeModels=[...new Set(configuredModels.map(model=>canonicalAIModel('google',model)))]
    .filter(model=>GOOGLE_FREE_CLASSIFIER_MODEL_IDS.has(model));
  return {
    keys:(Array.isArray(storedKeys)&&storedKeys.length?storedKeys:[legacyKey]).filter(Boolean),
    models:freeModels.length?freeModels:GOOGLE_DEFAULT_CLASSIFIER_MODELS,
  };
}
async function classifierCallOne(messages,ids,settings) {
  const {keys,models}=classifierProviderSettings(settings);
  if (!keys.length||!models.length) throw new Error('Add a Google AI Studio API key and select at least one Gemini model.');
  let lastError;
  const modelRateLimitDeadlines=[];
  const modelUnavailableErrors=[];
  for (const model0 of models) {
    const model=canonicalAIModel('google',model0);
    await classifierSetProgress({currentTier:`Google Gemini · ${model}`,activity:'Classifying with Gemini'});
    for (const key of keys) {
      const startedAt=Date.now();
      LOG('Classification request started',{model,batchSize:ids.length,batchIds:ids,thinkingLevel:'HIGH',timeoutMs:CLASSIFIER_REQUEST_TIMEOUT_MS});
      try {
        const providerMessages=classifierProviderMessages(messages);
        const options={messages:providerMessages,maxTokens:Math.min(24_000,1_000+ids.length*1_000),thinkingLevel:'HIGH',responseFormat:{type:'json_object'},timeoutMs:CLASSIFIER_REQUEST_TIMEOUT_MS,useOffscreen:true};
        let raw=await serializeAIRequest(()=>callAI('google',key,model,'',options),'google',model);
        let byId=validClassifierResults(parseClassifierJson(raw),ids);
        if (!byId) {
          const repair=[
            {role:'system',content:'Repair this Google Gemini classifier response as JSON only. Preserve its classifications and use the exact required batch ids.'},
            {role:'user',content:`Return {"results":[...]}, exactly these batch_id values: ${ids.join(', ')}. Include all required classification fields. Ratings must follow the 500–3000 scale, use the specified difficulty bands, and round to 100. Derive difficulty from estimated_rating.nzoi and keep it aligned with that rating.\nInvalid output:\n${String(raw||'').slice(0,14000)}`},
          ];
          raw=await serializeAIRequest(()=>callAI('google',key,model,'',{...options,messages:repair}),'google',model);
          byId=validClassifierResults(parseClassifierJson(raw),ids);
        }
        if (!byId) throw new Error('Google Gemini returned invalid or incomplete batch JSON');
        LOG('Classification request completed',{model,batchSize:ids.length,durationMs:Date.now()-startedAt,resultCount:byId.size});
        return {byId,model};
      } catch(error) {
        lastError=error;
        ERR('Classification request failed',{model,batchSize:ids.length,durationMs:Date.now()-startedAt,status:Number(error.status)||0,retryAfterMs:Number(error.retryAfterMs)||0,message:error.message,error});
        if (Number(error.status)===429) {
          if (error.modelScopedRateLimit) {
            modelRateLimitDeadlines.push({
              deadline:Date.now()+Math.max(0,Number(error.retryAfterMs)||0),
              dailyQuotaReset:!!error.dailyQuotaReset,
            });
            // Try another selected model, but don't rotate keys on a project-wide quota error.
            break;
          }
          throw error;
        }
        // A 5xx is a provider/model capacity failure, not a bad key. Skip the
        // remaining keys for this model and immediately try the next selected
        // free model before putting the durable batch back on the retry queue.
        if (Number(error.status)>=500) {
          modelUnavailableErrors.push({model,error});
          break;
        }
        if (error.retryable||error.status>=500) throw error;
      }
    }
  }
  if (modelRateLimitDeadlines.length) {
    const retryAfterMs=Math.max(0,Math.max(...modelRateLimitDeadlines.map(item=>item.deadline))-Date.now());
    const error=new Error(`All selected Google models are rate limited; retry after ${Math.ceil(retryAfterMs/1000)} seconds.`);
    error.status=429; error.retryable=true; error.retryAfterMs=retryAfterMs;
    error.dailyQuotaReset=modelRateLimitDeadlines.some(item=>item.dailyQuotaReset);
    await deferProviderAfterRateLimit('google',error);
    throw error;
  }
  if (modelUnavailableErrors.length) {
    const retryAfterMs=Math.max(0,...modelUnavailableErrors.map(item=>Number(item.error?.retryAfterMs)||0));
    const unavailableModels=[...new Set(modelUnavailableErrors.map(item=>item.model))];
    const lastUnavailable=modelUnavailableErrors[modelUnavailableErrors.length-1].error;
    const error=new Error(`Selected Gemini models are temporarily unavailable (${unavailableModels.join(', ')}). ${lastUnavailable.message}`);
    error.status=503; error.retryable=true; error.retryAfterMs=retryAfterMs;
    throw error;
  }
  throw lastError||new Error('No working Google AI Studio key/model is configured.');
}
async function classifierCall(messages,ids,settings,job) {
  if (ids.length>CLASSIFIER_MAX_BATCH_ITEMS) throw new Error(`Classification batches may contain at most ${CLASSIFIER_MAX_BATCH_ITEMS} questions.`);
  const config=classifierProviderSettings(settings);
  if (!config.keys.length||!config.models.length) throw new Error('Add a Google AI Studio API key and select at least one Gemini model.');

  // Older durable jobs may contain a partial Groq pass. Discard those fields
  // and classify the complete batch with Google before writing any result.
  if (job?.tier1Complete||job?.primaryResults||job?.reviewIds) {
    delete job.tier1Complete;
    delete job.primaryResults;
    delete job.primaryModels;
    delete job.primaryProviders;
    delete job.reviewIds;
    await classifierSave(job);
  }
  await classifierSetProgress({currentTier:'Google Gemini'});
  const result=await classifierCallOne(messages,ids,settings);
  return {
    byId:result.byId,
    modelById:new Map(ids.map(id=>[String(id),result.model])),
    providerById:new Map(ids.map(id=>[String(id),'google'])),
  };
}
async function persistBackgroundClassifications(job, results) {
  const updates={};
  const dirtyIds=[];
  for (const item of job.items) {
    const original=results[String(item.id)]; if (!original) continue;
    const cls={...original,classification_batch_id:job.id};
    updates[`nztags_${item.id}`]=cls;
    updates[`nzoiClassifierTask_${item.id}`]={batchId:job.id,status:'complete',updatedAt:Date.now()};
    dirtyIds.push(String(item.id));
    if (cls.cache_key) {
      updates[cls.cache_key]=cls;
      updates[`nztags_idx_${item.id}`]={key:cls.cache_key,contentHash:cls.problem_hash||'',url:cls.problem_url||'',title:cls.problem_title||'',savedAt:Date.now()};
    }
  }
  if (dirtyIds.length) {
    const current=(await store.get('nzoiClassificationDirtyIdsV1')).nzoiClassificationDirtyIdsV1 || [];
    updates.nzoiClassificationDirtyIdsV1=[...new Set([...current.map(String),...dirtyIds])];
  }
  if (Object.keys(updates).length) await store.set(updates);
  await Promise.all(dirtyIds.map(async id=>{
    const task=await backgroundWorkGet('problemTasks',id);
    if(task){task.status='complete';task.classificationCompletedAt=Date.now();task.lastError='';await backgroundWorkPut('problemTasks',task);}
  }));
}
async function processClassifierJob(job) {
  const ids=job.items.map(item=>String(item.id));
  const settings=await store.get(['googleKeys','googleKey','geminiKey','googleModels','googleModel']);
  await classifierSetProgress({status:'running',currentTier:'Google Gemini',currentBatch:job.id,activity:'Classifying with Gemini'});
  job.status='running'; await classifierSave(job);
  const result=await classifierCall(job.messages,ids,settings,job);
  if (!await classifierJobExists(job.id)) return;
  const final={};
  for (const item of job.items) {
    const id=String(item.id);
    final[id]=normalizeBackgroundClassification(result.byId.get(id),item,result.modelById.get(id),result.providerById.get(id));
  }
  await persistBackgroundClassifications(job,final);
  const p=(await store.get('nzoiClassifierProgress')).nzoiClassifierProgress||{};
  await classifierSetProgress({completed:(p.completed||0)+ids.length,googleCompleted:(p.googleCompleted||0)+ids.filter(id=>result.providerById.get(id)==='google').length,
    currentTier:`Google Gemini · ${result.model}`,lastError:''});
  await classifierSave(job,true);
}
async function flushDirtyClassificationsToGist() {
  const { githubToken, nzoiClassificationDirtyIdsV1 } = await store.get(['githubToken','nzoiClassificationDirtyIdsV1']);
  const ids=[...new Set((nzoiClassificationDirtyIdsV1 || []).map(String))];
  if (!githubToken || !ids.length) return;
  await classifierSetProgress({activity:'Saving classifications to Gist'});
  const local=await store.get(ids.map(id=>`nztags_${id}`));
  const snapshots={};
  const serializeLocal=value=>value===undefined?null:JSON.stringify(value);
  for (const id of ids) snapshots[id]=serializeLocal(local[`nztags_${id}`]);
  return withClassificationGistLock(async()=>{
    const merged=await mergeClassificationRecordsLocked(githubToken,local);
    const pulled=merged.pulledDown || {};
    // A Gist read can take long enough for another dashboard to edit a dirty
    // classification. Only apply a pulled-down value if local still matches
    // the snapshot that was sent to Gist; otherwise retain the newer local edit.
    const pulledKeys=Object.keys(pulled);
    const beforePull=pulledKeys.length?await store.get(pulledKeys):{};
    const safePulled={};
    for (const key of pulledKeys) {
      const id=key.slice('nztags_'.length);
      if (Object.hasOwn(snapshots,id) && serializeLocal(beforePull[key])===snapshots[id]) safePulled[key]=pulled[key];
    }
    if (Object.keys(safePulled).length) await store.set(safePulled);
    const expectedAfterMerge={...snapshots};
    for (const [key,value] of Object.entries(safePulled)) expectedAfterMerge[key.slice('nztags_'.length)]=serializeLocal(value);
    const latest=(await store.get('nzoiClassificationDirtyIdsV1')).nzoiClassificationDirtyIdsV1 || [];
    const current=await store.get(ids.map(id=>`nztags_${id}`));
    const completed=new Set(ids.filter(id=>serializeLocal(current[`nztags_${id}`])===expectedAfterMerge[id]));
    await store.set({ nzoiClassificationDirtyIdsV1:latest.map(String).filter(id=>!completed.has(id)) });
  });
}
async function runClassifierQueue() {
  if (classifierDrain) return classifierDrain;
  classifierDrain=(async()=>{
    const jobs=(await classifierBatches()).filter(j=>['queued','running'].includes(j.status))
      .sort((a,b)=>(a.createdAt||0)-(b.createdAt||0));
    if (!jobs.length) {
      const p=(await store.get('nzoiClassifierProgress')).nzoiClassifierProgress;
      if (p&&p.status!=='complete') await classifierSetProgress({status:'complete',currentTier:'Complete',currentBatch:'',activity:'Saving classifications to Gist'});
      try {
        await flushDirtyClassificationsToGist();
        const dirty=(await store.get('nzoiClassificationDirtyIdsV1')).nzoiClassificationDirtyIdsV1 || [];
        if (dirty.length) {
          const token=(await store.get('githubToken')).githubToken;
          await classifierSetProgress({status:'complete',currentTier:'Complete',currentBatch:'',syncError:token?'Gist sync is waiting for a retry':'Add a GitHub token to sync classifications'});
          chrome.alarms.clear(CLASSIFIER_ALARM); return;
        }
        if (p?.syncError) await classifierSetProgress({syncError:'',lastError:''});
        if (p) await classifierSetProgress({status:'complete',currentTier:'Complete',currentBatch:'',activity:'Classification complete'});
        chrome.alarms.clear(CLASSIFIER_ALARM);
      } catch(error) {
        await classifierSetProgress({syncError:error.message,lastError:error.message,activity:'Error'});
        classifierSchedule(Math.max(Number(error.retryAfterMs)||0,60_000));
      }
      return;
    }
    const now=Date.now();
    const dueJobs=jobs.filter(job=>(Number(job.nextAttemptAt)||0)<=now);
    if (!dueJobs.length) {
      classifierSchedule(Math.max(30_000,Math.min(...jobs.map(job=>Math.max(0,Number(job.nextAttemptAt)||0)-now))));
      return;
    }
    const job=dueJobs[0]; job.status='running'; job.attempts=(job.attempts||0)+1; await classifierSave(job);
    LOG('Classification batch processing started',{batchId:job.id,batchSize:job.items.length,attempt:job.attempts});
    try {
      await processClassifierJob(job);
      const stillExists=(await classifierBatches()).some(item=>item.id===job.id);
      if (stillExists) { job.nextAttemptAt=0; await classifierSave(job); }
      classifierSchedule();
      setTimeout(() => void runClassifierQueue(), 0);
    }
    catch(error) {
      if (!await classifierJobExists(job.id)) {
        classifierSchedule(); setTimeout(()=>void runClassifierQueue(),0); return;
      }
      const transient=error.retryable||error.status===429||error.status>=500||/timeout|network|temporar/i.test(error.message||'');
      if (error.dailyQuotaReset) {
        // Daily quota exhaustion is a durable wait, not a finite retry budget.
        // Leave the IndexedDB job queued across the reset and avoid incrementing
        // attempts until Google can accept another request.
        job.status='queued'; job.attempts=0;
        const wait=Math.max(
          Number(error.retryAfterMs)||0,
          nextPacificMidnightMs()-Date.now(),
        );
        job.nextAttemptAt=Date.now()+wait; await classifierSave(job);
        ERR('Classification batch paused for Google daily quota reset',{batchId:job.id,batchSize:job.items.length,waitMs:wait,status:Number(error.status)||0,message:error.message,error});
        await classifierSetProgress({status:'waiting',currentTier:'Waiting for Google daily quota reset',lastError:error.message,activity:'Waiting for Gemini'});
        classifierSchedule(wait);
      } else if (transient&&job.attempts<=8) {
        job.status='queued';
        const wait=Math.max(Number(error.retryAfterMs)||0,Math.min(30*60_000,15_000*2**Math.min(job.attempts-1,6)));
        job.nextAttemptAt=Date.now()+wait; await classifierSave(job);
        ERR('Classification batch failed; retry scheduled',{batchId:job.id,batchSize:job.items.length,attempt:job.attempts,waitMs:wait,status:Number(error.status)||0,retryAfterMs:Number(error.retryAfterMs)||0,message:error.message,error});
        await classifierSetProgress({status:'waiting',currentTier:'Waiting for Google Gemini',lastError:error.message,activity:'Waiting for Gemini'}); classifierSchedule(wait);
      } else {
        await classifierSave(job,true);
        const taskUpdates={};
        for (const item of job.items) taskUpdates[`nzoiClassifierTask_${item.id}`]={batchId:job.id,runId:job.runId||'',status:'failed',error:error.message,updatedAt:Date.now()};
        await store.set(taskUpdates);
        await Promise.all(job.items.map(async item=>{
          const task=await backgroundWorkGet('problemTasks',String(item.id));
          if(task){task.status='failed';task.lastError=String(error.message||error).slice(0,300);task.classificationFailedAt=Date.now();await backgroundWorkPut('problemTasks',task);}
        }));
        const p=(await store.get('nzoiClassifierProgress')).nzoiClassifierProgress||{};
        await classifierSetProgress({completed:(p.completed||0)+job.items.length,failed:(p.failed||0)+job.items.length,status:'running',lastError:error.message,activity:'Error'});
        ERR('Background classifier batch failed permanently',{batchId:job.id,batchSize:job.items.length,attempt:job.attempts,status:Number(error.status)||0,message:error.message,error}); classifierSchedule();
        setTimeout(() => void runClassifierQueue(), 0);
      }
    }
  })().finally(()=>{classifierDrain=null;});
  return classifierDrain;
}
async function enqueueClassifierJobs(jobs, runId='') {
  const saved=(await store.get('nzoiClassifierProgress')).nzoiClassifierProgress||{};
  const sameRun=!!runId && saved.runId===runId;
  const continuing=sameRun || ['queued','running','waiting'].includes(saved.status);
  const accepted=(Array.isArray(jobs)?jobs:[]).filter(job=>job?.id&&job.items?.length&&job.messages?.length);
  const incomingIds=[...new Set(accepted.flatMap(job=>job.items.map(item=>String(item.id)).filter(id=>/^\d+$/.test(id))))];
  const existingTasks=incomingIds.length?await store.get(incomingIds.map(id=>`nzoiClassifierTask_${id}`)):{};
  const tracked=new Set(continuing&&Array.isArray(saved.problemIds)?saved.problemIds.map(String):[]);
  const retries=new Set(incomingIds.filter(id=>existingTasks[`nzoiClassifierTask_${id}`]?.status==='failed'&&
    (!existingTasks[`nzoiClassifierTask_${id}`]?.runId||existingTasks[`nzoiClassifierTask_${id}`].runId===(runId||saved.runId||''))));
  const newlyTracked=incomingIds.filter(id=>!tracked.has(id)&&!retries.has(id));
  incomingIds.forEach(id=>tracked.add(id));
  const completed=Math.max(0,(continuing?Number(saved.completed)||0:0)-retries.size);
  const failed=Math.max(0,(continuing?Number(saved.failed)||0:0)-retries.size);
  let total=0;
  for (const job of accepted) {
    if (job.items.length>CLASSIFIER_MAX_BATCH_ITEMS) throw new Error(`Classification batches may contain at most ${CLASSIFIER_MAX_BATCH_ITEMS} questions.`);
    await classifierSave({...job,runId:job.runId||runId,status:'queued',attempts:0,nextAttemptAt:0,createdAt:Date.now()}); total+=job.items.length;
  }
  const queuedTaskUpdates={};
  for (const job of accepted) for (const item of job.items)
    queuedTaskUpdates[`nzoiClassifierTask_${item.id}`]={batchId:job.id,runId:job.runId||runId||saved.runId||'',status:'queued',updatedAt:Date.now()};
  if (Object.keys(queuedTaskUpdates).length) await store.set(queuedTaskUpdates);
  await classifierSetProgress({runId:runId||saved.runId||'',problemIds:[...tracked],total:(continuing?Number(saved.total)||0:0)+newlyTracked.length,completed,
    googleCompleted:Math.max(0,(continuing?saved.googleCompleted||0:0)-retries.size),
    failed,status:'queued',currentTier:'Waiting for AI provider',lastError:'',activity:'Waiting for Gemini'});
  classifierSchedule(0); void runClassifierQueue(); return {queued:total};
}
async function recoverClassifierQueue() {
  try { const jobs=await classifierBatches(); let found=false;
    let nextAt=0;
    for (const job of jobs) {
      if (job.status!=='queued') { job.status='queued'; await classifierSave(job); }
      if (job.status==='queued') { found=true; nextAt=Math.min(nextAt||Infinity,Number(job.nextAttemptAt)||0); }
    }
    if (found) {
      await classifierSetProgress({status:'queued',currentTier:'Resuming saved batches'});
      const delay=Math.max(0,nextAt-Date.now()); classifierSchedule(delay);
      if (!delay) void runClassifierQueue();
    } else if ((await store.get('nzoiClassificationDirtyIdsV1')).nzoiClassificationDirtyIdsV1?.length) void runClassifierQueue();
  } catch(error) { ERR('Classifier queue recovery failed:',error.message); }
}

async function inspectLocalStorage() {
  const keys=await localStorageKeys();
  const local={
    classificationCache:keys.filter(key=>/^nztags_/.test(key)).length,
    classifierWork:keys.filter(key=>/^nzoiClassifierTask_\d+$/.test(key)||['nzoiClassifierProgress','nzoiAIProviderPacingV1'].includes(key)).length,
    editorRecovery:keys.filter(key=>/^code_\d+_(?:cpp|python|java)(?:__[a-z0-9-]+)?$/.test(key)||/^syncmeta_code_/.test(key)||/^code_tabs_\d+$/.test(key)||/^nzname_\d+$/.test(key)).length,
    pdfCache:keys.filter(key=>/^nzpdf_text_/.test(key)).length,
    bestAnswerMetadata:keys.filter(key=>/^nzoiBestSubmission_\d+$/.test(key)||key==='nzoiBestSubmissionProgress').length,
    gistCache:keys.filter(key=>key==='gistCache'||key==='gistCacheTime').length,
  };
  const [questionQueue,classifierQueue,discoveryPages,discoveredProblems,problemTasks,answerTasks,discoveryState]=await Promise.all([
    questionQueueCount(),classifierBatchCount(),backgroundWorkAll('pages'),backgroundWorkAll('problems'),
    backgroundWorkAll('problemTasks'),backgroundWorkAll('answerTasks'),backgroundWorkGet('state','active'),
  ]);
  local.questionArchiveQueue=questionQueue;
  local.classifierWork+=classifierQueue;
  local.backgroundWork=discoveryPages.length+discoveredProblems.length+problemTasks.length+answerTasks.length+(discoveryState?1:0);
  return {local};
}

async function inspectGistRecords() {
  const gist={classifications:[],questions:[],protectedAnswerFiles:[],error:''};
  try {
    const {githubToken}=await store.get('githubToken');
    const token=githubToken || '';
    if (!token) throw new Error('Add a GitHub token in the extension settings to inspect Gist records.');
    const files=await fetchGistFiles(token);
    const classFile=files[CLASSIFICATIONS_FILE];
    const classText=classFile?(classFile.truncated?await fetch(classFile.raw_url).then(response=>response.text()):classFile.content):'{}';
    const [classes,archive]=await Promise.all([
      Promise.resolve().then(()=>JSON.parse(classText||'{}')),
      loadQuestionsFromGist(token),
    ]);
    gist.classifications=Object.entries(classes || {}).flatMap(([key,value])=>{
      const match=key.match(/^nztags_(\d+)$/); if (!match) return [];
      return [{id:match[1],title:String(value?.problem_title||value?.title||`Problem ${match[1]}`)}];
    }).sort((a,b)=>Number(a.id)-Number(b.id));
    gist.questions=Object.entries(archive?.questions || {}).map(([id,value])=>({id:String(id),title:String(value?.title||`Problem ${id}`)}))
      .sort((a,b)=>Number(a.id)-Number(b.id));
    gist.protectedAnswerFiles=Object.keys(files || {}).filter(name=>/\.(?:cpp|cc|cxx|h|hpp|py|java)$/i.test(name)).sort();
  } catch(error) { gist.error=String(error?.message||error); }
  return {gist};
}

async function inspectStorageAndGist() {
  const [local,gist]=await Promise.all([inspectLocalStorage(),inspectGistRecords()]);
  return {local:local.local,gist:gist.gist};
}
async function clearLocalStorageCategories(categories) {
  const chosen=new Set((Array.isArray(categories)?categories:[]).map(String));
  const keys=await localStorageKeys(), removeByCategory={};
  const patterns={
    classificationCache:key=>/^nztags_/.test(key),
    classifierWork:key=>/^nzoiClassifierTask_\d+$/.test(key)||['nzoiClassifierProgress','nzoiAIProviderPacingV1'].includes(key),
    editorRecovery:key=>/^code_\d+_(?:cpp|python|java)(?:__[a-z0-9-]+)?$/.test(key)||/^syncmeta_code_/.test(key)||/^code_tabs_\d+$/.test(key)||/^nzname_\d+$/.test(key),
    pdfCache:key=>/^nzpdf_text_/.test(key),
    bestAnswerMetadata:key=>/^nzoiBestSubmission_\d+$/.test(key)||key==='nzoiBestSubmissionProgress',
    gistCache:key=>key==='gistCache'||key==='gistCacheTime',
    backgroundWork:key=>[DISCOVERY_STATUS_KEY,PROBLEM_WORK_STATUS_KEY].includes(key),
  };
  for (const category of chosen) if (patterns[category]) removeByCategory[category]=keys.filter(patterns[category]);
  const keysToRemove=[...new Set(Object.values(removeByCategory).flat())];
  if (keysToRemove.length) await store.remove(keysToRemove);
  if (chosen.has('classifierWork')) {
    const jobs=await classifierBatches();
    await classifierClear();
    removeByCategory.classifierWork=(removeByCategory.classifierWork||[]).concat(jobs.map(job=>job.id));
  }
  if (chosen.has('questionArchiveQueue')) {
    const pending=await questionQueueRecords();
    await questionQueueClear(); chrome.alarms.clear(QUESTION_ALARM);
    removeByCategory.questionArchiveQueue=pending.map(item=>String(item.id));
    await store.set({nzoiQuestionArchiveQueueStatus:{pending:0,lastError:''}});
  }
  if(chosen.has('backgroundWork')){
    const [pages,problems,problemTasks,answerTasks,state]=await Promise.all([
      backgroundWorkAll('pages'),backgroundWorkAll('problems'),backgroundWorkAll('problemTasks'),
      backgroundWorkAll('answerTasks'),backgroundWorkGet('state','active'),
    ]);
    const removedCount=pages.length+problems.length+problemTasks.length+answerTasks.length+(state?1:0);
    backgroundWorkEpoch++;
    await Promise.all(['pages','problems','problemTasks','answerTasks','state'].map(name=>backgroundWorkClear(name)));
    await store.remove([DISCOVERY_STATUS_KEY,PROBLEM_WORK_STATUS_KEY]);
    await store.set({[BEST_ANSWER_STATUS_KEY]:{total:0,completed:0,saved:0,failed:0,status:'idle',activity:'Background answer scan cleared',updatedAt:Date.now()}});
    await Promise.all([chrome.alarms.clear(DISCOVERY_ALARM),chrome.alarms.clear(PROBLEM_WORK_ALARM),chrome.alarms.clear(BEST_ANSWER_ALARM)]);
    removeByCategory.backgroundWork=Array.from({length:removedCount},(_,index)=>`background-item-${index}`);
  }
  return {removed:Object.fromEntries(Object.entries(removeByCategory).map(([category,items])=>[category,items.length]))};
}
async function deleteClassificationRecordsFromGist(ids) {
  const token=(await store.get('githubToken')).githubToken;
  if (!token) throw new Error('Add a GitHub token before removing Gist classifications.');
  const selected=new Set((Array.isArray(ids)?ids:[]).map(String).filter(id=>/^\d+$/.test(id)));
  if (!selected.size) return {deleted:0};
  return withClassificationGistLock(async()=>{
    const classes=await loadClassificationsFromGist(token); let deleted=0;
    for (const id of selected) if (Object.hasOwn(classes,`nztags_${id}`)) { delete classes[`nztags_${id}`]; deleted++; }
    if (deleted) {
      await writeClassificationsToGist(token,classes);
      const dirty=(await store.get('nzoiClassificationDirtyIdsV1')).nzoiClassificationDirtyIdsV1 || [];
      await store.set({nzoiClassificationDirtyIdsV1:dirty.map(String).filter(id=>!selected.has(id))});
    }
    return {deleted};
  });
}
async function deleteQuestionRecordsFromGist(ids) {
  const token=(await store.get('githubToken')).githubToken;
  if (!token) throw new Error('Add a GitHub token before removing Gist questions.');
  const selected=new Set((Array.isArray(ids)?ids:[]).map(String).filter(id=>/^\d+$/.test(id)));
  if (!selected.size) return {deleted:0};
  const archive=await loadQuestionsFromGist(token); let deleted=0;
  for (const id of selected) if (Object.hasOwn(archive.questions,id)) { delete archive.questions[id]; deleted++; }
  if (deleted) {
    archive.updatedAt=new Date().toISOString();
    const gistId=await getOrCreateGist(token);
    await ghFetch(token,'PATCH','/gists/'+gistId,{files:{[QUESTIONS_FILE]:{content:JSON.stringify(archive,null,2)}}});
    await store.remove(['gistCache','gistCacheTime']);
    for (const record of await questionQueueRecords()) if (selected.has(String(record.id))) await questionQueueSave(record,true);
  }
  return {deleted};
}

// ── Message router ────────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      let result;
      switch (msg.type) {
        case 'storage:get':               result = await store.get(msg.keys); break;
        case 'storage:set':               await store.set(msg.data); break;
        case 'storage:remove':            await store.remove(msg.keys); break;
        case 'storage:inspect':           result = await inspectStorageAndGist(); break;
        case 'storage:inspectLocal':      result = await inspectLocalStorage(); break;
        case 'storage:inspectGist':       result = await inspectGistRecords(); break;
        case 'storage:clearLocal':        result = await clearLocalStorageCategories(msg.categories); break;
        case 'gist:files':                result = await fetchGistFiles(msg.token); break;
        case 'gist:save':                 await saveFileToGist(msg.token, msg.filename, msg.content); break;
        case 'gist:delete':               await deleteFileFromGist(msg.token, msg.filename); break;
        case 'gist:deleteHighestAnswerJson': await deleteGeneratedHighestAnswerJson(msg.token, msg.problemId); break;
        case 'gist:getOrCreate':          result = await getOrCreateGist(msg.token); break;
        case 'gist:test':                 result = await testGistToken(msg.token); break;
        case 'gist:list':                 result = await listGists(msg.token); break;
        case 'gist:saveClassifications':  await saveClassificationsToGist(msg.token, msg.data); break;
        case 'gist:loadClassifications':  result = await loadClassificationsFromGist(msg.token); break;
        case 'gist:mergeClassifications': result = await mergeClassificationRecordsToGist(msg.token,msg.data); break;
        case 'gist:loadQuestions':        result = await loadQuestionsFromGist(msg.token); break;
        case 'gist:mergeQuestions':       result = await mergeQuestionsToGist(msg.token, msg.questions); break;
        case 'gist:queueQuestions':       result = await enqueueQuestionArchiveRecords(msg.questions); break;
        case 'gist:deleteClassificationRecords': result = await deleteClassificationRecordsFromGist(msg.ids); break;
        case 'gist:deleteQuestionRecords': result = await deleteQuestionRecordsFromGist(msg.ids); break;
        case 'ai:listModels':             result = await serializeAIRequest(() => listAIModels(msg.provider, msg.apiKey), msg.provider); break;
        case 'ai:classify':               {
          const options=msg.options||{};
          result = await serializeAIRequest(() => callAI(msg.provider,msg.apiKey,msg.model,msg.prompt,options),msg.provider,msg.model);
          break;
        }
        case 'classifier:enqueue':         result = await enqueueClassifierJobs(msg.jobs,msg.runId); break;
        case 'classifier:progress':       result = (await store.get('nzoiClassifierProgress')).nzoiClassifierProgress || null; break;
        case 'problem:discoveryStart':     result = await startProblemDiscovery(msg); break;
        case 'problem:discoverySnapshot': result = await getProblemDiscoverySnapshot(); break;
        case 'problem:queue':              result = await queueBackgroundProblemWork(msg.problems||[]); break;
        case 'bestAnswers:queue':          result = await queueBackgroundBestAnswers(msg.problems||[]); break;
        case 'network:fetchBinary':        result = await fetchBinaryResource(msg.url, msg.maxBytes); break;
        case 'run:code':                  result = await runCode(msg.source, msg.languageId, msg.stdin); break;
        case 'get:tabId':                 result = sender.tab?.id; break;
        case 'inject:monaco':             await injectMonacoIntoTab(msg.tabId, msg.nonce); break;
        default: throw new Error('Unknown message: ' + msg.type);
      }
      sendResponse({ ok: true, data: result });
    } catch(e) {
      (e.retryable ? LOG : ERR)(msg.type, e.message);
      sendResponse({
        ok: false,
        error: e.message,
        status: Number(e.status) || 0,
        retryAfterMs: Number(e.retryAfterMs) || 0,
        retryable: !!e.retryable,
      });
    }
  })();
  return true;
});

chrome.runtime.onInstalled.addListener(({ reason }) => {
  if (reason === 'install') store.set({ defaultLanguage: 'cpp', gistAutoSaveMs: 5000 });
  void store.remove(['bynaraKeys','bynaraKey','bynaraModels','bynaraModel']);
  void migrateGoogleOnlySettings().catch(error=>ERR('Google-only settings migration failed:',error.message));
  void recoverClassifierQueue();
  void recoverQuestionArchiveQueue();
  void recoverProblemDiscovery();
  void recoverBackgroundProblemWork();
  void recoverBackgroundBestAnswers();
});

chrome.runtime.onStartup.addListener(() => { void migrateGoogleOnlySettings().catch(error=>ERR('Google-only settings migration failed:',error.message)); void recoverClassifierQueue(); void recoverQuestionArchiveQueue(); void recoverProblemDiscovery(); void recoverBackgroundProblemWork(); void recoverBackgroundBestAnswers(); });
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm?.name === CLASSIFIER_ALARM) void runClassifierQueue();
  if (alarm?.name === QUESTION_ALARM) void runQuestionArchiveQueue();
  if (alarm?.name === DISCOVERY_ALARM) void runProblemDiscoveryQueue();
  if (alarm?.name === PROBLEM_WORK_ALARM) void runBackgroundProblemWork();
  if (alarm?.name === BEST_ANSWER_ALARM) void runBestAnswerQueue();
  if (alarm?.name === CLASSIFIER_OFFSCREEN_CLOSE_ALARM) void (async()=>{
    if (!classifierOffscreenRequests.size && chrome.offscreen?.closeDocument && await classifierOffscreenDocumentExists()) {
      await chrome.offscreen.closeDocument();
      LOG('Closed idle hidden classifier request document');
    }
  })().catch(error=>ERR('Could not close idle hidden classifier request document',error));
});
chrome.storage.onChanged.addListener((changes,area)=>{
  if(area!=='local')return;
  if(changes.githubToken){
    void recoverQuestionArchiveQueue();void runClassifierQueue();void recoverBackgroundBestAnswers();
    void backgroundWorkGet('state','active').then(state=>{if(state){state.classificationIndexLoaded=false;state.knownClassificationIds=[];return backgroundWorkPut('state',state);}})
      .then(()=>void enqueueReadyBackgroundClassifications()).catch(error=>ERR('Background Gist cache refresh failed:',error.message));
  }
  if(['googleKeys','googleKey','geminiKey','googleModels','googleModel'].some(key=>changes[key])){
    void runBackgroundProblemWork();void enqueueReadyBackgroundClassifications();
  }
});
void migrateGoogleOnlySettings().catch(error=>ERR('Google-only settings migration failed:',error.message));
void recoverClassifierQueue();
void recoverQuestionArchiveQueue();
void recoverProblemDiscovery();
void recoverBackgroundProblemWork();
void recoverBackgroundBestAnswers();

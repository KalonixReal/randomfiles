/**
 * NZOI Enhanced — Dashboard UI (dashboard.js)
 * Loaded after content.js on the home page.
 * Defines its own bg() helper — does NOT rely on content.js scope.
 */

'use strict';

// Only run on home page
if (window.location.pathname !== '/' && window.location.pathname !== '') {
    // Not home — skip
} else {
    initDashboard();
}

function initDashboard() {

// ─── Logging ──────────────────────────────────────────────────────────────────

const LOG = (...a) => console.log('[NZOI Enhanced Dashboard]', ...a);
const ERR = (...a) => {
    // A stale extension context is already explained by one page-level notice.
    // Do not repeat it for every in-flight background operation.
    if (a.some(value => typeof nzoiIsExtensionContextInvalidated === 'function' && nzoiIsExtensionContextInvalidated(value))) return;
    console.error('[NZOI Enhanced Dashboard]', ...a);
};

// ─── Background bridge (self-contained, not relying on content.js) ────────────

function bg(msg) {
    return new Promise((resolve, reject) => {
        const runtime = typeof nzoiRuntimeForBridge === 'function' ? nzoiRuntimeForBridge() : null;
        if (!runtime) {
            const error = window.__NZOI_EXTENSION_CONTEXT_STATE__?.error || new Error('NZOI Enhanced was updated or disabled. Reload this page to reconnect the extension.');
            return reject(error);
        }
        LOG('→ BG msg:', msg.type, msg.provider || msg.filename || '');
        try {
            runtime.sendMessage(msg, res => {
                let lastError = null;
                try { lastError = runtime.lastError || null; }
                catch (error) {
                    const bridgeError = typeof nzoiIsExtensionContextInvalidated === 'function' && nzoiIsExtensionContextInvalidated(error)
                        ? nzoiMarkExtensionContextInvalidated(error) : error;
                    return reject(bridgeError);
                }
                if (lastError) {
                    const error = new Error(lastError.message || String(lastError));
                    const bridgeError = typeof nzoiIsExtensionContextInvalidated === 'function' && nzoiIsExtensionContextInvalidated(error)
                        ? nzoiMarkExtensionContextInvalidated(error) : error;
                    if (bridgeError === error) ERR('BG error:', error.message);
                    return reject(bridgeError);
                }
                if (!res?.ok) {
                    const error = new Error(res?.error || 'Background error');
                    if (typeof nzoiIsExtensionContextInvalidated === 'function' && nzoiIsExtensionContextInvalidated(error)) {
                        return reject(nzoiMarkExtensionContextInvalidated(error));
                    }
                    error.status = Number(res?.status) || 0;
                    error.retryAfterMs = Number(res?.retryAfterMs) || 0;
                    error.retryable = !!res?.retryable;
                    if (msg.type !== 'ai:classify') {
                        const report = error.retryable ? LOG : ERR;
                        report('BG returned error for', msg.type, ':', error.message);
                    }
                    return reject(error);
                }
                LOG('← BG ok:', msg.type);
                resolve(res.data);
            });
        } catch (error) {
            const bridgeError = typeof nzoiIsExtensionContextInvalidated === 'function' && nzoiIsExtensionContextInvalidated(error)
                ? nzoiMarkExtensionContextInvalidated(error) : error;
            if (bridgeError === error) ERR('BG error:', error.message || String(error));
            reject(bridgeError);
        }
    });
}

function rateLimitStatusMessage(message) {
    return /\b429\b|rate[- ]?limit|resource_exhausted|quota exceeded|too many requests|secondary rate/i.test(String(message || ''));
}

let dashboardActivity = { message:'Loading dashboard', state:'working', title:'Loading dashboard data.' };

function setDashboardActivity(message, state='working', title='') {
    const normalizedState = state === 'error' ? 'error' : state === 'success' ? 'success' : 'working';
    dashboardActivity = {
        message: normalizedState === 'error' ? 'Error' : String(message || 'Working').trim().slice(0, 180),
        state: normalizedState,
        title: normalizedState === 'error'
            ? 'See the extension console for detailed diagnostics.'
            : String(title || message || '').trim().slice(0, 300),
    };
    const el = document.getElementById('dashboard-activity');
    if (!el) return;
    const label = document.getElementById('dashboard-activity-label');
    if (label) label.textContent = dashboardActivity.message;
    el.dataset.state = dashboardActivity.state;
    el.title = dashboardActivity.title;
    el.setAttribute('aria-label', `Current activity: ${dashboardActivity.message}`);
}

function classifierActivity(progress) {
    if (!progress || typeof progress !== 'object') return null;
    if (progress.syncError || (progress.status === 'waiting' && progress.lastError) || progress.activity === 'Error' || (progress.status === 'complete' && Number(progress.failed) > 0)) {
        return { message:'Error', state:'error' };
    }
    if (progress.activity) {
        return {
            message:String(progress.activity),
            state:progress.status === 'complete' ? 'success' : 'working',
        };
    }
    if (progress.status === 'complete') return { message:'Classification complete', state:'success' };
    if (progress.status === 'waiting' || progress.status === 'queued' || /waiting/i.test(String(progress.currentTier || ''))) {
        return { message:'Waiting for Gemini', state:'working' };
    }
    if (/google|gemini/i.test(String(progress.currentTier || ''))) return { message:'Classifying with Gemini', state:'working' };
    return null;
}

function classifierProgressDescription(progress, processed, total) {
    const tier = String(progress.currentTier || '').trim();
    const failed = Math.min(processed, Number(progress.failed) || 0);
    const progressText = `${Math.max(0, processed - failed)} of ${total} classification results are available`;
    if (progress.syncError || (progress.status === 'waiting' && progress.lastError) || failed) {
        return 'An error occurred. Detailed diagnostics are available in the extension service worker console.';
    }
    if (/gist/i.test(tier) && /wait|retry|sync/i.test(tier)) return 'Classification results are ready; the background service is syncing them to Gist.';
    if (progress.status === 'complete') {
        return `Classification is finished. ${progressText}.`;
    }
    if (/google/i.test(tier)) {
        return `Google Gemini is processing the selected results. ${progressText}.`;
    }
    if (progress.status === 'queued' || /waiting/i.test(tier)) {
        return `Classification jobs are queued for background processing. ${progressText}; the count advances when a batch is saved locally.`;
    }
    return `Classification is running in the background. ${progressText}; the service worker continues the queue when the dashboard tab closes.`;
}

function renderClassifierProgress(progress) {
    const wrap = document.getElementById('dashboard-classifier-progress');
    if (!progress) return;
    const activity = classifierActivity(progress);
    if (activity) setDashboardActivity(activity.message, activity.state);
    if (!wrap || !(Number(progress.total) > 0)) return;
    const label = document.getElementById('dashboard-classifier-label');
    const count = document.getElementById('dashboard-classifier-count');
    const bar = document.getElementById('dashboard-classifier-bar');
    const total = Number(progress.total) || 0;
    const processed = Math.min(total, Number(progress.completed) || 0);
    const failed = Number(progress.failed) || 0;
    const hasError = !!progress.syncError || (progress.status === 'waiting' && !!progress.lastError) || failed > 0;
    const labelText = hasError
        ? 'Error'
        : progress.status === 'complete'
            ? 'Classification complete'
            : `${progress.currentTier || 'Classification'} · ${processed} processed`;
    const description = classifierProgressDescription(progress, processed, total);
    wrap.hidden = false;
    if (label) label.textContent = labelText;
    wrap.title = description;
    wrap.setAttribute('aria-label', `${labelText}. ${description}`);
    if (label) label.title = description;
    if (count) count.textContent = `${processed}/${total}`;
    if (bar) {
        bar.max = total;
        bar.value = processed;
        bar.setAttribute('aria-label', `${processed} of ${total} problems processed`);
        bar.title = description;
    }
}

window.__NZOI_SAFE_STORAGE__.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.nzoiClassifierProgress) renderClassifierProgress(changes.nzoiClassifierProgress.newValue);
    if (changes.nzoiClassifierProgress && !changes.nzoiClassifierProgress.newValue) {
        const progress=document.getElementById('dashboard-classifier-progress');
        if (progress) progress.hidden=true;
    }
});

// ─── API providers (loaded from storage — set keys in the extension popup) ──────

let API_PROVIDERS = [];

const GOOGLE_MODEL_IDS = [
    'gemini-3.1-flash-lite',
    'gemini-3.5-flash-lite',
    'gemini-3.5-flash',
    'gemini-3.6-flash',
    'gemini-3.7-flash',
    'gemini-3.8-flash',
];
const GOOGLE_DEFAULT_MODEL_IDS = ['gemini-3.8-flash', 'gemini-3.7-flash'];

const CLASSIFICATION_BATCH_SIZE = 15;
const CLASSIFICATION_UI_FLUSH_MS = 350;
const CLASSIFICATION_SYNC_DEBOUNCE_MS = 1200;
const QUESTION_ARCHIVE_WORKERS = 8;
// Keep archive checkpoints small. A failed or interrupted browser session
// loses at most one small batch instead of a large page of fetched questions.
const QUESTION_ARCHIVE_BATCH_SIZE = 10;
const QUESTION_PARSER_VERSION = 8;
const PDF_TEXT_CACHE_VERSION = 4;
const PROBLEM_FETCH_MAX_ATTEMPTS = 3;
const PROBLEM_FETCH_TIMEOUT_MS = 15_000;
const PDF_ATTACHMENT_MAX_FILES = 4;
const PDF_ATTACHMENT_MAX_BYTES = 8_000_000;
const PDF_ATTACHMENT_TEXT_MAX_CHARS = 80_000;
const PDF_ATTACHMENT_TOTAL_TEXT_MAX_CHARS = 180_000;
const PDF_ATTACHMENT_CACHE_MS = 7 * 24 * 60 * 60 * 1000;
const PDF_ATTACHMENT_FETCH_TIMEOUT_MS = 18_000;

const GOOGLE_LIMITS = {
    requestsPerMinute: 5,
    contextWindowTokens: 1_048_576,
};

const ROUTER_DIFFICULTIES = ['beginner', 'easy', 'medium', 'hard', 'very_hard', 'hardcore', 'olympiad_hard'];
const DIFFICULTY_RATING = {
    beginner: 500,
    easy: 900,
    medium: 1300,
    hard: 1700,
    very_hard: 2000,
    hardcore: 2400,
    olympiad_hard: 2800,
};

const VALID_TAGS = new Set([
    '2-satisfiability','binary search','bitmasks','brute force','chinese remainder theorem',
    'combinatorics','constructive algorithms','data structures','depth-first search and similar',
    'divide and conquer','dynamic programming','disjoint set union','expression parsing',
    'fast fourier transform','flows','game theory','geometry','graph matchings','graphs',
    'greedy algorithms','hashing','implementation','linear algebra','meet-in-the-middle',
    'number theory','probabilities','scheduling','shortest paths','sorting',
    'string suffix structures','strings','ternary search','trees','two pointers','io',
].map(t => t.toLowerCase()));

// ─── State ────────────────────────────────────────────────────────────────────

const ROUTER_JSON_OBJECT = { type: 'json_object' };

const DEFAULT_CLASSIFIER_PROMPT_TEMPLATE = `You are the sole competitive-programming classifier for NZOI Training.

Return ONLY one valid JSON object. Do not use markdown. Do not include extra keys.
Do not give a solution, algorithm walkthrough, pseudocode, or code.

Base the classification on the complete statement, input/output format, constraints, subtasks, and samples. Infer the intended efficient technique from the constraints rather than matching isolated keywords.

Your job:
- Classify difficulty using exactly one of: beginner, easy, medium, hard, very_hard, hardcore, olympiad_hard.
- Estimate Codeforces-style ratings for codeforces, atcoder, usaco, and nzoi on a shared 500–3000 scale. Each rating must be an integer rounded to the nearest 100.
- Use 500 only for the most basic I/O: the output follows directly from the input, with no problem-specific computation or extra solution logic.
- Use these non-overlapping bands: 600–700 trivial; 800–900 easy; 1000–1500 medium; 1600–1700 difficult; 1800–2100 very hard; 2200–3000 IOI-level. Boundaries belong to the band that starts at that value; round half-way values up and never go below 500 or above 3000.
- A required observation, branch, loop, simulation, or case handling must score above 800 (at least 900 after rounding). Use 600 or higher when a correct solution needs more than a few straightforward lines. Do not rate by source-code length alone when a short implementation hides a difficult insight.
- Derive difficulty from estimated_rating.nzoi: beginner for 500; easy for 600–900; medium for 1000–1500; hard for 1600–1700; very_hard for 1800–2100; hardcore for 2200–2500; olympiad_hard for 2600–3000. Both final categories are within the IOI-level rating band.
- Treat IOI-level as substantial algorithmic depth, proof burden, or implementation complexity. Never exceed 3000.
- Choose one to four skills that are genuinely required by the intended solution. Do not add tags merely because their words appear in the story.
- primary_skill must be the main algorithmic bottleneck. Use implementation only when no more specific algorithmic tag is justified.
- Judge difficulty from required insight, proof burden, implementation risk, and constraints—not statement length.
- Treat the previous classification only as a weak consistency hint; override it whenever the statement disagrees.
- If the statement or constraints are incomplete, lower confidence and raise risk_of_misclassification instead of inventing details.
- Set confidence honestly from 0 to 1 based on statement completeness and certainty about the intended solution; do not inflate confidence to avoid review.
- Keep reasoning_summary short and high-level. Do not reveal hidden chain-of-thought.

Risky topics that should lower confidence or mark the problem hard include: tricky DP, graph modeling, modified shortest path, flows, matching, geometry, number theory, combinatorics, game theory, string hashing, suffix structures, heavy data structures, proof-heavy greedy, and binary search on answer.

Allowed existing tags:
{{TAGS}}

Previous classification anchor, if any. Use it only if it still matches the statement and constraints:
{{PREVIOUS}}

Problem title:
{{TITLE}}

Problem URL:
{{URL}}

Problem statement:
{{TEXT}}

Required JSON shape:
{
  "difficulty": "beginner|easy|medium|hard|very_hard|hardcore|olympiad_hard",
  "estimated_rating": { "codeforces": 1200, "atcoder": 1200, "usaco": 1200, "nzoi": 1200 },
  "primary_skill": "one existing tag",
  "skills": ["one existing tag"],
  "reasoning_summary": "brief non-solution reason",
  "risk_of_misclassification": "low|medium|high",
  "confidence": 0.0
}`;

const state = {
    problems: [], allTags: new Set(), allGroups: new Set(), seenIds: new Set(),
    problemById: new Map(), discoveredById: new Map(),
    // Active table sort, controlled from column headers.
    sorts: [{ column:'rating', ascending:false }],
    // Multi-value filters: Sets of selected values per dimension (OR within each
    // dimension, AND across dimensions). Empty Set = "all" for that dimension.
    filters: { tags: new Set(), groups: new Set(), diffs: new Set(), search: '' },
    apiStates: {}, reclassifying: new Set(), total: 0,
    filtered: [],   // current filtered+sorted view — virtualized renderer reads this
    theme: 'dark',  // set synchronously at the top of run(), before first paint
    hideTags: false, // some users find inline tags spoil the approach before they've tried the problem
    revealedTagRows: new Set(), // problem IDs temporarily revealed by clicking their hidden-tags placeholder
};

// Row height in px — MUST match `.pr{height:...}` in injectDashboardStyles().
// Used by the virtualized renderer to compute scroll offsets without measuring
// the DOM (so it works correctly even before any rows have been painted).
const ROW_H = 72;
const OVERSCAN = 6; // extra rows rendered above/below the viewport

// Precompute lowercase sort keys once, so the comparator in updateTable() never
// calls .toLowerCase()/.join() per-comparison (was the main per-sort cost at
// ~800 rows; Array.prototype.sort itself is already O(N log N) TimSort).
// Call this whenever a problem is created/restored/classified, or whenever its
// name/group/tags change.
function setSortKeys(p) {
    p._nameKey  = (p.name  || '').toLowerCase();
    p._groupKey = (p.group || '').toLowerCase();
    p._tagsKey  = (p.tags  || []).join(',').toLowerCase();
}

function prepareProblem(p) {
    if (!Array.isArray(p.tags)) p.tags = p.tags == null ? null : [];
    if (p.rating == null) p.rating = null;
    if (p.rating != null && Number.isFinite(Number(p.rating))) {
        p.rating = roundRating(p.rating);
        if (p.difficulty) p.difficulty = difficultyFromRating(p.rating);
    }
    p.searchIndex = `${p.name || ''} ${(p.tags || []).join(' ')} ${p.rating || ''} ${p.group || ''}`.toLowerCase();
    p._tagSet = new Set((p.tags || []).map(t => t.toLowerCase()));
    setSortKeys(p);
    if (p.group) state.allGroups.add(p.group);
    (p.tags || []).forEach(t => state.allTags.add(t));
    return p;
}

function upsertProblems(problems) {
    if (!problems || !problems.length) return [];
    const byId = new Map(state.problems.map(p => [String(p.id), p]));
    const changed = [];
    problems.forEach(raw => {
        const incoming = prepareProblem({ ...raw });
        const key = String(incoming.id);
        const existing = byId.get(key);
        if (existing) {
            Object.assign(existing, incoming);
            prepareProblem(existing);
            changed.push(existing);
        } else {
            byId.set(key, incoming);
            changed.push(incoming);
        }
    });
    state.problems = Array.from(byId.values());
    state.problemById = byId;
    return changed;
}

function providerDayKey(provider, date=new Date()) {
    if (!provider?.dailyTimeZone) return date.toISOString().slice(0, 10);
    const parts = new Intl.DateTimeFormat('en-US', {
        timeZone:provider.dailyTimeZone,
        year:'numeric',
        month:'2-digit',
        day:'2-digit',
    }).formatToParts(date);
    const get = type => parts.find(part => part.type === type)?.value || '';
    return `${get('year')}-${get('month')}-${get('day')}`;
}

function initApiStates() {
    state.apiStates = {};
    API_PROVIDERS.forEach(p => {
        const key = p.quotaGroup || p.name;
        if (state.apiStates[key]) return;
        state.apiStates[key] = {
            lastCall: 0,
            pauseUntil: 0,
            consecutive429: 0,
            requestTimes: [],
            tokenTimes: [],
            dayKey: providerDayKey(p),
            dailyRequests: 0,
            dailyTokens: 0,
            currentBackoffMs: 5000,
            limitLogTimes: {},
        };
    });
}

// ─── Utilities ────────────────────────────────────────────────────────────────

const esc      = t => (t||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
const sleep    = ms => new Promise(r => setTimeout(r, ms));
const debounce = (f,w) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => f(...a), w); }; };

const getRatingConfig = () => ({
    bounds: [500,1200,1400,1600,1900,2100,2300,2400,2600,3001],
    colors: ['#808080','#008000','#03a89e','#0000ff','#aa00aa','#ff8c00','#ff8c00','#ff0000','#ff0000','#ff0000'],
});
const getRatingRank = rating => {
    const r = clamp(roundRating(rating), 500, 3000);
    if (r < 1200) return { label:'Newbie', color:'var(--cf-newbie)' };
    if (r < 1400) return { label:'Pupil', color:'var(--cf-pupil)' };
    if (r < 1600) return { label:'Specialist', color:'var(--cf-specialist)' };
    if (r < 1900) return { label:'Expert', color:'var(--cf-expert)' };
    if (r < 2100) return { label:'Candidate Master', color:'var(--cf-candidate)' };
    if (r < 2400) return { label:r < 2300 ? 'Master' : 'International Master', color:'var(--cf-master)' };
    if (r < 2600) return { label:'Grandmaster', color:'var(--cf-grandmaster)' };
    return { label:'International Grandmaster', color:'var(--cf-legendary)' };
};
const getStarCount = r => r < 1200 ? 1 : r < 1400 ? 2 : r < 1600 ? 3 : r < 1900 ? 4 : 5;
const getStarRating = r => '★'.repeat(getStarCount(r));
const formatPct = p => `${Math.round(p||0)}%`;
const getProgressColor = () => 'var(--data-neutral)';

const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
const roundRating = n => Math.round(clamp(Number(n) || 500, 500, 3000) / 100) * 100;
const estimateTokens = text => Math.ceil(String(text || '').length / 4);

function fillPromptTemplate(template, values) {
    return String(template || '').replace(/\{\{([A-Z0-9_]+)\}\}/g, (_, key) => {
        const value = values[key];
        return value == null ? '' : String(value);
    });
}

function trimForTokenBudget(text, maxTokens) {
    const s = String(text || '');
    if (estimateTokens(s) <= maxTokens) return s;
    const maxChars = Math.max(1200, maxTokens * 4);
    const head = Math.floor(maxChars * 0.72);
    const tail = Math.floor(maxChars * 0.22);
    return s.slice(0, head) + '\n\n[content truncated for provider context window]\n\n' + s.slice(-tail);
}

function stableHash(input) {
    const s = String(input || '');
    let h1 = 0x811c9dc5, h2 = 0x01000193;
    for (let i = 0; i < s.length; i++) {
        const c = s.charCodeAt(i);
        h1 ^= c;
        h1 = Math.imul(h1, 0x01000193);
        h2 ^= c + i;
        h2 = Math.imul(h2, 0x85ebca6b);
    }
    return ((h1 >>> 0).toString(36) + (h2 >>> 0).toString(36));
}

const bytesToBinary = bytes => {
    let out = '';
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
        out += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    }
    return out;
};

const binaryToBytes = str => {
    const out = new Uint8Array(str.length);
    for (let i = 0; i < str.length; i++) out[i] = str.charCodeAt(i) & 255;
    return out;
};

function decodePdfBytes(bytes) {
    if (!bytes || !bytes.length) return '';
    if (bytes.length >= 2 && bytes[0] === 0xfe && bytes[1] === 0xff) {
        let out = '';
        for (let i = 2; i + 1 < bytes.length; i += 2) out += String.fromCharCode((bytes[i] << 8) | bytes[i + 1]);
        return out;
    }
    if (bytes.length >= 2 && bytes[0] === 0xff && bytes[1] === 0xfe) {
        let out = '';
        for (let i = 2; i + 1 < bytes.length; i += 2) out += String.fromCharCode(bytes[i] | (bytes[i + 1] << 8));
        return out;
    }
    let zeroEven = 0, pairs = 0;
    for (let i = 0; i + 1 < bytes.length; i += 2) { pairs++; if (bytes[i] === 0 && bytes[i + 1] >= 32) zeroEven++; }
    if (pairs > 2 && zeroEven / pairs > 0.45) {
        let out = '';
        for (let i = 0; i + 1 < bytes.length; i += 2) out += String.fromCharCode((bytes[i] << 8) | bytes[i + 1]);
        return out;
    }
    return Array.from(bytes, b => String.fromCharCode(b)).join('');
}

function decodePdfLiteralString(src) {
    const bytes = [];
    for (let i = 0; i < src.length; i++) {
        let c = src[i];
        if (c !== '\\') { bytes.push(c.charCodeAt(0) & 255); continue; }
        const n = src[++i];
        if (n == null) break;
        if (n === 'n') bytes.push(10);
        else if (n === 'r') bytes.push(13);
        else if (n === 't') bytes.push(9);
        else if (n === 'b') bytes.push(8);
        else if (n === 'f') bytes.push(12);
        else if (n === '\n') {}
        else if (n === '\r') { if (src[i + 1] === '\n') i++; }
        else if (/[0-7]/.test(n)) {
            let oct = n;
            for (let k = 0; k < 2 && /[0-7]/.test(src[i + 1] || ''); k++) oct += src[++i];
            bytes.push(parseInt(oct, 8) & 255);
        } else {
            bytes.push(n.charCodeAt(0) & 255);
        }
    }
    return decodePdfBytes(bytes);
}

function decodePdfHexString(src) {
    const hex = String(src || '').replace(/[^0-9a-f]/gi, '');
    const bytes = [];
    for (let i = 0; i < hex.length; i += 2) bytes.push(parseInt(hex.slice(i, i + 2).padEnd(2, '0'), 16) || 0);
    return decodePdfBytes(bytes);
}

function cleanPdfText(text) {
    return String(text || '')
        .replace(/\u0000/g, '')
        .replace(/[\u0001-\u0008\u000b\u000e-\u001f\u007f]/g, ' ')
        .replace(/[ \t\r\f\v]+/g, ' ')
        .replace(/\s*\n\s*/g, '\n')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

function extractPdfTextOperators(streamText) {
    const out = [];
    const blockRe = /BT([\s\S]*?)ET/g;
    let block;
    while ((block = blockRe.exec(streamText))) {
        const body = block[1];
        const tokenRe = /\((?:\\.|[^\\()])*\)|<([0-9a-fA-F\s]+)>|\[(.*?)\]\s*TJ/g;
        let token;
        while ((token = tokenRe.exec(body))) {
            const raw = token[0];
            if (raw[0] === '(') out.push(decodePdfLiteralString(raw.slice(1, -1)));
            else if (raw[0] === '<') out.push(decodePdfHexString(token[1] || ''));
            else if (token[2]) {
                const inner = token[2];
                const partRe = /\((?:\\.|[^\\()])*\)|<([0-9a-fA-F\s]+)>/g;
                let part;
                while ((part = partRe.exec(inner))) {
                    const p = part[0];
                    out.push(p[0] === '(' ? decodePdfLiteralString(p.slice(1, -1)) : decodePdfHexString(part[1] || ''));
                }
            }
        }
        out.push('\n');
    }
    return out.join(' ');
}

async function inflatePdfStream(bytes) {
    if (!('DecompressionStream' in window)) return null;
    try {
        const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate'));
        return new Uint8Array(await new Response(stream).arrayBuffer());
    } catch {
        return null;
    }
}

function extractPdfLooseText(binary) {
    const out = [];
    const literalRe = /\((?:\\.|[^\\()]){3,}\)/g;
    let m;
    while ((m = literalRe.exec(binary))) {
        const text = decodePdfLiteralString(m[0].slice(1, -1));
        if (/[A-Za-z0-9]/.test(text)) out.push(text);
        if (out.join(' ').length > PDF_ATTACHMENT_TEXT_MAX_CHARS) break;
    }
    const readable = binary
        .replace(/[^\x09\x0a\x0d\x20-\x7e]+/g, '\n')
        .split(/\n+/)
        .map(s => s.trim())
        .filter(s => s.length > 30 && /[A-Za-z]/.test(s))
        .slice(0, 800)
        .join('\n');
    return cleanPdfText(out.join(' ') + '\n' + readable);
}

let _pdfJsPromise = null;

function loadPdfJs() {
    if (!_pdfJsPromise) {
        _pdfJsPromise = import(nzoiRuntimeURL('libs/pdfjs/pdf.min.mjs')).then(pdfjs => {
            pdfjs.GlobalWorkerOptions.workerSrc = nzoiRuntimeURL('libs/pdfjs/pdf.worker.min.mjs');
            return pdfjs;
        });
    }
    return _pdfJsPromise;
}

async function extractPdfTextWithPdfJs(buffer) {
    const pdfjs = await loadPdfJs();
    const task = pdfjs.getDocument({ data: new Uint8Array(buffer) });
    const pdf = await task.promise;
    const pages = [];
    try {
        for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber++) {
            const page = await pdf.getPage(pageNumber);
            const content = await page.getTextContent();
            const parts = [];
            for (const item of content.items || []) {
                if (typeof item?.str !== 'string') continue;
                parts.push(item.str);
                parts.push(item.hasEOL ? '\n' : ' ');
            }
            pages.push(parts.join(''));
            if (pages.join('\n').length > PDF_ATTACHMENT_TEXT_MAX_CHARS) break;
        }
    } finally {
        await task.destroy();
    }
    return cleanPdfText(pages.join('\n')).slice(0, PDF_ATTACHMENT_TEXT_MAX_CHARS);
}

function isReadablePdfText(text) {
    const value = cleanPdfText(text);
    if (value.length < 20) return false;
    const visible = value.replace(/\s/g, '');
    const letters = (visible.match(/[A-Za-z]/g) || []).length;
    if (!visible.length || letters / visible.length < 0.35) return false;
    const tokens = value.split(/\s+/).filter(Boolean);
    const singletons = tokens.filter(token => /^[A-Z]$/.test(token)).length;
    return tokens.length < 30 || singletons / tokens.length < 0.4;
}

async function extractPdfTextFromArrayBuffer(buffer) {
    const text = await extractPdfTextWithPdfJs(buffer);
    if (!isReadablePdfText(text)) {
        throw new Error('PDF.js returned text that did not pass readability checks');
    }
    return text;
}

function normalizeDifficulty(value) {
    const d = String(value || '').trim().toLowerCase().replace(/[\s-]+/g, '_');
    const aliases = {
        trivial: 'beginner',
        novice: 'beginner',
        easy_medium: 'medium',
        medium_easy: 'medium',
        veryhard: 'very_hard',
        olympiad: 'olympiad_hard',
        extremely_hard: 'hardcore',
    };
    const out = aliases[d] || d;
    return ROUTER_DIFFICULTIES.includes(out) ? out : 'medium';
}

function difficultyFromRating(rating) {
    const r = roundRating(rating);
    if (r < 600) return 'beginner';
    if (r < 1000) return 'easy';
    if (r < 1600) return 'medium';
    if (r < 1800) return 'hard';
    if (r < 2200) return 'very_hard';
    if (r < 2600) return 'hardcore';
    return 'olympiad_hard';
}

function labelDifficulty(difficulty) {
    return String(difficulty || 'medium').replace(/_/g, ' ');
}

const SKILL_RULES = [
    [/2[-\s]?sat|two satisfiability/, '2-satisfiability'],
    [/binary search|parametric search|answer search/, 'binary search'],
    [/bitmask|bitset|subset/, 'bitmasks'],
    [/brute force|backtracking|complete search|enumeration/, 'brute force'],
    [/chinese remainder|crt\b/, 'chinese remainder theorem'],
    [/combinatorics|counting|inclusion.?exclusion|pigeonhole/, 'combinatorics'],
    [/constructive|construction/, 'constructive algorithms'],
    [/data structure|segment tree|fenwick|binary indexed tree|\bbit\b|sparse table|heap|priority queue|treap|sqrt decomposition|heavy.?light|hld|lazy propagation/, 'data structures'],
    [/dfs|depth.?first|flood fill|topological|traversal/, 'depth-first search and similar'],
    [/divide and conquer|cdq/, 'divide and conquer'],
    [/dynamic programming|\bdp\b|knapsack|memoization|lis|lcs|digit dp|tree dp|interval dp/, 'dynamic programming'],
    [/disjoint set|union find|dsu/, 'disjoint set union'],
    [/expression parsing|parser|grammar/, 'expression parsing'],
    [/fft|fourier|ntt/, 'fast fourier transform'],
    [/flow|dinic|min.?cut|max.?flow|circulation/, 'flows'],
    [/game theory|grundy|nim|sprague/, 'game theory'],
    [/geometry|convex hull|sweep line|polygon|circle|orientation/, 'geometry'],
    [/matching|bipartite matching|hungarian/, 'graph matchings'],
    [/\bgraph|bfs|shortest path|dijkstra|bellman|floyd|mst|minimum spanning|topological/, 'graphs'],
    [/greedy|exchange argument/, 'greedy algorithms'],
    [/hash|rolling hash|zobrist/, 'hashing'],
    [/implementation|simulation|ad hoc|casework|parsing input/, 'implementation'],
    [/linear algebra|matrix|gaussian/, 'linear algebra'],
    [/meet.?in.?the.?middle/, 'meet-in-the-middle'],
    [/number theory|modular|gcd|lcm|prime|sieve|factor|diophantine|totient/, 'number theory'],
    [/probabilit|expected value|random/, 'probabilities'],
    [/scheduling|interval scheduling|deadline/, 'scheduling'],
    [/shortest path|dijkstra|bellman|floyd|0-1 bfs|modified shortest/, 'shortest paths'],
    [/sorting|order statistics/, 'sorting'],
    [/suffix array|suffix automaton|suffix tree|suffix structure/, 'string suffix structures'],
    [/string|kmp|prefix function|z-function|trie|aho.?corasick/, 'strings'],
    [/ternary search/, 'ternary search'],
    [/tree|lca|centroid|euler tour/, 'trees'],
    [/two pointers|sliding window/, 'two pointers'],
    [/\bio\b|input.?output|fast input/, 'io'],
];

function mapSkillToTag(skill) {
    const s = String(skill || '').trim().toLowerCase();
    if (!s) return '';
    if (VALID_TAGS.has(s)) return s;
    const compact = s.replace(/[_-]+/g, ' ');
    if (VALID_TAGS.has(compact)) return compact;
    for (const [re, tag] of SKILL_RULES) if (re.test(compact)) return tag;
    return '';
}

function normalizeSkillList(rawSkills, primarySkill) {
    const source = [];
    if (primarySkill) source.push(primarySkill);
    if (Array.isArray(rawSkills)) source.push(...rawSkills);
    const out = [];
    source.forEach(skill => {
        const tag = mapSkillToTag(skill);
        if (tag && !out.includes(tag)) out.push(tag);
    });
    return out.slice(0, 4);
}

function normalizeRatings(ratings, difficulty) {
    const base = DIFFICULTY_RATING[difficulty] || 1500;
    const src = ratings && typeof ratings === 'object' ? ratings : {};
    const nzoi = roundRating(src.nzoi || src.codeforces || base);
    return {
        codeforces: roundRating(src.codeforces || nzoi),
        atcoder: roundRating(src.atcoder || nzoi),
        usaco: roundRating(src.usaco || nzoi),
        nzoi,
    };
}

// ─── API rate limiter ─────────────────────────────────────────────────────────

const apiMgr = {
    _persistTimer: null,
    _providerLastCall: {},
    _providerPauseUntil: {},
    stateKey(p) {
        return p.quotaGroup || p.name;
    },
    async loadPersisted() {
        const saved = await new Promise(resolve => window.__NZOI_SAFE_STORAGE__.local.get('nzoiApiQuotaStateV2', data => resolve(data.nzoiApiQuotaStateV2 || {})));
        const seen = new Set();
        for (const p of API_PROVIDERS) {
            const key = this.stateKey(p);
            if (seen.has(key)) continue;
            seen.add(key);
            const ps = this.ensureState(p);
            const prior = saved[key];
            if (!prior || prior.dayKey !== providerDayKey(p)) continue;
            const now = Date.now();
            ps.requestTimes = Array.isArray(prior.requestTimes) ? prior.requestTimes.filter(t => t > now - 60_000) : [];
            ps.tokenTimes = Array.isArray(prior.tokenTimes) ? prior.tokenTimes.filter(x => x?.t > now - 60_000) : [];
            ps.dailyRequests = Math.max(0, Number(prior.dailyRequests) || 0);
            ps.dailyTokens = Math.max(0, Number(prior.dailyTokens) || 0);
            ps.pauseUntil = Math.max(0, Number(prior.pauseUntil) || 0);
            ps.consecutive429 = Math.max(0, Number(prior.consecutive429) || 0);
            ps.consecutiveTransient = Math.max(0, Number(prior.consecutiveTransient) || 0);
        }
    },
    persistSoon() {
        if (this._persistTimer) return;
        this._persistTimer = setTimeout(() => {
            this._persistTimer = null;
            const snapshot = {};
            for (const [key, ps] of Object.entries(state.apiStates)) {
                snapshot[key] = {
                    dayKey: ps.dayKey,
                    requestTimes: ps.requestTimes,
                    tokenTimes: ps.tokenTimes,
                    dailyRequests: ps.dailyRequests,
                    dailyTokens: ps.dailyTokens,
                    pauseUntil: ps.pauseUntil,
                    consecutive429: ps.consecutive429,
                    consecutiveTransient: ps.consecutiveTransient,
                };
            }
            window.__NZOI_SAFE_STORAGE__.local.set({ nzoiApiQuotaStateV2:snapshot });
        }, 200);
    },
    candidates(kind, sp=null) {
        if (kind === 'classifier') {
            return API_PROVIDERS.filter(p => p.classificationEnabled && (!sp || sp === 'router' || p.name === sp || p.provider === sp));
        }
        if (!kind || kind === 'any') {
            return API_PROVIDERS.filter(p => !sp || sp === 'router' || p.name === sp || p.provider === sp);
        }
        if (kind === 'google') {
            return API_PROVIDERS.filter(p => p.provider === kind && (!sp || sp === 'router' || p.name === sp));
        }
        const direct = API_PROVIDERS.filter(p => p.name === kind || p.provider === kind);
        return direct.length ? direct : API_PROVIDERS.filter(p => !sp || sp === 'router' || p.name === sp || p.provider === sp);
    },
    ensureState(p) {
        const key = this.stateKey(p);
        if (!state.apiStates[key]) {
            state.apiStates[key] = {
                lastCall: 0,
                pauseUntil: 0,
                consecutive429: 0,
                consecutiveTransient: 0,
                requestTimes: [],
                tokenTimes: [],
                dayKey: providerDayKey(p),
                dailyRequests: 0,
                dailyTokens: 0,
                currentBackoffMs: 5000,
                limitLogTimes: {},
            };
        }
        return state.apiStates[key];
    },
    rollDailyWindow(p, ps) {
        const dayKey = providerDayKey(p);
        if (ps.dayKey !== dayKey) {
            ps.dayKey = dayKey;
            ps.dailyRequests = 0;
            ps.dailyTokens = 0;
        }
    },
    logLimited(p, key, message, intervalMs=10_000) {
        const ps = this.ensureState(p);
        const now = Date.now();
        ps.limitLogTimes = ps.limitLogTimes || {};
        if ((ps.limitLogTimes[key] || 0) + intervalMs > now) return;
        ps.limitLogTimes[key] = now;
        LOG(message);
    },
    getAvailable(kind, sp=null, tokenCost=0) {
        const now = Date.now();
        const prv = this.candidates(kind, sp);
        if (kind === 'classifier') {
            // Least-recently-used scheduling spreads classification batches
            // across every selected provider/model as one intentional pool.
            prv.sort((a, b) => {
                const groupOrder = this.ensureState(a).lastCall - this.ensureState(b).lastCall;
                return groupOrder || (a.keyLastCall || 0) - (b.keyLastCall || 0);
            });
        } else {
            prv.sort((a, b) => (a.keyLastCall || 0) - (b.keyLastCall || 0));
        }
        for (const p of prv) {
            const ps = this.ensureState(p);
            this.rollDailyWindow(p, ps);
            if ((p.keyPauseUntil || 0) > now) continue;
            if ((this._providerPauseUntil[p.provider] || 0) > now) continue;
            if (ps.pauseUntil > now) {
                this.logLimited(p, 'paused', `${p.name} paused for ${Math.ceil((ps.pauseUntil-now)/1000)}s`, 30_000);
                continue;
            }
            ps.requestTimes = ps.requestTimes.filter(t=>t>now-60_000);
            ps.tokenTimes = (ps.tokenTimes || []).filter(x=>x.t>now-60_000);
            const rr = ps.requestTimes;
            if (p.contextWindowTokens && tokenCost > p.contextWindowTokens) continue;
            if (p.minimumIntervalMs && now - (this._providerLastCall[p.provider] || 0) < p.minimumIntervalMs) continue;
            if (p.rpsLimit && rr.filter(t=>t>now-1000).length >= p.rpsLimit) continue;
            if (p.rpmLimit && rr.length >= p.rpmLimit) {
                this.logLimited(p, 'rpm', `${p.name} rate limited (${rr.length}/${p.rpmLimit} rpm)`);
                continue;
            }
            if (p.rpdLimit && ps.dailyRequests >= p.rpdLimit) {
                this.logLimited(p, 'rpd', `${p.name} daily request limit reached (${ps.dailyRequests}/${p.rpdLimit})`, 300_000);
                continue;
            }
            if (p.tpdLimit && ps.dailyTokens + tokenCost > p.tpdLimit) {
                this.logLimited(p, 'tpd', `${p.name} daily token limit reached (${ps.dailyTokens}/${p.tpdLimit})`, 300_000);
                continue;
            }
            if (p.tpmLimit) {
                const used = ps.tokenTimes.reduce((sum, x) => sum + x.tokens, 0);
                if (used + tokenCost > p.tpmLimit) {
                    this.logLimited(p, 'tpm', `${p.name} token limited (${used}/${p.tpmLimit} tpm)`);
                    continue;
                }
            }
            return p;
        }
        return null;
    },
    dailyExhausted(kind, sp=null, tokenCost=0) {
        const candidates = this.candidates(kind, sp);
        if (!candidates.length) return false;
        return candidates.every(p => {
            const ps = this.ensureState(p);
            this.rollDailyWindow(p, ps);
            const requestsExhausted = !!p.rpdLimit && ps.dailyRequests >= p.rpdLimit;
            const tokensExhausted = !!p.tpdLimit && ps.dailyTokens + tokenCost > p.tpdLimit;
            return requestsExhausted || tokensExhausted;
        });
    },
    reserve(p, tokenCost=0) {
        const now = Date.now();
        const ps = this.ensureState(p);
        this.rollDailyWindow(p, ps);
        ps.requestTimes = ps.requestTimes.filter(t=>t>now-60_000);
        ps.tokenTimes = (ps.tokenTimes || []).filter(x=>x.t>now-60_000);
        ps.requestTimes.push(now);
        if (p.rpdLimit) ps.dailyRequests++;
        if (p.tpdLimit) ps.dailyTokens += tokenCost;
        if (tokenCost > 0) ps.tokenTimes.push({ t: now, tokens: tokenCost });
        ps.lastCall = now;
        p.keyLastCall = now;
        this._providerLastCall[p.provider] = now;
        this.persistSoon();
        const dayPart = p.rpdLimit ? `, ${ps.dailyRequests}/${p.rpdLimit} day` : '';
        LOG(`${p.name}: reserved ${ps.requestTimes.length}/${p.rpmLimit || 'unlimited'} rpm${dayPart}`);
    },
    async waitFor(kind, sp=null, tokenCost=0, options={}) {
        const waitForever = !!options.waitForever;
        let waited = 0;
        while (true) {
            const p = this.getAvailable(kind, sp, tokenCost);
            if (p) {
                this.reserve(p, tokenCost);
                return p;
            }
            const dailyBlocked = this.dailyExhausted(kind, sp, tokenCost);
            if (dailyBlocked && !waitForever) {
                throw new Error((kind || 'AI') + ' daily request limit reached');
            }
            if (waited === 0) LOG(`All ${kind || 'AI'} providers busy; waiting without fallback…`);
            const delay = dailyBlocked ? 30_000 : 1000;
            await sleep(delay); waited += delay;
            if (!waitForever && waited > 120_000) throw new Error((kind || 'AI') + ' providers rate-limited for >2 minutes');
        }
    },
    record(p, tokenCost=0) {
        const now=Date.now(), ps=this.ensureState(p);
        ps.requestTimes = ps.requestTimes.filter(t=>t>now-60_000);
        ps.tokenTimes = (ps.tokenTimes || []).filter(x=>x.t>now-60_000);
        ps.lastCall=now;
        LOG(`${p.name}: ${ps.requestTimes.length}/${p.rpmLimit || 'unlimited'} rpm used`);
    },
    resetBackoff(p) {
        const ps=this.ensureState(p);
        ps.consecutive429=0;
        ps.consecutiveTransient=0;
        ps.currentBackoffMs=5000;
        this.persistSoon();
    },
    handle429(p, error=null) {
        const ps=this.ensureState(p); ps.consecutive429++;
        const message = String(error?.message || '');
        const msMatch = message.match(/retry-after-ms\s*[:=]\s*(\d+(?:\.\d+)?)/i);
        const secondsMatch = message.match(/retry-after\s*[:=]\s*(\d+(?:\.\d+)?)/i);
        const retryAfterMs = Number(error?.retryAfterMs) ||
            (msMatch ? Math.ceil(Number(msMatch[1])) : secondsMatch ? Math.ceil(Number(secondsMatch[1]) * 1000) : 0);
        const bo = Math.min(300_000, Math.max(retryAfterMs, ps.currentBackoffMs * Math.pow(2, ps.consecutive429)));
        ps.pauseUntil = Date.now() + bo;
        this.persistSoon();
        LOG(`${p.displayName || p.name}: rate limited — retrying after ${Math.ceil(bo/1000)}s`);
    },
    handleTransient(p, error=null) {
        const ps=this.ensureState(p);
        ps.consecutiveTransient++;
        const requested = Number(error?.retryAfterMs) || 0;
        const exponential = 5_000 * Math.pow(2, Math.min(ps.consecutiveTransient - 1, 6));
        const jitter = Math.floor(Math.random() * 1_500);
        const bo = Math.min(300_000, Math.max(requested, exponential + jitter));
        ps.pauseUntil = Math.max(ps.pauseUntil || 0, Date.now() + bo);
        this.persistSoon();
        const status = Number(error?.status) || 0;
        const reason = /empty response/i.test(String(error?.message || ''))
            ? 'empty response'
            : status ? `HTTP ${status}` : 'temporary failure';
        LOG(`${p.displayName || p.name}: ${reason} — retrying after ${Math.ceil(bo/1000)}s`);
    },
};

// ─── Classifier ───────────────────────────────────────────────────────────────

const classifier = {
    // Queue-based classification: callable multiple times as new problems are
    // discovered (e.g. from background "My Groups" fetches) without spawning
    // overlapping drain loops — the single loop below absorbs anything pushed
    // onto _queue while it's running.
    routerSystemPrompt(roleLabel='classifier') {
        return [
            `You are the ${roleLabel} for competitive-programming problem classification.`,
            'Output ONLY one valid JSON object. No markdown, no prose outside JSON.',
            'Do not provide a full solution, algorithm walkthrough, pseudocode, or code.',
            'Inspect input/output format and constraints carefully before classifying.',
            'Use this difficulty enum exactly: beginner, easy, medium, hard, very_hard, hardcore, olympiad_hard.',
            'Rate every platform from 500 to 3000 and round to the nearest 100 using these exact non-overlapping bands: 500 pure direct input/output with no problem-specific computation; 600–700 trivial; 800–900 easy; 1000–1500 medium; 1600–1700 difficult; 1800–2100 very hard; 2200–3000 IOI-level. Half-way values round up; boundaries belong to the band starting at that rating.',
            'Derive difficulty from estimated_rating.nzoi: beginner for 500; easy for 600–900; medium for 1000–1500; hard for 1600–1700; very_hard for 1800–2100; hardcore for 2200–2500; olympiad_hard for 2600–3000. Both final categories are within the IOI-level rating band.',
            'A required observation, branch, loop, simulation, or case handling must score above 800 (at least 900 after rounding). Use 600+ when a correct solution takes more than a few straightforward lines. Never rate below 500 or above 3000. This current rating policy overrides any older scale mentioned in a saved prompt template or prior classification.',
            'Use primary_skill and skills from the closest existing tag names supplied by the user.',
            'reasoning_summary must be concise, high-level, and must not reveal hidden chain-of-thought.',
        ].join('\n');
    },

    async buildClassifierBatchMessages(items) {
        const storedPrompts = await new Promise(resolve => window.__NZOI_SAFE_STORAGE__.local.get(
            ['classifierPromptTemplate'], resolve
        ));
        const candidate = storedPrompts.classifierPromptTemplate;
        const tpl = typeof candidate === 'string' && candidate.trim() &&
            ['{{TEXT}}', '{{TAGS}}', '{{PREVIOUS}}'].every(token => candidate.includes(token))
            ? candidate
            : DEFAULT_CLASSIFIER_PROMPT_TEMPLATE;
        const policy = fillPromptTemplate(tpl, {
            TAGS: Array.from(VALID_TAGS).join(', '),
            PREVIOUS: 'Use each item.previous_classification.',
            TITLE: 'Use each item.title.',
            URL: 'Use each item.url.',
            TEXT: 'Use each item.problem_text.',
        });
        const perItemTokenBudget = Math.max(4_000, Math.floor((64_000 - 12_000) / Math.max(1, items.length)));
        const payload = items.map(item => ({
            batch_id:String(item.prob.id),
            title:item.prob.name || '',
            url:item.prob.href || '',
            previous_classification:item.previous ? {
                difficulty:item.previous.difficulty,
                rating:item.previous.rating,
                tags:item.previous.tags,
                confidence:item.previous.confidence,
                provider:item.previous.source_provider || item.previous.classifiedBy,
                model:item.previous.source_model,
            } : null,
            problem_text:trimForTokenBudget(item.parsed.text, perItemTokenBudget),
        }));
        return [
            {
                role:'system',
        content:this.routerSystemPrompt('AI batched classifier') +
                    '\nClassify every input item independently. Never omit or merge items.',
            },
            {
                role:'user',
                content:[
                    'Classify every item in the input array.',
                    'Return ONLY one JSON object with a "results" array.',
                    'The array must contain exactly one result per input and copy each batch_id exactly.',
                    'The policy below was originally written for one item: apply its required fields to each result object, but keep the outer results-array format required here.',
                    '',
                    'Classification policy/template:',
                    policy,
                    '',
                    'Input items JSON:',
                    JSON.stringify(payload),
                    '',
                    'Required result fields: batch_id, difficulty, estimated_rating, primary_skill, skills, reasoning_summary, risk_of_misclassification, confidence.',
                ].join('\n'),
            },
        ];
    },

    buildClassifierBatchRepairMessages(raw, expectedIds) {
        return [
            {
                role:'system',
                content:'Repair classifier output into one valid JSON object. Output JSON only; do not classify again or add commentary.',
            },
            {
                role:'user',
                content:[
                    'Required top-level shape: {"results":[...]}',
                    `Required batch_id values, exactly once each: ${expectedIds.join(', ')}`,
                    'Each item requires: batch_id, difficulty, estimated_rating, primary_skill, skills, reasoning_summary, risk_of_misclassification, confidence.',
                    'difficulty enum: ' + ROUTER_DIFFICULTIES.join(', '),
                    'estimated_rating keys: codeforces, atcoder, usaco, nzoi.',
                    'Every estimated_rating must be an integer from 500 to 3000 and divisible by 100; follow the prompt rating bands. Derive difficulty from estimated_rating.nzoi and keep its enum value aligned with that rating.',
                    'Invalid output:',
                    String(raw || '').slice(0, 14_000),
                ].join('\n'),
            },
        ];
    },

    parseStrictJson(raw) {
        if (typeof raw !== 'string') return { ok: false, error: 'empty_non_string_response' };
        try {
            const value = JSON.parse(raw.trim());
            if (!value || typeof value !== 'object' || Array.isArray(value)) return { ok: false, error: 'json_not_object' };
            return { ok: true, value };
        } catch (e) {
            return { ok: false, error: e.message || 'invalid_json' };
        }
    },

    hasProvider(kind) {
        if (kind === 'classifier') return API_PROVIDERS.some(p => p.classificationEnabled && p.provider === 'google');
        return API_PROVIDERS.some(p => p.provider === kind);
    },

    async callProvider(kind, messages, options={}, sp=null) {
        if (!this.hasProvider(kind)) throw new Error('Missing ' + kind + ' provider');
        const waitForever = !!options.waitForever;
        const requestOptions = { ...options };
        delete requestOptions.waitForever;
        const promptTokens = estimateTokens(messages.map(m => m.content || '').join('\n'));
        const tokenCost = promptTokens + (requestOptions.maxTokens || 900);
        const candidates = apiMgr.candidates(kind, sp);
        if (!candidates.length) throw new Error('Missing ' + kind + ' provider');
        if (candidates.every(p => p.contextWindowTokens && tokenCost > p.contextWindowTokens)) {
            throw new Error('context-too-long for ' + kind);
        }
        let lastErr = null;
        const maxAttempts = waitForever ? Number.POSITIVE_INFINITY : 4;
        for (let attempt = 0; attempt < maxAttempts; attempt++) {
            const pv = await apiMgr.waitFor(kind, sp, tokenCost, { waitForever });
            const model = pv.model;
            try {
                if (pv.contextWindowTokens && tokenCost > pv.contextWindowTokens) {
                    throw new Error('context-too-long for ' + model);
                }
                const raw = await bg({
                        type: 'ai:classify',
                        provider: pv.provider,
                        apiKey: pv.key,
                        model,
                        prompt: messages.map(m => m.content || '').join('\n\n'),
                        options: {
                            ...requestOptions,
                            messages,
                            responseFormat: requestOptions.responseFormat || ROUTER_JSON_OBJECT,
                        },
                    });
                apiMgr.record(pv, tokenCost);
                apiMgr.resetBackoff(pv);
                return { raw, provider: pv.provider, providerName: pv.name, model };
            } catch (e) {
                lastErr = e;
                const status = Number(e.status) || Number(String(e.message).match(/\b(4\d\d|5\d\d)\b/)?.[1]) || 0;
                if ([401, 402, 403].includes(status) || /payment required|invalid api key|unauthorized|forbidden/i.test(e.message)) {
                    const until = Date.now() + 24 * 60 * 60 * 1000;
                    API_PROVIDERS.filter(item => item.provider === pv.provider && item.key === pv.key)
                        .forEach(item => { item.keyPauseUntil = until; });
                    apiMgr.persistSoon();
                    ERR(`${pv.provider} key unavailable — pausing that key for 24h`);
                } else if (status === 429 || /429|rate limit|quota|resource exhausted|limit exceeded/i.test(e.message)) {
                    apiMgr.handle429(pv, e);
                } else if (status === 408 || status === 425 || status >= 500 || e.retryable || /timeout|network|empty response/i.test(e.message)) {
                    apiMgr.handleTransient(pv, e);
                } else if ((status >= 400 && status < 500) || /context|too long|unsupported model/i.test(e.message)) {
                    const ps = apiMgr.ensureState(pv);
                    ps.pauseUntil = Date.now() + 60 * 60 * 1000;
                    apiMgr.persistSoon();
                    ERR(`${pv.displayName || pv.name}: request rejected${status ? ` (HTTP ${status})` : ''} — pausing this model for 1h`);
                } else {
                    apiMgr.handleTransient(pv, e);
                }
            }
        }
        throw lastErr || new Error(kind + ' API attempts exhausted');
    },

    async callAndParseClassifierBatch(messages, expectedIds, options={}, sp=null) {
        const first = await this.callProvider('classifier', messages, options, sp);
        let parsed = this.parseStrictJson(first.raw);
        if (parsed.ok && Array.isArray(parsed.value?.results)) {
            return { ...first, parsed:parsed.value, validJson:true, repaired:false };
        }
        // A format repair stays on the exact same selected provider/model. It
        // is not a fallback to a different model.
        const repair = await this.callProvider(
            'classifier',
            this.buildClassifierBatchRepairMessages(first.raw, expectedIds),
            options,
            first.providerName
        );
        parsed = this.parseStrictJson(repair.raw);
        if (parsed.ok && Array.isArray(parsed.value?.results)) {
            return { ...repair, parsed:parsed.value, validJson:true, repaired:true, originalRaw:first.raw };
        }
        return { ...repair, parsed:null, validJson:false, repaired:true, originalRaw:first.raw, parseError:parsed.error };
    },

    normalizeResult(payload, meta={}) {
        const rawDifficulty = payload?.difficulty || difficultyFromRating(payload?.estimated_rating?.nzoi);
        const initialDifficulty = normalizeDifficulty(rawDifficulty);
        const estimated_rating = normalizeRatings(payload?.estimated_rating, initialDifficulty);
        const difficulty = difficultyFromRating(estimated_rating.nzoi);
        const rawPrimary = typeof payload?.primary_skill === 'string' ? payload.primary_skill.trim() : '';
        const rawSkills = Array.isArray(payload?.skills) ? payload.skills.filter(Boolean) : [];
        const skills = normalizeSkillList(rawSkills, rawPrimary);
        const primary_skill = mapSkillToTag(rawPrimary) || skills[0] || '';
        const confidence = clamp(Number(payload?.confidence), 0, 1) || 0;
        const reasoning_summary = String(payload?.reasoning_summary || '').replace(/\s+/g, ' ').trim().slice(0, 280);
        const risk = ['low', 'medium', 'high'].includes(payload?.risk_of_misclassification)
            ? payload.risk_of_misclassification
            : (confidence >= 0.85 ? 'low' : confidence >= 0.65 ? 'medium' : 'high');
        return {
            difficulty,
            estimated_rating,
            primary_skill,
            skills,
            reasoning_summary,
            risk_of_misclassification: risk,
            confidence,
            source_provider: meta.source_provider || 'unknown',
            source_model: meta.source_model || 'unknown',
            tags: skills,
            rating: estimated_rating.nzoi,
            classifiedBy: meta.source_provider || 'unknown',
            classifiedAt: Date.now(),
        };
    },

    cacheKeys(prob, problemText) {
        const contentHash = stableHash(problemText || '');
        const fullHash = stableHash([prob.href || '', prob.name || '', contentHash].join('\n'));
        return {
            legacy: `nztags_${prob.id}`,
            index: `nztags_idx_${prob.id}`,
            full: `nztags_v2_${fullHash}`,
            contentHash,
        };
    },

    async readContentCache(prob, problemText) {
        const keys = this.cacheKeys(prob, problemText);
        const stored = await new Promise(r => window.__NZOI_SAFE_STORAGE__.local.get(keys.full, r));
        const cls = stored[keys.full];
        return cache.isValid(cls) ? { ...cls, cacheHit: true } : null;
    },

    withCacheMeta(prob, cls, problemText) {
        const keys = this.cacheKeys(prob, problemText);
        return {
            ...cls,
            cache_key: keys.full,
            problem_hash: keys.contentHash,
            question_parser_version: QUESTION_PARSER_VERSION,
            problem_url: prob.href || '',
            problem_title: prob.name || '',
        };
    },

    async saveClassification(prob, cls) {
        const legacy = `nztags_${prob.id}`;
        const updates = { [legacy]: cls };
        if (cls.cache_key) {
            updates[cls.cache_key] = cls;
            updates[`nztags_idx_${prob.id}`] = {
                key: cls.cache_key,
                contentHash: cls.problem_hash || '',
                url: cls.problem_url || prob.href || '',
                title: cls.problem_title || prob.name || '',
                savedAt: Date.now(),
            };
        }
        await new Promise(r => window.__NZOI_SAFE_STORAGE__.local.set(updates, r));
    },

    findPdfLinks(doc, baseUrl, rawText='') {
        const links = [];
        const add = (href, { embedded=false, explicit=false, label='' }={}) => {
            if (!href) return;
            try {
                const rawHref = String(href).trim();
                let effectiveBase = baseUrl;
                const isRelative = !/^[a-z][a-z0-9+.-]*:/i.test(rawHref) && !rawHref.startsWith('//') && !rawHref.startsWith('/');
                if (isRelative) {
                    const b = new URL(baseUrl, location.href);
                    const lastPart = b.pathname.split('/').pop() || '';
                    if (!b.pathname.endsWith('/') && !lastPart.includes('.')) {
                        b.pathname += '/';
                        b.search = '';
                        b.hash = '';
                        effectiveBase = b.href;
                    }
                }
                const parsedUrl = new URL(rawHref, effectiveBase);
                // Pages are served over HTTPS. Upgrade legacy attachment links
                // before they can trigger mixed-content blocking in the page.
                if (parsedUrl.protocol === 'http:') parsedUrl.protocol = 'https:';
                const url = parsedUrl.href;
                if (!/\.pdf(?:[?#]|$)/i.test(url)) return;
                const attachmentPath = /\/(?:files?|attachments?|downloads?)\//i.test(new URL(url).pathname);
                const attachmentLabel = /\b(?:pdf|download|attachment|problem statement)\b/i.test(String(label || ''));
                // Do not mistake an ordinary citation/reference link ending in
                // .pdf for part of the problem statement. Embedded documents,
                // explicit textual PDF URLs and real download/attachment links
                // are parsed through PDF.js below.
                if (!embedded && !explicit && !attachmentPath && !attachmentLabel) return;
                if (!links.includes(url)) links.push(url);
            } catch {}
        };
        doc?.querySelectorAll?.('a[href], iframe[src], embed[src], object[data]')?.forEach(el => {
            const tag = String(el.tagName || '').toLowerCase();
            add(el.getAttribute('href') || el.getAttribute('src') || el.getAttribute('data'), {
                embedded:tag !== 'a',
                label:el.textContent || el.getAttribute('title') || el.getAttribute('aria-label') || '',
            });
        });
        const markdownPdfRe = /!?\[([^\]\n]*)\]\(([^)"'\s<>]+\.pdf(?:[?#][^)"'\s<>]*)?)\)/gi;
        let match;
        while ((match = markdownPdfRe.exec(String(rawText || '')))) add(match[2], { explicit:true, label:match[1] });
        const barePdfRe = /(?:^|[\s("'=])((?:https?:\/\/|\.{0,2}\/|\/)?[A-Za-z0-9._~:/?#@!$&*+,;=%-]+\.pdf(?:[?#][A-Za-z0-9._~:/?#@!$&*+,;=%-]*)?)/gi;
        while ((match = barePdfRe.exec(String(rawText || '')))) add(match[1], { explicit:true });
        return links.slice(0, PDF_ATTACHMENT_MAX_FILES);
    },

    async fetchWithTimeout(url, options={}, timeoutMs=PDF_ATTACHMENT_FETCH_TIMEOUT_MS) {
        const ctrl = new AbortController();
        const t = setTimeout(() => ctrl.abort(), timeoutMs);
        try {
            return await fetch(url, { ...options, signal: ctrl.signal });
        } finally {
            clearTimeout(t);
        }
    },

    async loadPdfText(url) {
        const key = 'nzpdf_text_' + stableHash(url);
        try {
            const cached = await new Promise(r => window.__NZOI_SAFE_STORAGE__.local.get(key, d => r(d[key] || null)));
            if (cached?.text && Number(cached.parserVersion || 0) >= PDF_TEXT_CACHE_VERSION &&
                Date.now() - (cached.savedAt || 0) < PDF_ATTACHMENT_CACHE_MS) {
                return cached.text;
            }
        } catch {}
        // Always transport attachment bytes through the extension worker. A
        // fetch issued from this HTTPS page can be blocked as mixed content
        // before CORS handling, even when a background retry would succeed.
        const remote = await bg({ type:'network:fetchBinary', url, maxBytes:PDF_ATTACHMENT_MAX_BYTES });
        const binary = atob(String(remote?.base64 || ''));
        if (!binary.length) throw new Error('PDF attachment download was empty');
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
        const buffer = bytes.buffer;
        if (buffer.byteLength > PDF_ATTACHMENT_MAX_BYTES) throw new Error('PDF too large: ' + buffer.byteLength + ' bytes');
        const finalText = await extractPdfTextFromArrayBuffer(buffer);
        window.__NZOI_SAFE_STORAGE__.local.set({
            [key]: {
                url,
                text: finalText,
                parserVersion: PDF_TEXT_CACHE_VERSION,
                savedAt: Date.now(),
                bytes: buffer.byteLength,
            },
        });
        return finalText;
    },

    async enrichProblemTextWithPdfs(prob, doc, baseText) {
        const links = this.findPdfLinks(doc, prob.href, doc?.body?.innerText || baseText);
        if (!links.length) return baseText;
        LOG(`Found ${links.length} PDF attachment(s) for ${prob.name}`);
        const parts = [];
        let used = 0;
        const results = await Promise.allSettled(links.map(url => this.loadPdfText(url)));
        results.forEach((result, i) => {
            if (result.status !== 'fulfilled') {
                LOG(`Skipping unavailable optional PDF for ${prob.name}: ${links[i]} (${result.reason?.message || result.reason})`);
                return;
            }
            const text = result.value;
            const remaining = PDF_ATTACHMENT_TOTAL_TEXT_MAX_CHARS - used;
            if (remaining <= 0) return;
            const clipped = String(text || '').slice(0, remaining);
            used += clipped.length;
            parts.push(`\n\n[PDF attachment ${i + 1}: ${links[i]}]\n${clipped}`);
        });
        if (!parts.length) return baseText;
        return `${baseText}\n\n=== Attached PDF Text For Classification ===${parts.join('')}`;
    },

    _problemFetches: new Map(),

    // This is the single question parser used by both AI classification and the
    // questions.txt archive. The archive therefore records the exact untrimmed
    // parsed text that classification receives before provider token limits are
    // applied, including text extracted from direct or linked PDF files.
    fetchProblemContent(prob) {
        const key = String(prob.id || prob.href || '');
        setDashboardActivity(`Parsing question: ${prob.name || key}`);
        if (this._problemFetches.has(key)) return this._problemFetches.get(key);
        const task = (async () => {
            let lastError=null;
            for (let attempt=1;attempt<=PROBLEM_FETCH_MAX_ATTEMPTS;attempt++) {
                try {
                    const r = await this.fetchWithTimeout(prob.href, { credentials:'include', cache:'no-store' }, PROBLEM_FETCH_TIMEOUT_MS);
                    if (!r.ok) {
                        const error=new Error('HTTP ' + r.status);
                        error.status=r.status;
                        throw error;
                    }
                    const contentType = r.headers.get('content-type') || '';
                    const pageUrl = r.url || prob.href || '';
                    if (/application\/pdf/i.test(contentType) || /\.pdf(?:[?#]|$)/i.test(pageUrl)) {
                        const len = Number(r.headers.get('content-length') || 0);
                        if (len && len > PDF_ATTACHMENT_MAX_BYTES) throw new Error('PDF too large: ' + len + ' bytes');
                        const buffer = await r.arrayBuffer();
                        if (buffer.byteLength > PDF_ATTACHMENT_MAX_BYTES) throw new Error('PDF too large: ' + buffer.byteLength + ' bytes');
                        const pdfText = await extractPdfTextFromArrayBuffer(buffer);
                        return {
                            text: `${prob.name || ''}\n\n[Problem PDF: ${pageUrl}]\n${pdfText}`,
                            sourceType: 'pdf',
                            pageUrl,
                            contentType,
                            pdfLinks: [pageUrl],
                            fetchError: '',
                        };
                    }
                    const html = await r.text();
                    const doc = new DOMParser().parseFromString(html, 'text/html');
                    const baseText = doc.querySelector('.problem-description,.problem-statement')?.innerText || doc.body.innerText || prob.name || '';
                    const pdfLinks = this.findPdfLinks(doc, pageUrl || prob.href, doc.body?.innerText || baseText);
                    const text = await this.enrichProblemTextWithPdfs({ ...prob, href:pageUrl || prob.href }, doc, baseText);
                    return { text, sourceType: 'html', pageUrl, contentType, pdfLinks, fetchError: '' };
                } catch (e) {
                    lastError=e;
                    const permanentHttpError=[400,401,403,404,410].includes(Number(e?.status));
                    if (permanentHttpError || attempt>=PROBLEM_FETCH_MAX_ATTEMPTS) break;
                    const delay=Math.min(2_000,500*2**(attempt-1));
                    LOG(`Problem parse attempt ${attempt}/${PROBLEM_FETCH_MAX_ATTEMPTS} failed for ${prob.name}; retrying in ${delay}ms:`,e.message);
                    await sleep(delay);
                }
            }
            const error=new Error(`Could not load the problem statement after ${PROBLEM_FETCH_MAX_ATTEMPTS} attempt(s): ${lastError?.message || 'unknown fetch error'}`);
            error.name='ProblemContentUnavailableError';
            error.code='problem_content_unavailable';
            error.retryable=true;
            error.deferClassification=true;
            error.cause=lastError;
            setDashboardActivity('Error', 'error');
            throw error;
        })();
        this._problemFetches.set(key, task);
        task.then(()=>this._problemFetches.delete(key),()=>this._problemFetches.delete(key));
        return task;
    },

    validRawClassification(value) {
        const difficulty = String(value?.difficulty || '').trim().toLowerCase().replace(/[\s-]+/g, '_');
        const ratings = value?.estimated_rating;
        const confidence = Number(value?.confidence);
        return !!value &&
            ROUTER_DIFFICULTIES.includes(difficulty) &&
            ratings && typeof ratings === 'object' &&
            ['codeforces','atcoder','usaco','nzoi'].every(key => {
                const rating = Number(ratings[key]);
                return Number.isInteger(rating) && rating >= 500 && rating <= 3_000 && rating % 100 === 0;
            }) &&
            difficulty === difficultyFromRating(ratings.nzoi) &&
            typeof value.primary_skill === 'string' && value.primary_skill.trim().length > 0 &&
            Array.isArray(value.skills) && value.skills.length > 0 &&
            typeof value.reasoning_summary === 'string' && value.reasoning_summary.trim().length > 0 &&
            ['low','medium','high'].includes(value.risk_of_misclassification) &&
            Number.isFinite(confidence) && confidence >= 0 && confidence <= 1;
    },

    async classifyBatch(problems, sp=null, force=false) {
        if (!problems.length) return new Map();
        if (!this.hasProvider('classifier')) throw new Error('No AI provider is configured for classification');

        // Parse each statement once and persist that exact text to the durable
        // archive queue. Gist writes continue in the service worker while the
        // durable provider-tiered classification queue runs independently.
        const rawParsed = new Array(problems.length);
        const deferredErrors = new Map();
        let parseCursor = 0;
        const parseWorker = async () => {
            while (parseCursor < problems.length) {
                const index = parseCursor++;
                const prob=problems[index];
                try {
                    rawParsed[index] = await this.fetchProblemContent(prob);
                } catch(error) {
                    deferredErrors.set(String(prob.id),error);
                }
            }
        };
        await Promise.all(Array.from({ length:Math.min(QUESTION_ARCHIVE_WORKERS, problems.length) }, parseWorker));
        const preparedItems=[];
        problems.forEach((prob,index)=>{
            if (deferredErrors.has(String(prob.id))) return;
            try {
                preparedItems.push({prob,parsed:prepareParsedQuestion(prob,rawParsed[index])});
            } catch(error) {
                error.deferClassification=true;
                error.retryable=true;
                error.code=error.code||'problem_parse_failed';
                deferredErrors.set(String(prob.id),error);
            }
        });
        const output = new Map();
        output.deferredErrors=deferredErrors;
        if (!preparedItems.length) {
            if (deferredErrors.size) setDashboardActivity('Error', 'error');
            return output;
        }
        for (const item of preparedItems) {
            LOG(`Parsed question ${item.prob.id}: ${item.parsed.text.length} chars`);
        }

        // Queue parsed question records locally in IndexedDB-backed background
        // storage. GitHub rate limits must not hold classification hostage.
        setDashboardActivity('Queueing question statements');
        for (let offset = 0; offset < preparedItems.length; offset += QUESTION_ARCHIVE_BATCH_SIZE) {
            await questionArchive.persistParsedBatch(preparedItems.slice(offset, offset + QUESTION_ARCHIVE_BATCH_SIZE));
        }

        const pending = [];
        for (const item of preparedItems) {
            if (!force) {
                const cached = await this.readContentCache(item.prob, item.parsed.text);
                if (cached) {
                    output.set(String(item.prob.id), cached);
                    continue;
                }
            }
            item.previous = await new Promise(resolve =>
                window.__NZOI_SAFE_STORAGE__.local.get(`nztags_${item.prob.id}`, data =>
                    resolve(data[`nztags_${item.prob.id}`] || null)
                )
            );
            pending.push(item);
        }

        if (!pending.length) setDashboardActivity('Using saved classifications', 'success');
        else setDashboardActivity('Waiting for Gemini');
        const runId=`dashboard-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`;
        const jobs=[];
        for (let start = 0; start < pending.length; start += CLASSIFICATION_BATCH_SIZE) {
            const batch = pending.slice(start, start + CLASSIFICATION_BATCH_SIZE);
            const jobId = `nzoi-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
            const messages = await this.buildClassifierBatchMessages(batch);
            const items = batch.map(item => {
                const id = String(item.prob.id);
                const cacheKeys = this.cacheKeys(item.prob, item.parsed.text);
                return {
                    id,
                    prob:{ id, name:item.prob.name || '', href:item.prob.href || '' },
                    cacheMeta:{
                        cache_key:cacheKeys.full,
                        problem_hash:cacheKeys.contentHash,
                        question_parser_version:QUESTION_PARSER_VERSION,
                    },
                };
            });
            jobs.push({ id:jobId, items, messages, runId, sourceItems:batch });
        }
        for (let offset=0;offset<jobs.length;offset+=4) {
            await bg({type:'classifier:enqueue',jobs:jobs.slice(offset,offset+4).map(({sourceItems,...job})=>job),runId});
        }

        // A malformed or incomplete large response should not discard every
        // question in that batch. Keep completed IDs and retry only failures.
        const awaitJobOrSalvage=async context=>{
            const waiting=new Set(context.sourceItems.map(item=>String(item.prob.id)));
            const failed=new Map();
            while (waiting.size) {
                const ids=[...waiting];
                const keys=ids.flatMap(id=>[`nzoiClassifierTask_${id}`,`nztags_${id}`]);
                const stored=await new Promise(resolve=>window.__NZOI_SAFE_STORAGE__.local.get(keys,resolve));
                for (const id of ids) {
                    const task=stored[`nzoiClassifierTask_${id}`];
                    if (task?.batchId!==context.id) continue;
                    if (task.status==='failed') {
                        failed.set(id,new Error(task.error||`AI classification failed for question ${id}`));
                        waiting.delete(id);
                        continue;
                    }
                    if (task.status!=='complete') continue;
                    const cls=stored[`nztags_${id}`];
                    if (cls && cls.classification_batch_id===context.id && cache.isValid(cls)) output.set(id,cls);
                    else failed.set(id,new Error(`Google batch result is missing or invalid for question ${id}`));
                    waiting.delete(id);
                }
                if (waiting.size) await sleep(1500);
            }
            if (!failed.size) return;
            const failedItems=context.sourceItems.filter(item=>failed.has(String(item.prob.id)));
            const malformed=Array.from(failed.values()).some(error=>
                /invalid.*batch\s*json|batch.*(?:invalid|incomplete|missing)|(?:invalid|incomplete|missing).*(?:batch|batch_id|result)/i.test(error.message||'')
            );
            if (malformed && failedItems.length>1) {
                const half=Math.ceil(failedItems.length/2);
                LOG(`The classifier returned an incomplete batch for ${failedItems.length} question(s); retrying as smaller batches`);
                for (const subset of [failedItems.slice(0,half),failedItems.slice(half)].filter(items=>items.length)) {
                    const jobId=`nzoi-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,9)}`;
                    const messages=await this.buildClassifierBatchMessages(subset);
                    const cacheItems=subset.map(item=>{
                        const id=String(item.prob.id),keys=this.cacheKeys(item.prob,item.parsed.text);
                        return {id,prob:{id,name:item.prob.name||'',href:item.prob.href||''},cacheMeta:{
                            cache_key:keys.full,problem_hash:keys.contentHash,question_parser_version:QUESTION_PARSER_VERSION,
                        }};
                    });
                    const retryContext={id:jobId,sourceItems:subset};
                    await bg({type:'classifier:enqueue',jobs:[{id:jobId,items:cacheItems,messages,runId}],runId});
                    await awaitJobOrSalvage(retryContext);
                }
                return;
            }
            for (const [id,error] of failed) deferredErrors.set(id,error);
        };
        await Promise.all(jobs.map(awaitJobOrSalvage));
        return output;
    },

    async classifyProblem(prob, sp=null, force=false) {
        const results = await this.classifyBatch([prob], sp, force);
        const value = results.get(String(prob.id));
        if (!value && results.deferredErrors?.has(String(prob.id))) throw results.deferredErrors.get(String(prob.id));
        if (!value) throw new Error(`Classification missing for question ${prob.id}`);
        return value;
    },

    _queue: [],
    _queuedIds: new Set(),
    _activeIds: new Set(),
    _running: false,
    _uiFlushTimer: null,

    // ── Gist sync: gradual, coalesced, never overlapping ──────────────────────
    // The old approach called syncToGist() every 10 classifications, and each
    // call did window.__NZOI_SAFE_STORAGE__.local.get(null) (reading EVERY stored key,
    // including every saved code snapshot for every problem/language — not
    // just classifications) plus a full Gist read+merge+write, with calls
    // potentially overlapping if classification ran faster than the network
    // round-trip. That's the "lag the whole thing" bottleneck.
    //
    // Fix: track exactly which nztags_<id> keys changed since the last
    // successful sync (_dirtyKeys), and run at most ONE sync at a time
    // (_syncInFlight). Any classification/edit that finishes while a sync is
    // already running just marks _syncPending — the in-flight sync picks up
    // everything newly-dirtied in one immediate follow-up pass once it
    // completes, rather than starting a second overlapping read+write. This
    // collapses any burst of classifications into the minimum number of actual
    // Gist round-trips, and each round-trip only touches the keys that
    // actually changed instead of the entire storage area.
    _dirtyKeys: new Set(),
    _syncInFlight: false,
    _syncPending: false,
    _syncTimer: null,
    _syncRetryDelay: 0,

    markDirty(pid) { this._dirtyKeys.add(`nztags_${pid}`); },

    requestSync(delay=CLASSIFICATION_SYNC_DEBOUNCE_MS) {
        if (this._syncInFlight) { this._syncPending = true; return; }
        if (this._syncTimer) {
            if (delay > 0) return;
            clearTimeout(this._syncTimer);
            this._syncTimer = null;
        }
        const start = () => {
            this._syncTimer = null;
            if (!this._dirtyKeys.size) return;
            this._syncInFlight = true;
            this._runSync().finally(() => {
                this._syncInFlight = false;
                if (this._syncPending) {
                    this._syncPending = false;
                    const delay=this._syncRetryDelay||0; this._syncRetryDelay=0;
                    this.requestSync(delay);
                }
            });
        };
        if (delay > 0) this._syncTimer = setTimeout(start, delay);
        else start();
    },

    async _runSync() {
        if (!this._dirtyKeys.size) return;
        let dirty=[];
        try {
            const token = await new Promise(r => window.__NZOI_SAFE_STORAGE__.local.get('githubToken', d => r(d.githubToken || '')));
            if (!token) { this._dirtyKeys.clear(); return; }

            // Snapshot + clear the dirty set up front — anything marked dirty
            // WHILE this sync is in flight (e.g. another classification
            // finishes mid-request) re-populates it and triggers the
            // coalesced follow-up pass in requestSync() above, rather than
            // being silently dropped.
            dirty = [...this._dirtyKeys];
            this._dirtyKeys.clear();

            // Only fetch the specific keys that changed — not the entire
            // storage area (which also holds every saved code snapshot).
            const localChanged = await new Promise(r => window.__NZOI_SAFE_STORAGE__.local.get(dirty, r));

            setDashboardActivity('Saving classifications to Gist');
            const syncResult=await bg({type:'gist:mergeClassifications',token,data:localChanged});
            const pulledDown=Object.entries(syncResult?.pulledDown||{});

            if (pulledDown.length) {
                const updates = {};
                pulledDown.forEach(([k, gd]) => {
                    updates[k] = gd;
                    const pid = k.slice('nztags_'.length);
                    const prob = state.problems.find(p => String(p.id) === pid);
                    if (prob) {
                        Object.assign(prob, gd);
                        prob.searchIndex = `${prob.name} ${(prob.tags||[]).join(' ')} ${prob.rating}`.toLowerCase();
                        setSortKeys(prob);
                        (gd.tags||[]).forEach(t => state.allTags.add(t));
                    }
                });
                await new Promise(r => window.__NZOI_SAFE_STORAGE__.local.set(updates, r));
                LOG(`Gist sync: pulled down ${pulledDown.length} better classification(s) from gist`);
            }

            LOG(`Gist sync: ${dirty.length} changed key(s), ${syncResult?.total||0} total in file`);
            if (typeof ui !== 'undefined') {
                ui.flashSaved();
                if (pulledDown.length) { ui.populateFilters(); ui.updateTable(); ui.updateCounter(); }
            }
        } catch(e) {
            dirty.forEach(key=>this._dirtyKeys.add(key));
            this._syncRetryDelay=Math.max(Number(e.retryAfterMs)||0,e.retryable?60_000:10_000);
            this._syncPending=!!this._dirtyKeys.size;
            LOG('Gist sync deferred:', e.message);
            setDashboardActivity('Error', 'error');
        }
    },

    enqueue(newProbs) {
        if (!newProbs || !newProbs.length) return;
        let added = 0;
        newProbs.forEach(prob => {
            const pid = String(prob.id);
            if (this._queuedIds.has(pid) || this._activeIds.has(pid)) return;
            this._queuedIds.add(pid);
            this._queue.push(prob);
            added++;
        });
        if (!added) return;
        setDashboardActivity('Waiting for Gemini');
        LOG(`Queued ${added} new classification(s); ${this._queue.length} waiting`);
        if (!this._running) this._drain();
    },

    scheduleUiFlush(force=false) {
        if (typeof ui === 'undefined') return;
        if (force) { this.flushUi(); return; }
        if (this._uiFlushTimer) return;
        this._uiFlushTimer = setTimeout(() => this.flushUi(), CLASSIFICATION_UI_FLUSH_MS);
    },

    flushUi() {
        if (this._uiFlushTimer) {
            clearTimeout(this._uiFlushTimer);
            this._uiFlushTimer = null;
        }
        if (typeof ui === 'undefined') return;
        ui.populateFilters();
        ui.updateTable();
        ui.updateCounter();
    },

    async completeQueuedClassification(prob, cls, stats, workerId) {
        await this.saveClassification(prob, cls);
        Object.assign(prob, cls);
        delete prob.classificationDeferred;
        delete prob.deferReason;
        upsertProblems([prob]);
        (cls.tags || []).forEach(t => state.allTags.add(t));
        stats.comp++;
        LOG(`[OK w${workerId}] ${prob.name} -> ${cls.rating} [${(cls.tags || []).join(', ')}] via ${cls.classifiedBy} (${this._queue.length} queued)`);
        // The service worker owns durable classification Gist writes. Avoid a
        // second page-side Gist read/merge/write for the same result.
        this.scheduleUiFlush();
    },

    deferQueuedClassification(prob, error, stats, workerId='batch') {
        const message=String(error?.message||error||'Temporary classification failure').slice(0,240);
        prob.classificationDeferred=message;
        prob.deferReason=error?.code||'temporary_google_classification_failure';
        upsertProblems([prob]);
        stats.deferred++;
        LOG(`[DEFERRED w${workerId}]: ${prob.name} ${message}; use Reclassify to retry`);
        this.scheduleUiFlush();
    },

    async _drain() {
        this._running = true;
        let total = 0;
        const stats = { comp: 0, fail: 0, deferred: 0 };
        while (this._queue.length) {
            const batch = this._queue.splice(0);
            total += batch.length;
            batch.forEach(prob => {
                const id = String(prob.id);
                this._queuedIds.delete(id);
                this._activeIds.add(id);
            });
            LOG(`Starting one classification batch: ${batch.length} problem(s), ${this._queue.length} waiting`);
            setDashboardActivity('Parsing questions');
            try {
                const results = await this.classifyBatch(batch);
                for (const prob of batch) {
                    const id=String(prob.id);
                    const cls = results.get(id);
                    if (!cls) {
                        const error=results.deferredErrors?.get(id)||new Error(`Classification result is missing for question ${id}`);
                        this.deferQueuedClassification(prob,error,stats,'batch');
                        continue;
                    }
                    await this.completeQueuedClassification(prob, cls, stats, 'batch');
                }
            } catch (e) {
                batch.forEach(prob => {
                    prob.classificationDeferred = String(e.message || e).slice(0,240);
                    prob.deferReason=e?.code||'temporary_google_classification_failure';
                    stats.deferred++;
                });
                upsertProblems(batch);
                LOG('Classification batch deferred for retry:', e.message);
                setDashboardActivity('Error', 'error');
                this.scheduleUiFlush();
            } finally {
                batch.forEach(prob => this._activeIds.delete(String(prob.id)));
            }
        }
        this._running = false;
        this.flushUi();
        this.requestSync(0);
        LOG(`Classification complete: ${stats.comp} ok, ${stats.deferred} deferred, ${stats.fail} failed (of ${total} queued this round)`);
        if (this._queue.length) this._drain();
    },

    async reclassify(pid, sp=null) {
        LOG(`Reclassifying pid=${pid} sp=${sp||'any'}`);
        const prob = state.problems.find(p=>String(p.id)===String(pid));
        if (!prob) { ERR('Problem not found in state:', pid); return; }
        state.reclassifying.add(String(pid)); ui.updateRow(String(pid), true);
        try {
            const cls = await this.classifyProblem(prob, sp, true);
            await this.saveClassification(prob, cls);
            Object.assign(prob, cls);
            delete prob.classificationDeferred;
            delete prob.deferReason;
            prob.searchIndex = `${prob.name} ${(prob.tags||[]).join(' ')} ${prob.rating}`.toLowerCase();
            setSortKeys(prob);
            cls.tags.forEach(t => state.allTags.add(t));
            LOG(`Reclassified: ${prob.name} → ${cls.rating} via ${cls.classifiedBy}`);
            // Reclassification was persisted by the background queue already.
        } catch(e) {
            ERR('Reclassify failed:', e.message);
            prob.classificationDeferred=String(e.message||e).slice(0,240);
            prob.deferReason=e?.code||'temporary_google_classification_failure';
            alert(`Reclassification is waiting for a configured AI provider/model: ${e.message}`);
        }
        state.reclassifying.delete(String(pid)); ui.updateTable();
    },
};

// Reflect completed background classification writes as soon as they arrive.
window.__NZOI_SAFE_STORAGE__.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    const updates=[];
    for (const [key, change] of Object.entries(changes)) {
        const match=key.match(/^nztags_(\d+)$/), cls=change?.newValue;
        if (!match) continue;
        const existing=state.problemById.get(match[1]);
        if (!cls && existing) {
            existing.tags=null; existing.rating=null; existing.classificationDeferred='';
            ['difficulty','estimated_rating','primary_skill','skills','reasoning_summary','confidence','classifiedBy','classifiedAt','tier1_provider','tier1_model','tier2_provider','tier2_model','tier2_status','classification_batch_id'].forEach(field=>delete existing[field]);
            updates.push(existing);
            continue;
        }
        if (!cache.isValid(cls)) continue;
        if (existing?.classifiedBy==='manual') continue;
        const base=existing || {id:match[1],name:cls.problem_title||`Problem ${match[1]}`,href:cls.problem_url||''};
        updates.push({...base,...cls,id:match[1],classificationDeferred:''});
    }
    if (!updates.length) return;
    upsertProblems(updates);
    updates.forEach(problem=>(problem.tags||[]).forEach(tag=>state.allTags.add(tag)));
    if (typeof ui !== 'undefined') classifier.scheduleUiFlush();
});

window.__NZOI_SAFE_STORAGE__.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.nzoiQuestionArchiveQueueStatus) return;
    questionArchive._pendingCount=Number(changes.nzoiQuestionArchiveQueueStatus.newValue?.pending)||0;
    questionArchive._lastError=String(changes.nzoiQuestionArchiveQueueStatus.newValue?.lastError||'');
    questionArchive._activity=String(changes.nzoiQuestionArchiveQueueStatus.newValue?.activity||'');
    questionArchive.updateStatus();
});

// ─── Question text Gist archive ──────────────────────────────────────────────

function sanitizeParsedQuestionText(value) {
    return String(value || '')
        .replace(/\r\n?/g, '\n')
        .replace(/\u00a0/g, ' ')
        .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '')
        .split('\n')
        .map(line => line.replace(/[ \t]+$/g, ''))
        .join('\n')
        .replace(/\n{4,}/g, '\n\n\n')
        .trim();
}

function prepareParsedQuestion(prob, parsedProblem) {
    const text = sanitizeParsedQuestionText(parsedProblem?.text || prob?.name || '');
    if (!text) throw new Error(`Question parser returned empty text for ${prob?.id || prob?.name || 'unknown problem'}`);
    return {
        ...(parsedProblem || {}),
        text,
        parserVersion:QUESTION_PARSER_VERSION,
        extractionMode:'parser-only',
    };
}

const questionArchive = {
    _token: '',
    _ready: null,
    _knownIds: new Set(),
    _queuedIds: new Set(),
    _queue: [],
    _running: false,
    _retryTimer: null,
    _remoteTotal: 0,
    _pendingCount: 0,
    _lastError: '',
    _activity: '',
    _writeTail: Promise.resolve(),

    updateStatus(message='') {
        const el = document.getElementById('archive-status');
        if (!el) return;
        const pending = Math.max(this._pendingCount, this._queuedIds.size);
        el.textContent = message || (pending ? `${pending.toLocaleString()} waiting for Gist` : 'Question archive synced');
        const error = String(this._lastError || '').trim().slice(0, 260);
        const statusMessage = String(message || '').trim();
        let description;
        if (/parsing will retry/i.test(statusMessage)) {
            description = `${pending.toLocaleString()} question statement(s) are waiting for extraction. Parsing paused after an error and is scheduled to retry automatically.`;
        } else if (/add a github token/i.test(error)) {
            description = `${pending.toLocaleString()} question statement(s) are queued for Gist upload. Add a GitHub token in the extension settings to enable syncing. ${error}`;
        } else if (rateLimitStatusMessage(error)) {
            description = `${pending.toLocaleString()} question statement(s) remain queued. GitHub temporarily rate-limited the Gist write; the background archive will retry after the service allows another request. Last error: ${error}`;
        } else if (error) {
            description = `${pending.toLocaleString()} question statement(s) remain queued for Gist upload. The background archive is retaining them after a sync error. Last error: ${error}`;
        } else if (pending) {
            description = `${pending.toLocaleString()} question statement(s) are waiting to be saved to the linked Gist by the background archive.`;
        } else {
            description = 'Question statements are stored in the linked Gist. No statements are currently waiting to upload.';
        }
        el.title = description;
        el.setAttribute('aria-label', `${el.textContent}. ${description}`);
        if (this._lastError || this._activity === 'Error') setDashboardActivity('Error', 'error');
        else if (this._activity) setDashboardActivity(this._activity, this._activity.includes('saved to Gist') ? 'success' : 'working');
        else if (pending) setDashboardActivity('Waiting for Gist');
    },

    async init() {
        if (this._ready) return this._ready;
        this._ready = (async () => {
            const data=await new Promise(r=>window.__NZOI_SAFE_STORAGE__.local.get(['githubToken','nzoiQuestionArchiveQueueStatus'],r));
            this._token=data.githubToken || '';
            this._pendingCount=Number(data.nzoiQuestionArchiveQueueStatus?.pending)||0;
            this._lastError=String(data.nzoiQuestionArchiveQueueStatus?.lastError||'');
            this._activity=String(data.nzoiQuestionArchiveQueueStatus?.activity||'');
            this.updateStatus();
            return true;
        })();
        return this._ready;
    },

    enqueue(problems) {
        for (const prob of problems || []) {
            const id = String(prob?.id || '');
            if (!/^\d+$/.test(id) || this._knownIds.has(id) || this._queuedIds.has(id)) continue;
            this._queuedIds.add(id);
            this._queue.push({prob,attempts:0,nextAttemptAt:0});
        }
        this.updateStatus();
        if (this._queue.length && !this._running) {
            if (this._retryTimer) { clearTimeout(this._retryTimer); this._retryTimer=null; }
            this._drain();
        }
    },

    makeRecord(prob, parsed) {
        return {
            id: String(prob.id),
            parserVersion: Number(parsed.parserVersion || QUESTION_PARSER_VERSION),
            title: prob.name || '',
            url: prob.href || parsed.pageUrl || '',
            resolvedUrl: parsed.pageUrl || prob.href || '',
            group: prob.group || '',
            progress: Number.isFinite(prob.progress) ? prob.progress : null,
            sourceType: parsed.sourceType || 'unknown',
            contentType: parsed.contentType || '',
            pdfLinks: Array.isArray(parsed.pdfLinks) ? parsed.pdfLinks : [],
            capturedAt: new Date().toISOString(),
            fetchError: parsed.fetchError || '',
            text: parsed.text || prob.name || '',
            extractionMode: parsed.extractionMode || 'parser-only',
        };
    },

    async _commitEntries(entries) {
        if (!entries.length) return { queued:0, pending:this._pendingCount };
        const ordered=[...entries].sort((a,b)=>Number(a.id)-Number(b.id));
        const result=await bg({type:'gist:queueQuestions',questions:ordered});
        ordered.forEach(entry=>this._knownIds.add(String(entry.id)));
        this._pendingCount=Number(result?.pending)||this._pendingCount;
        this.updateStatus();
        return result;
    },

    // Parsed statements enter a durable service-worker queue. A temporary GitHub
    // limit can delay the Gist write without keeping classification on hold.
    async persistParsedBatch(items) {
        const records = items.map(item => this.makeRecord(item.prob, item.parsed));
        const result=await this._commitEntries(records);
        this._pendingCount=Number(result?.pending)||this._pendingCount;
        this.updateStatus();
    },

    async _drain() {
        if (this._running) return;
        this._running = true;
        try {
            while (this._queue.length) {
                const now=Date.now();
                const due=this._queue.filter(entry=>(Number(entry.nextAttemptAt)||0)<=now).slice(0,QUESTION_ARCHIVE_BATCH_SIZE);
                if (!due.length) break;
                const dueSet=new Set(due);
                this._queue=this._queue.filter(entry=>!dueSet.has(entry));
                const candidates=due.filter(entry=>{
                    const id=String(entry.prob?.id||'');
                    if (this._knownIds.has(id)) { this._queuedIds.delete(id); return false; }
                    return true;
                });
                if (!candidates.length) continue;

                const parsedEntries=[];
                const failures=[];
                setDashboardActivity('Parsing question statements');
                let cursor=0;
                const worker=async()=>{
                    while(cursor<candidates.length) {
                        const entry=candidates[cursor++], prob=entry.prob;
                        try {
                            const parsed=prepareParsedQuestion(prob,await classifier.fetchProblemContent(prob));
                            parsedEntries.push({entry,record:this.makeRecord(prob,parsed)});
                        } catch(error) {
                            failures.push({entry,error});
                        }
                }
                };
                await Promise.all(Array.from({length:Math.min(QUESTION_ARCHIVE_WORKERS,candidates.length)},worker));

                // Classification may have queued these same statements while
                // the archive workers were fetching them. That durable ack is
                // enough; do not enqueue the duplicate parse result as well.
                const unqueued=parsedEntries.filter(({entry})=>!this._knownIds.has(String(entry.prob.id)));
                parsedEntries.filter(({entry})=>this._knownIds.has(String(entry.prob.id))).forEach(({entry})=>{
                    this._queuedIds.delete(String(entry.prob.id));
                });
                if (unqueued.length) {
                    try {
                        setDashboardActivity('Queueing question statements');
                        await this._commitEntries(unqueued.map(item=>item.record));
                        unqueued.forEach(({entry})=>{
                            this._queuedIds.delete(String(entry.prob.id));
                        });
                    } catch(error) {
                        unqueued.forEach(({entry})=>failures.push({entry,error}));
                    }
                }

                for (const {entry,error} of failures) {
                    entry.attempts=(Number(entry.attempts)||0)+1;
                    const delay=Math.min(15*60_000,5_000*2**Math.min(entry.attempts-1,7));
                    entry.nextAttemptAt=Date.now()+delay;
                    this._queue.push(entry);
                    this._lastError=String(error?.message||error||'Question archive retry pending').slice(0,300);
                }
                if (failures.length) {
                    setDashboardActivity('Error', 'error');
                    this.updateStatus('Question parsing will retry');
                }
                else this.updateStatus();
            }
        } finally {
            this._running = false;
            if (!this._queue.length) {
                this._lastError='';
                this.updateStatus();
            } else {
                const delay=Math.max(500,Math.min(...this._queue.map(entry=>Math.max(0,(Number(entry.nextAttemptAt)||0)-Date.now()))));
                if (this._retryTimer) clearTimeout(this._retryTimer);
                this._retryTimer=setTimeout(()=>{this._retryTimer=null;void this._drain();},delay);
            }
        }
    },
};

// ─── Cache ────────────────────────────────────────────────────────────────────

// Classification "quality" ranking, used when merging local vs. Gist data so a
// fallback/heuristic result never silently overwrites a better one already
// shared in the Gist (and vice versa — a better local result still wins).
//   manual   (user explicitly set tags/rating in the UI) — highest, always wins
//   Google Gemini classification results                  — normal
//   fallback / missing                                     — lowest
function classificationQuality(cls) {
    const by = cls?.classifiedBy;
    if (by === 'manual') return 2;
    if (!by || by === 'fallback') return 0;
    return 1;
}

// True if `a` should be kept over `b` when merging. Absent/invalid entries
// always lose. At the same quality level, the entry with MORE tags (more
// information) wins; an exact tie prefers `a` (the candidate being written).
function isBetterClassification(a, b) {
    const av = cache.isValid(a), bv = cache.isValid(b);
    if (!av) return false;
    if (!bv) return true;
    const ta = classificationQuality(a), tb = classificationQuality(b);
    if (ta !== tb) return ta > tb;
    return (a.tags?.length || 0) >= (b.tags?.length || 0);
}

let gistClassificationSnapshotPromise = null;
const cache = {
    isValid: d => Array.isArray(d?.tags) && d.tags.length > 0 && typeof d?.rating === 'number' && d.rating >= 500,

    // Fast path: window.__NZOI_SAFE_STORAGE__.local only — no network. Called before first render.
    async loadLocal(all) {
        if (!all.length) return { cached: [], uncached: [] };
        const keys = all.map(p=>`nztags_${p.id}`);
        const stored = await new Promise(r => window.__NZOI_SAFE_STORAGE__.local.get(keys, r));
        const cached=[], uncached=[];
        all.forEach(p => {
            const d = stored[`nztags_${p.id}`];
            if (d && this.isValid(d)) {
                const mp = { ...p, ...d };
                mp.searchIndex = `${mp.name} ${(mp.tags||[]).join(' ')} ${mp.rating}`.toLowerCase();
                setSortKeys(mp);
                cached.push(mp); d.tags.forEach(t=>state.allTags.add(t));
            } else uncached.push(p);
        });
        LOG(`Local cache: ${cached.length} cached, ${uncached.length} uncached`);
        return { cached, uncached };
    },

    // Slow path: hits the Gist API. Called AFTER the first render so it never
    // blocks initial paint.
    async restoreFromGist(uncached) {
        if (!uncached.length) return { restored: [], stillUncached: uncached };
        try {
            if (!gistClassificationSnapshotPromise) {
                gistClassificationSnapshotPromise = (async()=>{
                    const token = await new Promise(r => window.__NZOI_SAFE_STORAGE__.local.get('githubToken', d => r(d.githubToken || '')));
                    if (!token) return {};
                    return bg({ type:'gist:loadClassifications', token });
                })().catch(error=>{ gistClassificationSnapshotPromise=null; throw error; });
            }
            const gistClasses = await gistClassificationSnapshotPromise;
            const restored=[], stillUncached=[];
            uncached.forEach(p => {
                const gd = gistClasses[`nztags_${p.id}`];
                if (gd && this.isValid(gd)) {
                    const mp = { ...p, ...gd };
                    mp.searchIndex = `${mp.name} ${(mp.tags||[]).join(' ')} ${mp.rating}`.toLowerCase();
                    setSortKeys(mp);
                    restored.push(mp); gd.tags.forEach(t=>state.allTags.add(t));
                    window.__NZOI_SAFE_STORAGE__.local.set({ [`nztags_${p.id}`]: gd });
                } else { stillUncached.push(p); }
            });
            LOG(`Gist restore: ${restored.length} restored, ${stillUncached.length} still need AI`);
            return { restored, stillUncached };
        } catch(e) { LOG('Gist classification restore skipped:', e.message); return { restored: [], stillUncached: uncached }; }
    },

    async clearAll() {
        if (!confirm('Clear all classifications?')) return;
        const all = await new Promise(r=>window.__NZOI_SAFE_STORAGE__.local.get(null,r));
        const keys = Object.keys(all).filter(k=>k.startsWith('nztags_'));
        await new Promise(r=>window.__NZOI_SAFE_STORAGE__.local.remove(keys,r));
        LOG('Cleared', keys.length, 'classifications');
        location.reload();
    },

    async refreshAll() {
        if (!confirm('Re-classify all problems with the current question/PDF parser? This clears local and Gist classifications first.')) return;
        const all = await new Promise(r=>window.__NZOI_SAFE_STORAGE__.local.get(null,r));
        const keys = Object.keys(all).filter(k=>k.startsWith('nztags_'));
        await new Promise(r=>window.__NZOI_SAFE_STORAGE__.local.remove(keys,r));
        try {
            const token = await new Promise(r => window.__NZOI_SAFE_STORAGE__.local.get('githubToken', d => r(d.githubToken || '')));
            if (token) await bg({ type:'gist:saveClassifications', token, data: {} });
        } catch(e) {
            LOG('Gist classification clear skipped:', e.message);
        }
        location.reload();
    },
};

// ─── Scrapers ─────────────────────────────────────────────────────────────────

const scrapers = {
    _pageFetchLimit:4,
    _pageFetchActive:0,
    _pageFetchWaiters:[],

    nzoiUrl(href) {
        try { return new URL(href || '/', 'https://train.nzoi.org.nz').href; }
        catch { return 'https://train.nzoi.org.nz/'; }
    },

    async fetchScrapePage(url) {
        if (this._pageFetchActive>=this._pageFetchLimit) {
            await new Promise(resolve=>this._pageFetchWaiters.push(resolve));
        } else {
            this._pageFetchActive++;
        }
        try {
            return await fetch(url,{credentials:'include',cache:'no-store'});
        } finally {
            const next=this._pageFetchWaiters.shift();
            if (next) next();
            else this._pageFetchActive--;
        }
    },

    getMyGroups() {
        const g=[];
        const seen = new Set();
        const addGroup = l => {
            if(!l || !l.length) return;
            const canonical = this.groupBaseUrl(this.nzoiUrl(l.attr('href')));
            if (!canonical) return;
            if(seen.has(canonical)) return;
            seen.add(canonical);
            const base = new URL(canonical);
            g.push({name:l.text().trim() || `Group ${base.pathname.split('/').filter(Boolean).pop()}`,href:canonical});
        };
        $('h2').filter((_, h) => /My Groups/i.test($(h).text())).first().nextAll('div').each((_, div)=>{
            const l=$(div).find('a[href*="/groups/"]').first();
            addGroup(l);
        });
        if (g.length < 2) $('a[href*="/groups/"]').each((_, a) => addGroup($(a)));
        g.sort((a,b)=>a.name.localeCompare(b.name, undefined, {sensitivity:'base'}));
        LOG('Groups:', g.map(x=>x.name));
        return g;
    },

    // Group pages can be linked by numeric ID, slug, or a nested route such as
    // /groups/<slug>/problems. Normalize known child routes to the group root;
    // keep unknown nested paths as their own safe family base.
    groupBaseUrl(value) {
        let url;
        try { url = new URL(value, 'https://train.nzoi.org.nz'); } catch { return ''; }
        if (url.origin !== 'https://train.nzoi.org.nz') return '';
        const parts = url.pathname.split('/').filter(Boolean);
        if (parts[0] !== 'groups' || parts.length < 2) return '';
        if (/^(?:new|search|join)$/i.test(parts[1])) return '';
        const childRoutes = new Set(['problems','submissions','members','settings','edit','activity','leaderboard','solutions','results']);
        const childIndex = parts.findIndex((part, index) => index >= 2 && childRoutes.has(part.toLowerCase()));
        const rootParts = childIndex >= 0 ? parts.slice(0, childIndex) : parts;
        url.pathname = `/${rootParts.join('/')}`;
        url.search = '';
        url.hash = '';
        return url.href.replace(/\/$/, '');
    },

    getUpcomingContests() {
        const c=[];
        $('h2:contains("Upcoming and Current Contests")').next('table').find('tbody tr').each(function(){
            const cells=$(this).find('td');
            if(cells.length>=6) c.push({title:$(cells[0]).text().trim(),startTime:$(cells[1]).text().trim(),endTime:$(cells[2]).text().trim(),href:$(cells[5]).find('a').attr('href')});
        });
        c.sort((a,b)=>a.title.localeCompare(b.title, undefined, {sensitivity:'base'}));
        return c;
    },

    // Shared extraction logic. Pushes newly-seen problems (deduped via
    // state.seenIds) from any /problems/N link. If the link lives in a table row
    // we also read the progress cell; otherwise it still appears as a problem.
    procDOM(doc, gn, into, updated=[]) {
        if (!doc) return;
        doc.querySelectorAll('a[href*="/problems/"]').forEach(lnk=>{
            if(!lnk) return;
            const href=this.nzoiUrl(lnk.getAttribute('href'));
            const id=(href.match(/\/problems\/(\d+)/)||[])[1];
            if(!id||!/^\d+$/.test(id)) return;
            const row=lnk.closest('tr'), cells=row?.children || [];
            const name=lnk.textContent.trim(), progTxt=cells[1]?.textContent.trim()||'';
            let prog=0;
            if(progTxt.includes('%')) prog=parseInt(progTxt)||0;
            else if(progTxt.includes('/')) { const[s,t]=progTxt.split('/').map(Number); if(!isNaN(s)&&!isNaN(t)&&t>0) prog=Math.round(s/t*100); }
            const existing = state.problemById.get(id) || state.discoveredById.get(id) || into.find(problem => String(problem.id) === id);
            if (existing) {
                // Keep the strongest progress if the same problem appears in
                // multiple group tables or a later page has fresher progress.
                if (prog > Number(existing.progress || 0)) {
                    existing.progress = prog;
                    if (!updated.some(problem => String(problem.id) === id)) updated.push(existing);
                }
                if (!existing.name && name) existing.name = name;
                if (!state.seenIds.has(id)) state.seenIds.add(id);
                return;
            }
            if(state.seenIds.has(id)) return;
            state.seenIds.add(id);
            const problem={id,name,href,group:gn,progress:prog};
            state.discoveredById.set(id,problem);
            into.push(problem);
        });
    },

    // SYNCHRONOUS, no fetch — every "Public Problems" subtable is already
    // present in the home page's DOM (hidden behind a "Show" toggle), so this
    // gives us a full first paint instantly.
    getOwnPageProblems(updated=[]) {
        const all=[];
        $('.subheading').each((_, el) => {
            const raw = $(el).find('td:first').text().trim();
            const gn = raw.replace(/\(\d+\s*problems?\)\s*$/i, '').trim() || 'Public';
            const holder = $(el).next('tr').find('[id]').first()[0] || $(el).next('tr')[0];
            this.procDOM(holder, gn, all, updated);
        });
        // Scan the full server-rendered document even when the structured
        // section scan found some rows. Some themes place additional problem
        // links outside the first identified holder; procDOM deduplicates and
        // keeps the strongest progress value when the same problem appears twice.
        this.procDOM(document, 'Public', all, updated);
        LOG(`Own-page problems: ${all.length}`);
        return all;
    },

    paginationLinks(doc, familyUrl, descendants=false) {
        const links = [];
        let base;
        try { base = new URL(familyUrl); } catch { return links; }
        const rootPath = base.pathname.replace(/\/+$/, '');
        doc.querySelectorAll('a[href]').forEach(anchor => {
            const href = anchor.getAttribute('href') || '';
            const looksLikePager = anchor.matches('[rel="next"], .pagination a, .pager a') || /[?&]page=\d+/i.test(href);
            if (!looksLikePager) return;
            let url;
            try { url = new URL(href, base); } catch { return; }
            const path = url.pathname.replace(/\/+$/, '');
            const inFamily = path === rootPath || (descendants && path.startsWith(rootPath + '/'));
            if (!inFamily) return;
            if (url.origin !== base.origin) return;
            url.hash = '';
            // Normalize parameter order so tracking parameters or reordered
            // query strings cannot cause the same page to be crawled repeatedly.
            const params = [...url.searchParams.entries()].sort(([ak,av],[bk,bv]) => ak.localeCompare(bk) || av.localeCompare(bv));
            url.search = '';
            params.forEach(([key,value]) => url.searchParams.append(key,value));
            links.push(url.href);
        });
        return [...new Set(links)];
    },

    // Optional home-page pagination is discovered and crawled only after the
    // synchronous first paint. If the home page has no pager links, this does
    // no network work.
    async getOwnPagePaginationProblems(initialLinks=[], updated=[], onPage=null) {
        const all=[];
        let home;
        try { home = new URL(location.href); } catch { return all; }
        if (home.origin !== 'https://train.nzoi.org.nz') return all;
        home.hash = '';
        const pending=[...new Set([...(initialLinks || []), ...this.paginationLinks(document, home.href, false)])];
        const visited=new Set([home.href]);
        const updatedIds=new Set((updated||[]).map(problem=>String(problem.id)));
        while (pending.length && visited.size < 40) {
            const batch=[];
            while (pending.length && batch.length<this._pageFetchLimit && visited.size<40) {
                const href=pending.shift();
                let url;
                try { url=new URL(href); } catch { continue; }
                if (url.origin!==home.origin || url.pathname.replace(/\/+$/,'')!==home.pathname.replace(/\/+$/,'')) continue;
                if (visited.has(url.href)) continue;
                visited.add(url.href);
                batch.push(url.href);
            }
            if (!batch.length) break;
            const pages=await Promise.all(batch.map(async href=>{
                try {
                    const response=await this.fetchScrapePage(href);
                    const text=await response.text();
                    if (!response.ok) throw new Error('HTTP '+response.status);
                    let finalUrl;
                    try { finalUrl=new URL(response.url); } catch { finalUrl=null; }
                    if (!finalUrl || finalUrl.origin!==home.origin || finalUrl.pathname.replace(/\/+$/,'')!==home.pathname.replace(/\/+$/,'')) {
                        throw new Error('pagination left the current training page');
                    }
                    const doc=new DOMParser().parseFromString(text,'text/html');
                    if (/\/accounts\/sign_in/i.test(finalUrl.pathname) || doc.querySelector('form[action*="sign_in"]')) {
                        throw new Error('session expired; sign in to NZOI again');
                    }
                    const pageProblems=[],pageUpdates=[];
                    this.procDOM(doc,'Public',pageProblems,pageUpdates);
                    all.push(...pageProblems);
                    pageUpdates.forEach(problem=>{
                        const id=String(problem.id);
                        if (!updatedIds.has(id)) { updatedIds.add(id); updated.push(problem); }
                    });
                    if (typeof onPage==='function' && (pageProblems.length || pageUpdates.length)) {
                        try { await onPage(pageProblems,pageUpdates); }
                        catch(error) { ERR('Home page ingestion failed:',href,error.message); }
                    }
                    return this.paginationLinks(doc,home.href,false);
                } catch(error) {
                    ERR('Home problem page fetch failed:',href,error.message);
                    return [];
                }
            }));
            pages.flat().forEach(next=>{ if (!visited.has(next) && !pending.includes(next)) pending.push(next); });
        }
        LOG(`Home pagination: ${all.length} additional problems across ${visited.size-1} page(s)`);
        return all;
    },

    // Fetch every page for one private group. Current NZOI group pages normally
    // contain every problem set at once; the pager crawl also covers alternate
    // themes and future server-side pagination without leaving the group route.
    async getGroupPageProblems(g, updated=[], onPage=null) {
        const all=[];
        const baseHref=this.groupBaseUrl(g.href);
        if (!baseHref) return all;
        const pending=[baseHref];
        const visited=new Set();
        const updatedIds=new Set((updated||[]).map(problem=>String(problem.id)));
        while (pending.length && visited.size < 100) {
            const batch=[];
            while (pending.length && batch.length<this._pageFetchLimit && visited.size<100) {
                const value=pending.shift();
                let normalized;
                try { normalized=new URL(value); } catch { continue; }
                normalized.hash='';
                const canonical=normalized.href;
                if (visited.has(canonical)) continue;
                visited.add(canonical);
                batch.push(canonical);
            }
            if (!batch.length) break;
            const pages=await Promise.all(batch.map(async canonical=>{
                try {
                    const r=await this.fetchScrapePage(canonical);
                    const text=await r.text();
                    if (!r.ok) throw new Error('HTTP '+r.status);
                    let finalUrl;
                    try { finalUrl=new URL(r.url); } catch { finalUrl=null; }
                    const base=new URL(baseHref);
                    if (!finalUrl || finalUrl.origin!==base.origin || !(finalUrl.pathname.replace(/\/+$/,'')===base.pathname || finalUrl.pathname.startsWith(base.pathname+'/'))) {
                        throw new Error('group pagination left this group route');
                    }
                    const doc=new DOMParser().parseFromString(text,'text/html');
                    if (/\/accounts\/sign_in/i.test(finalUrl.pathname) || doc.querySelector('form[action*="sign_in"]')) {
                        throw new Error('session expired; sign in to NZOI again');
                    }
                    const pageProblems=[],pageUpdates=[];
                    this.procDOM(doc,g.name,pageProblems,pageUpdates);
                    all.push(...pageProblems);
                    pageUpdates.forEach(problem=>{
                        const id=String(problem.id);
                        if (!updatedIds.has(id)) { updatedIds.add(id); updated.push(problem); }
                    });
                    if (typeof onPage==='function' && (pageProblems.length || pageUpdates.length)) {
                        try { await onPage(pageProblems,pageUpdates); }
                        catch(error) { ERR('Group page ingestion failed:',g.name,canonical,error.message); }
                    }
                    return this.paginationLinks(doc,baseHref,true);
                } catch(error) {
                    ERR('Group fetch failed:',g.name,canonical,error.message);
                    return [];
                }
            }));
            pages.flat().forEach(next=>{ if (!visited.has(next) && !pending.includes(next)) pending.push(next); });
        }
        LOG(`Group ${g.name}: ${all.length} unique new problems across ${visited.size} page(s)`);
        return all;
    },
};

// Archive the best judged source for every problem with recorded progress.
// The site session stays in the page's origin; only the source selected as the
// current best is sent to the extension's existing private-Gist writer.
const bestSubmissionArchive = (() => {
    const PROGRESS_KEY = 'nzoiBestSubmissionProgress';
    const RECORD_PREFIX = 'nzoiBestSubmission_';
    const WORKERS = 2;
    const REQUEST_TIMEOUT_MS = 18_000;
    const MAX_LIST_PAGES = 60;
    let progress = { total:0, completed:0, saved:0, failed:0, status:'idle' };
    let progressWrites = Promise.resolve();
    let startTail = Promise.resolve();
    const startedProblemProgress = new Map();

    const storageGet = key => new Promise(resolve => window.__NZOI_SAFE_STORAGE__.local.get(key, data => resolve(data[key])));
    const storageSet = values => new Promise((resolve, reject) => window.__NZOI_SAFE_STORAGE__.local.set(values, () => {
        let error = null;
        try { error = typeof nzoiRuntimeForBridge === 'function' ? nzoiRuntimeForBridge()?.lastError || null : null; }
        catch (runtimeError) {
            if (typeof nzoiIsExtensionContextInvalidated === 'function' && nzoiIsExtensionContextInvalidated(runtimeError)) {
                return reject(nzoiMarkExtensionContextInvalidated(runtimeError));
            }
            return reject(runtimeError);
        }
        if (error) reject(new Error(error.message)); else resolve();
    }));

    function publishProgress() {
        const snapshot = { ...progress, updatedAt:Date.now() };
        progressWrites = progressWrites.catch(() => {}).then(() => storageSet({ [PROGRESS_KEY]:snapshot }));
        return progressWrites;
    }

    function parseSubmissionId(value) {
        try {
            const url = new URL(value, location.origin);
            if (url.origin !== location.origin) return null;
            return url.pathname.match(/\/submissions?\/(\d+)(?:\/|$)/i)?.[1] || null;
        } catch { return null; }
    }

    function parseScore(value) {
        const match = String(value || '').match(/\b(\d+(?:\.\d+)?)\s*%/);
        if (match) return Math.max(0, Math.min(100, Number(match[1])));
        const ratio = String(value || '').match(/\b(\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)/);
        if (ratio && Number(ratio[2]) > 0 && Number(ratio[1]) <= Number(ratio[2]) && Number(ratio[2]) <= 1000) {
            return Math.max(0, Math.min(100, Number(ratio[1]) / Number(ratio[2]) * 100));
        }
        if (/\b(?:accepted|fully correct|all tests passed)\b/i.test(String(value || ''))) return 100;
        return null;
    }

    function scoreFromElement(element) {
        if (!element) return null;
        for (const node of [element, ...element.querySelectorAll('[class],[id]')]) {
            const classes = `${node.id || ''} ${typeof node.className === 'string' ? node.className : ''}`;
            const match = classes.match(/\bscore_(\d{1,2})x\b/i);
            if (match) return Math.max(0, Math.min(100, Number(match[1]) * 10));
        }
        return parseScore(element.innerText || element.textContent || '');
    }

    function listingEntries(doc, pageUrl, problem) {
        const page = new URL(pageUrl, location.origin);
        const scoped = page.pathname.includes(`/problems/${problem.id}/`) ||
            ['problem_id','problem','id'].some(key => page.searchParams.get(key) === String(problem.id));
        const entries = new Map();
        doc.querySelectorAll('a[href]').forEach(anchor => {
            const id = parseSubmissionId(anchor.getAttribute('href'));
            if (!id) return;
            const row = anchor.closest('tr') || anchor.parentElement?.parentElement || anchor;
            if (!scoped) {
                const problemLink = [...row.querySelectorAll('a[href*="/problems/"]')]
                    .some(link => /\/problems\/(\d+)/.exec(link.getAttribute('href') || '')?.[1] === String(problem.id));
                if (!problemLink) return;
            }
            const scoreNode = row.querySelector('#submission_judged,[id*="score"],[class*="score_"]') || row;
            entries.set(id, {
                id,
                href:new URL(anchor.getAttribute('href'), pageUrl).href,
                score:scoreFromElement(scoreNode),
                order:entries.size,
            });
        });
        return [...entries.values()];
    }

    function listingCandidates(doc, problem) {
        const urls = new Set();
        const add = value => {
            try {
                const url = new URL(value, location.origin);
                if (url.origin !== location.origin || parseSubmissionId(url.href)) return;
                const isProblemRoute = url.pathname.includes(`/problems/${problem.id}/`) ||
                    ['problem_id','problem'].some(key => url.searchParams.get(key) === String(problem.id));
                if (/submission/i.test(`${url.pathname} ${url.search}`) && isProblemRoute) {
                    url.hash = '';
                    urls.add(url.href);
                }
            } catch {}
        };
        doc?.querySelectorAll?.('a[href]')?.forEach(anchor => add(anchor.getAttribute('href')));
        const root = location.origin;
        add(`${root}/problems/${problem.id}/submissions`);
        add(`${root}/problems/${problem.id}/solutions`);
        add(`${root}/submissions?problem_id=${encodeURIComponent(problem.id)}`);
        add(`${root}/submissions?problem=${encodeURIComponent(problem.id)}`);
        return [...urls];
    }

    async function fetchDocument(value) {
        const url = new URL(value, location.origin);
        if (url.origin !== location.origin) throw new Error('Submission URL left the NZOI site');
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
        try {
            const response = await fetch(url.href, {
                credentials:'include', cache:'no-store', signal:controller.signal,
                headers:{ 'Accept':'text/html,application/xhtml+xml' },
            });
            const text = await response.text();
            if (!response.ok) throw new Error(`HTTP ${response.status} for ${url.pathname}`);
            const doc = new DOMParser().parseFromString(text, 'text/html');
            if (/\/accounts\/sign_in/i.test(response.url) || doc.querySelector('form[action*="sign_in"]')) {
                throw new Error('NZOI session expired; sign in and reopen the dashboard');
            }
            return { doc, url:response.url || url.href };
        } finally {
            clearTimeout(timer);
        }
    }

    function nextListingPages(doc, pageUrl) {
        const base = new URL(pageUrl, location.origin);
        const pages = [];
        doc.querySelectorAll('a[href]').forEach(anchor => {
            const href = anchor.getAttribute('href') || '';
            if (!anchor.matches('[rel="next"],.pagination a,.pager a') && !/[?&]page=\d+/i.test(href)) return;
            try {
                const url = new URL(href, base);
                if (url.origin === location.origin && url.pathname === base.pathname && /[?&]page=\d+/i.test(url.href)) {
                    url.hash = '';
                    pages.push(url.href);
                }
            } catch {}
        });
        return [...new Set(pages)];
    }

    async function findListing(problem) {
        let problemDoc = null;
        try { problemDoc = (await fetchDocument(problem.href)).doc; } catch (error) {
            LOG(`Could not inspect problem page ${problem.id} for submission links:`, error.message);
        }
        if (problemDoc) {
            const inlineEntries = listingEntries(problemDoc, problem.href, problem);
            if (inlineEntries.length) return { doc:problemDoc, url:problem.href, entries:inlineEntries };
        }
        const candidates = listingCandidates(problemDoc, problem);
        let lastError = null;
        for (const url of candidates) {
            try {
                const result = await fetchDocument(url);
                const entries = listingEntries(result.doc, result.url, problem);
                if (entries.length) return { ...result, entries };
            } catch (error) { lastError = error; }
        }
        throw lastError || new Error(`No submission history was found for problem ${problem.id}`);
    }

    async function allSubmissionEntries(problem, firstListing) {
        const entries = new Map();
        const queue = [firstListing];
        const visited = new Set();
        while (queue.length && visited.size < MAX_LIST_PAGES) {
            const current = queue.shift();
            if (visited.has(current.url)) continue;
            visited.add(current.url);
            listingEntries(current.doc, current.url, problem).forEach(entry => {
                const old = entries.get(entry.id);
                if (!old || (entry.score != null && (old.score == null || entry.score > old.score))) entries.set(entry.id, entry);
            });
            for (const next of nextListingPages(current.doc, current.url)) {
                if (visited.has(next)) continue;
                try { queue.push(await fetchDocument(next)); }
                catch (error) { LOG(`Submission history page unavailable for ${problem.id}:`, error.message); }
            }
        }
        if (queue.length) LOG(`Submission history for ${problem.id} reached the ${MAX_LIST_PAGES}-page safety limit`);
        return [...entries.values()];
    }

    function sourceFromDocument(doc) {
        const candidates = [
            '#main-container > .highlight pre', '#main-container .highlight pre',
            '.submission-source pre', '.submission-source', '#source pre', '#source',
            '.highlight pre', 'pre[class*="language-"]',
        ];
        for (const selector of candidates) {
            const node = doc.querySelector(selector);
            const source = node?.textContent || '';
            if (source.trim()) return source.replace(/\r\n/g, '\n');
        }
        const fallback = [...doc.querySelectorAll('#main-container pre, pre')]
            .filter(node => !node.closest('table.results,.results,.test-output'))
            .sort((a,b) => (b.textContent || '').length - (a.textContent || '').length)[0];
        const source = fallback?.textContent || '';
        return source.trim() ? source.replace(/\r\n/g, '\n') : '';
    }

    function languageFromDocument(doc, source) {
        const marked = [
            ...doc.querySelectorAll('select[name*="language"] option:checked,[data-language],.submission-language,#submission_language'),
        ].map(node => node.value || node.getAttribute('data-language') || node.textContent || '').join(' ');
        const metadataRows = [...doc.querySelectorAll('tr,dl,li,p')]
            .filter(node => /\blanguage\b/i.test(node.textContent || ''))
            .map(node => node.textContent || '').join(' ');
        const hint = `${marked} ${metadataRows}`;
        if (/\bpython\b|\bpy3\b/i.test(hint) || /^\s*(?:from\s+\w+\s+import|import\s+\w+|def\s+\w+\s*\(|print\s*\(|if\s+__name__\s*==)|\binput\s*\(/m.test(source)) return 'python';
        if (/\bc\s*\+\+|\bg\+\+|\bclang\b/i.test(hint) || /#include\s*[<"]|\busing\s+namespace\s+std|\bint\s+main\s*\(/m.test(source)) return 'cpp';
        if (/\bjava\b/i.test(hint) || /\bpublic\s+class\s+\w+|\bSystem\.out\./m.test(source)) return 'java';
        return 'text';
    }

    function scoreFromDocument(doc) {
        const judged = doc.querySelector('#submission_judged,[id*="submission_judged"]');
        const judgedScore = scoreFromElement(judged);
        if (judgedScore != null) return judgedScore;
        const scoreNodes = [...doc.querySelectorAll('[id*="score"],[class*="score_"]')];
        for (const node of scoreNodes) {
            const score = scoreFromElement(node);
            if (score != null) return score;
        }
        return parseScore(doc.body?.innerText || doc.body?.textContent || '');
    }

    async function highestSubmission(problem) {
        const listing = await findListing(problem);
        const entries = await allSubmissionEntries(problem, listing);
        if (!entries.length) throw new Error(`No submission links found for problem ${problem.id}`);
        const scoreComplete = entries.every(entry => entry.score != null);
        const topListedScore = scoreComplete ? Math.max(...entries.map(entry => entry.score)) : null;
        const candidates = [...entries];
        candidates.sort((a,b) => {
            if (scoreComplete && a.score !== b.score) return b.score - a.score;
            return Number(b.id) - Number(a.id);
        });
        let best = null;
        for (const entry of candidates) {
            if (best && scoreComplete && entry.score < (best.score ?? topListedScore)) break;
            const detail = await fetchDocument(entry.href);
            const source = sourceFromDocument(detail.doc);
            if (!source.trim()) {
                LOG(`Submission ${entry.id} has no visible source code; skipping`);
                continue;
            }
            const score = scoreFromDocument(detail.doc) ?? entry.score;
            const language = languageFromDocument(detail.doc, source);
            const candidate = { ...entry, score, source, language, url:detail.url };
            const effectiveScore = score == null ? Number(problem.progress || 0) : score;
            const bestScore = best ? (best.score == null ? Number(problem.progress || 0) : best.score) : -1;
            if (!best || effectiveScore > bestScore || (effectiveScore === bestScore && Number(candidate.id) > Number(best.id))) best = candidate;
        }
        if (!best) throw new Error(`No submission source was readable for problem ${problem.id}`);
        if (best.score == null) best.scoreFallback = true;
        return best;
    }

    async function archiveOne(problem, token) {
        const best = await highestSubmission(problem);
        const extension = ({ cpp:'cpp', python:'py', java:'java' })[best.language];
        if (!extension) throw new Error(`Unsupported submission language for problem ${problem.id}; source was not archived`);
        const filename = `NZOI_${problem.id}__highest-answer.${extension}`;
        const legacyJsonFilename = `NZOI_${problem.id}__highest-answer.json`;
        const storageKey = RECORD_PREFIX + problem.id;
        const previous = await storageGet(storageKey);
        const sameSubmission = previous?.submissionId === String(best.id) && Number(previous.score) === Number(best.score);
        const cleanupPending = previous?.legacyJsonFilename === legacyJsonFilename || previous?.filename === legacyJsonFilename;
        if (sameSubmission && previous?.filename === filename && !cleanupPending) {
            return { ...previous, unchanged:true };
        }
        // Keep the Gist answer directly usable as source. Submission metadata
        // stays in extension storage and no answer text is copied there.
        await bg({ type:'gist:save', token, filename, content:best.source });
        let legacyJsonFilenamePending = '';
        if (previous?.filename === legacyJsonFilename || previous?.legacyJsonFilename === legacyJsonFilename) {
            try {
                // This narrowly scoped background action can only remove the
                // generated JSON for this problem, after its source was saved.
                await bg({ type:'gist:deleteHighestAnswerJson', token, problemId:String(problem.id) });
            } catch (error) {
                legacyJsonFilenamePending = legacyJsonFilename;
                LOG(`Saved ${filename}; generated JSON cleanup will retry later:`, error.message);
            }
        }
        const record = {
            status:'saved', submissionId:String(best.id),
            score:best.score == null ? Number(problem.progress) || 0 : best.score,
            language:best.language, filename, syncedAt:Date.now(),
            ...(legacyJsonFilenamePending ? { legacyJsonFilename:legacyJsonFilenamePending } : {}),
        };
        await storageSet({ [storageKey]:record });
        return record;
    }

    async function start(problems) {
        const run = startTail.catch(() => {}).then(() => startNow(problems));
        startTail = run.catch(() => {});
        return run;
    }

    async function startNow(problems) {
        const eligible = [...new Map(problems
            .filter(problem => Number(problem.progress) > 0)
            .filter(problem => Number(problem.progress) > (startedProblemProgress.get(String(problem.id)) ?? -1))
            .map(problem => [String(problem.id), problem])).values()];
        if (!eligible.length) return;
        eligible.forEach(problem => startedProblemProgress.set(String(problem.id), Number(problem.progress) || 0));
        const token = await storageGet('githubToken');
        if (!token) {
            progress = { total:eligible.length, completed:0, saved:0, failed:0, status:'needs-token' };
            await publishProgress();
            LOG(`Best-submission Gist archive needs a GitHub token (${eligible.length} started problems)`);
            return;
        }
        progress = { total:eligible.length, completed:0, saved:0, failed:0, status:'scanning', startedAt:Date.now() };
        await publishProgress();
        LOG(`Checking highest submissions for ${eligible.length} problem(s) with progress`);
        let cursor = 0;
        const worker = async () => {
            while (cursor < eligible.length) {
                const problem = eligible[cursor++];
                try {
                    const result = await archiveOne(problem, token);
                    progress.saved++;
                } catch (error) {
                    progress.failed++;
                    ERR(`Could not archive highest submission for ${problem.id} (${problem.name}):`, error.message);
                } finally {
                    progress.completed++;
                    progress.lastProblem = `${problem.id} · ${problem.name}`;
                    await publishProgress();
                }
            }
        };
        await Promise.all(Array.from({ length:Math.min(WORKERS, eligible.length) }, worker));
        progress.status = 'complete';
        progress.finishedAt = Date.now();
        await publishProgress();
        LOG(`Best-submission archive complete: ${progress.saved} verified, ${progress.failed} failed`);
    }

    return { start };
})();

function injectDashboardStyles() {
    if (document.getElementById('nzoi-dash-styles')) return;
    const s = document.createElement('style');
    s.id = 'nzoi-dash-styles';
    s.textContent = `
/* ── NZOI Enhanced Dashboard v12 ── */
:root{
  --bgp:#0d1117;--bgs:#161b22;--bgt:#21262d;--bgh:#30363d;
  --tp:#f0f6fc;--ts:#8b949e;--tt:#6e7681;
  --ab:#58a6ff;--ar:#f85149;
  --ar-tint:rgba(248,81,73,.08);
  --bp:#30363d;
  --faint:rgba(255,255,255,.06);
  --sm:0 4px 12px rgba(0,0,0,.25);--sl:0 16px 40px rgba(0,0,0,.4);
  --rsm:6px;--rmd:10px;--rlg:14px;
  --nzoi-green:#2d9d78;--nzoi-green-dk:#1e6b52;
  --data-neutral:#a7b0bc;
  --cf-newbie:#a3a3a3;--cf-pupil:#3fb950;--cf-specialist:#2dd4bf;--cf-expert:#58a6ff;
  --cf-candidate:#d2a8ff;--cf-master:#f0883e;--cf-grandmaster:#ff6b6b;--cf-legendary:#ff3d6e;
}
/* Light theme — toggled via data-theme="light" on <html>, persisted in
   window.__NZOI_SAFE_STORAGE__.local under 'theme'. Every color elsewhere in this sheet
   routes through these tokens, so this block is the only thing that needs to
   change to re-skin the whole dashboard. */
:root[data-theme="light"]{
  --bgp:#ffffff;--bgs:#f6f8fa;--bgt:#eaeef2;--bgh:#d0d7de;
  --tp:#1f2328;--ts:#57606a;--tt:#6e7781;
  --ab:#0969da;--ar:#cf222e;
  --ar-tint:rgba(207,34,46,.08);
  --bp:#d0d7de;
  --faint:rgba(31,35,40,.07);
  --sm:0 1px 3px rgba(31,35,40,.10),0 1px 2px rgba(31,35,40,.06);
  --sl:0 12px 28px rgba(140,149,159,.35);
  --nzoi-green:#1a8f68;--nzoi-green-dk:#136b4d;
  --data-neutral:#626d78;
  --cf-newbie:#808080;--cf-pupil:#008000;--cf-specialist:#008f88;--cf-expert:#0057d9;
  --cf-candidate:#9400a8;--cf-master:#c66a00;--cf-grandmaster:#d12c2c;--cf-legendary:#b00032;
}
*{box-sizing:border-box;margin:0;padding:0}
body,html{
  background:var(--bgp)!important;color:var(--tp)!important;
  font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif!important;
  font-size:14px;line-height:1.5;height:100%;max-height:100dvh;overflow:hidden;
  -webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;
}
/* Match Chrome's 90% page zoom on the dashboard only. Expanding the body's
   layout box keeps the scaled dashboard flush with every viewport edge. */
html.nzoi-dashboard-page body{
  zoom:.9;width:111.111111%;height:111.111111dvh;max-height:111.111111dvh;overflow:hidden!important;
}
html.nzoi-dashboard-page footer,
html.nzoi-dashboard-page #footer,
html.nzoi-dashboard-page .footer,
html.nzoi-dashboard-page .ui.footer,
html.nzoi-dashboard-page [role="contentinfo"]{display:none!important}
/* ── Layout ── */
#main-container{
  position:relative!important;z-index:1!important;
  width:100%!important;height:calc(111.111111dvh - var(--nzoi-dashboard-top, 0px))!important;max-height:calc(111.111111dvh - var(--nzoi-dashboard-top, 0px))!important;
  margin:0!important;padding:0!important;display:flex;background:var(--bgp);overflow:hidden;
}
.dbl{display:flex;width:100%;height:100%;gap:14px;padding:14px;min-height:0}
.dbm{flex:1;display:flex;flex-direction:column;background:var(--bgs);border-radius:var(--rmd);border:1px solid var(--bp);box-shadow:var(--sm);overflow:hidden;min-width:0}

/* ── Header ── */
.dbh{background:var(--bgs);border-bottom:1px solid var(--bp);padding:14px 18px 12px;flex-shrink:0}
.dbht{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;gap:12px}
.dbtitle{font-size:20px;font-weight:700;color:var(--tp);letter-spacing:-.03em;display:flex;align-items:center;gap:10px}
.dbtitle::before{
  content:'';display:inline-block;width:8px;height:8px;border-radius:50%;
  background:var(--nzoi-green);box-shadow:0 0 8px var(--nzoi-green);flex-shrink:0;
}

/* ── Status bar ── */
.cst{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.cprog{display:inline-flex;align-items:center;gap:5px;max-width:230px}
.cprog progress{width:68px;height:6px;accent-color:var(--data-neutral);color:var(--data-neutral)}
#dashboard-classifier-progress progress{accent-color:var(--data-neutral);color:var(--data-neutral)}
.csc{
  font-size:11px;color:var(--tt);font-variant-numeric:tabular-nums;
  background:var(--bgp);border:1px solid var(--bp);padding:3px 10px;
  border-radius:20px;letter-spacing:.02em;box-shadow:inset 0 1px 0 rgba(255,255,255,.035);
}
#archive-status{color:var(--data-neutral);border-color:color-mix(in srgb,var(--data-neutral) 35%,var(--bp));background:color-mix(in srgb,var(--data-neutral) 8%,var(--bgp))}
#dashboard-activity{display:inline-flex;align-items:center;gap:6px;max-width:230px;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--data-neutral);border-color:color-mix(in srgb,var(--data-neutral) 35%,var(--bp));background:color-mix(in srgb,var(--data-neutral) 8%,var(--bgp))}
#dashboard-activity-label{display:block;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#dashboard-activity::before{content:'';width:6px;height:6px;flex:0 0 6px;border-radius:50%;background:currentColor;opacity:.8}
#dashboard-activity[data-state="success"]{color:var(--nzoi-green);border-color:color-mix(in srgb,var(--nzoi-green) 35%,var(--bp));background:color-mix(in srgb,var(--nzoi-green) 8%,var(--bgp))}
#dashboard-activity[data-state="error"]{color:var(--ar);border-color:color-mix(in srgb,var(--ar) 40%,var(--bp));background:color-mix(in srgb,var(--ar) 8%,var(--bgp))}
.cprog[tabindex="0"]:focus-visible,#archive-status:focus-visible{outline:2px solid var(--data-neutral);outline-offset:2px}
.csa{display:flex;align-items:center;gap:4px}
.csa-div{width:1px;height:18px;background:var(--bp);margin:0 2px;flex-shrink:0}
.abt{
  display:flex;align-items:center;justify-content:center;
  width:28px;height:28px;background:transparent;border:1px solid var(--bp);
  border-radius:var(--rsm);color:var(--tt);cursor:pointer;transition:all .2s;
}
.abt:hover{background:var(--bgh);color:var(--ts);border-color:var(--ts)}
.abt.danger:hover{border-color:var(--ar);color:var(--ar);background:var(--ar-tint)}
.abt.flt-btn--active{border-color:var(--nzoi-green);color:var(--nzoi-green);background:rgba(45,157,120,.1)}
.abt svg{width:13px;height:13px}

/* ── Hidden-tags placeholder chip ── */
.tb2.tag-hidden{cursor:pointer;display:inline-flex;align-items:center;gap:4px;font-style:italic;transition:all .15s}
.tb2.tag-hidden:hover{background:var(--bgh);color:var(--tp)}
.tb2.tag-hidden svg{width:11px;height:11px;flex-shrink:0}

/* ── Filter bar ── */
.flt{display:flex;align-items:center;gap:6px;flex-wrap:wrap;position:relative}
.flt-btn{
  display:flex;align-items:center;gap:4px;padding:6px 11px;
  background:var(--bgp);border:1px solid var(--bp);border-radius:20px;
  color:var(--ts);font-size:12px;font-weight:500;cursor:pointer;
  transition:all .18s;user-select:none;white-space:nowrap;font-family:inherit;line-height:1.2;
}
.flt-btn:hover{border-color:var(--ts);color:var(--tp)}
.flt-btn:focus-visible,.abt:focus-visible,.rcb:focus-visible,.ebt:focus-visible{outline:2px solid var(--cf-expert);outline-offset:2px}
.flt-btn--active{border-color:var(--ab);color:var(--ab);background:rgba(88,166,255,.08)}
.flt-ct{color:var(--ab);font-weight:600;font-size:11px}
.flt-clear{
  padding:5px 10px;border-radius:20px;border:1px solid rgba(248,81,73,.3);
  background:transparent;color:var(--ar);font-size:11px;font-weight:500;
  cursor:pointer;transition:all .18s;
}
.flt-clear:hover{background:var(--ar-tint);border-color:var(--ar)}
.flt-results{
  margin-left:auto;padding:5px 10px;border:1px solid var(--bp);border-radius:20px;
  color:var(--tt);background:var(--bgp);font-size:11px;font-weight:600;
  font-variant-numeric:tabular-nums;white-space:nowrap;
}

/* ── Multi-select dropdown panel ── */
.flt-panel{
  position:fixed;z-index:9999;
  background:var(--bgt);border:1px solid var(--bp);border-radius:var(--rmd);
  box-shadow:var(--sl);padding:6px;min-width:180px;max-height:280px;
  overflow-y:auto;scrollbar-width:thin;scrollbar-color:var(--bp) transparent;
  display:none;animation:fi .15s ease;
}
.flt-panel.open{display:block}
.flt-panel::-webkit-scrollbar{width:5px}
.flt-panel::-webkit-scrollbar-thumb{background:var(--bp);border-radius:3px}
.flt-opt{
  display:flex;align-items:center;gap:8px;padding:7px 10px;
  border-radius:var(--rsm);cursor:pointer;font-size:13px;
  color:var(--ts);transition:background .12s;
}
.flt-opt:hover{background:var(--bgh);color:var(--tp)}
.flt-opt input[type=checkbox],.to input[type=checkbox]{
  appearance:none;width:14px;height:14px;border:1px solid var(--bp);
  border-radius:4px;background:var(--bgt);cursor:pointer;flex-shrink:0;
  display:inline-grid;place-content:center;transition:background .15s,border-color .15s;
}
.flt-opt input[type=checkbox]:checked,.to input[type=checkbox]:checked{background:var(--nzoi-green);border-color:var(--nzoi-green)}
.flt-opt input[type=checkbox]:checked::after,.to input[type=checkbox]:checked::after{
  content:'';width:4px;height:8px;border:solid #fff;border-width:0 2px 2px 0;transform:rotate(45deg);margin-top:-2px;
}

/* ── Sort badges on column headers ── */
.sth{cursor:pointer;user-select:none;white-space:nowrap;position:relative}
.sth:hover{color:var(--ts)}.sth.act{color:var(--tp)}
.sort-badges{display:inline-flex;align-items:center;gap:2px;margin-left:4px;vertical-align:middle}
.sort-badge-pri{font-size:10px;color:var(--ab)}
.sort-badge-sec{font-size:9px;color:var(--tt);opacity:.7}
.sort-badge-sec sup{font-size:7px}

/* ── Search + Filters bar ── */
.dbct{display:flex;align-items:center;gap:10px;flex-wrap:wrap;flex-shrink:0}
.sw{flex:1;min-width:180px;position:relative}
.si{position:absolute;left:10px;top:50%;transform:translateY(-50%);width:15px;height:15px;color:var(--tt);pointer-events:none}
#db-search{
  width:100%;padding:8px 12px 8px 34px;
  background:var(--bgp);border:1px solid var(--bp);
  border-radius:var(--rsm);color:var(--tp);font-size:13px;
  transition:border-color .2s,box-shadow .2s;
}
#db-search:focus{outline:none;border-color:var(--ab);box-shadow:0 0 0 3px rgba(88,166,255,.1)}
#db-search::placeholder{color:var(--tt)}

.tbs{flex:1;display:flex;flex-direction:column;overflow:hidden}
.tbw{flex:1;overflow-y:auto;min-height:0;padding:0 18px 12px}
.tbw::-webkit-scrollbar{width:7px}
.tbw::-webkit-scrollbar-thumb{background:var(--bp);border-radius:4px}
.tbw::-webkit-scrollbar-track{background:transparent}

/* ── Table ── */
.pt{width:100%;border-collapse:separate;border-spacing:0;table-layout:fixed}
.pt th{width:18%}.pt th:first-child{width:24%}.pt th:nth-child(5){width:16%}.pt th:last-child{width:11%}
.pt thead{position:sticky;top:0;z-index:10;background:var(--bgs)}
.pt thead::after{content:'';display:block;height:1px;background:var(--bp);position:absolute;bottom:0;left:0;right:0}
.pt th{
  background:transparent;color:var(--tt);padding:10px 14px;text-align:left;
  font-weight:600;font-size:10px;text-transform:uppercase;letter-spacing:.6px;
  border:none;border-bottom:1px solid var(--bp);white-space:nowrap;
}

/* ── Table rows ── */
.pr{transition:background .12s;border-bottom:1px solid color-mix(in srgb,var(--bp) 72%,transparent);height:72px}
.pr:hover{background:color-mix(in srgb,var(--cf-expert) 9%,var(--bgs))}
.pt .pr:hover td{background:transparent!important}
.pr.unclassified-row{opacity:.7}
.pr td{padding:10px 14px;border:none;color:var(--ts);vertical-align:middle;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.pn,.pl{color:var(--tp)!important;font-weight:500;text-decoration:none!important;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.pl{transition:color .15s}.pl:hover{color:var(--ab)!important}

/* ── Progress bar ── */
.pgw{display:flex;align-items:center;gap:8px}
.pgb{flex:1;height:6px;background:color-mix(in srgb,var(--ts) 18%,var(--bgp));border-radius:999px;overflow:hidden}
.pgf{height:100%;background:var(--progress-color,var(--data-neutral));border-radius:999px;transition:width .4s ease,filter .2s;box-shadow:0 0 8px color-mix(in srgb,var(--progress-color,var(--data-neutral)) 34%,transparent)}
.pgt{font-size:11px;color:var(--tp);min-width:32px;text-align:right;font-variant-numeric:tabular-nums;font-weight:600}

/* ── Group badge + Tags ── */
.gb{
  display:inline-block;padding:2px 9px;border-radius:20px;font-size:11px;font-weight:500;
  background:rgba(88,166,255,.08);color:var(--ab);border:1px solid rgba(88,166,255,.2);
  white-space:nowrap;flex-shrink:0;max-width:130px;overflow:hidden;text-overflow:ellipsis;
}
.tb2{
  display:inline-block;padding:2px 9px;border-radius:20px;font-size:11px;font-weight:500;
  background:var(--bgh);color:var(--ts);border:1px solid var(--bp);
  white-space:nowrap;flex-shrink:0;
}
.tb2:not(.unclassified-tag):not(.tag-hidden){
  color:var(--data-neutral);
  background:color-mix(in srgb,var(--data-neutral) 9%,var(--bgp));
  border-color:color-mix(in srgb,var(--data-neutral) 28%,var(--bp));
}
.rating-value{
  display:inline-flex;align-items:center;justify-content:center;min-width:34px;padding:2px 7px;
  border:1px solid color-mix(in srgb,currentColor 42%,transparent);
  border-radius:999px;background:color-mix(in srgb,currentColor 13%,var(--bgp));
}
.tb2.unclassified-tag{
  background:color-mix(in srgb,var(--cf-master) 10%,var(--bgp));color:var(--cf-master);
  border-color:color-mix(in srgb,var(--cf-master) 38%,var(--bp));font-style:italic;
}
.tw,.gw{display:flex;flex-wrap:nowrap;align-items:center;gap:4px;overflow:hidden;min-width:0}
.tag-cell{display:flex;flex-direction:column;gap:3px;min-width:0;overflow:hidden}
.rsum{font-size:10px;line-height:1.2;color:var(--tt);opacity:.85;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%}
.tag-scroll{
  flex:1;min-width:0;display:flex;align-items:center;gap:4px;overflow-x:auto;overflow-y:hidden;
  scroll-behavior:smooth;scrollbar-width:thin;scrollbar-color:var(--bp) transparent;
  -webkit-mask-image:linear-gradient(90deg,#000 0,#000 calc(100% - 18px),transparent);
  mask-image:linear-gradient(90deg,#000 0,#000 calc(100% - 18px),transparent);
}
.tag-scroll::-webkit-scrollbar{height:4px}
.tag-scroll::-webkit-scrollbar-track{background:transparent}
.tag-scroll::-webkit-scrollbar-thumb{background:var(--bp);border-radius:999px}

/* Virtualized list spacer rows — keep total scroll height correct while only
   rows near the viewport are actually in the DOM (see ui.renderVirtual). */
.vsp{border:none!important}
.vsp td{border:none!important}

/* ── Edit button ── */
.ebt{
  display:inline-flex;align-items:center;justify-content:center;
  width:20px;height:20px;background:transparent;border:none;
  border-radius:4px;color:transparent;cursor:pointer;transition:all .15s;
  padding:0;flex-shrink:0;margin-left:2px;
}
.tw:hover .ebt,.gw:hover .ebt,.pr:hover .ebt,.dfw:hover .ebt{color:var(--tt)}
.ebt:hover{background:var(--bgh);color:var(--ab)!important}
.ebt svg{width:11px;height:11px}

/* ── Difficulty stars ── */
.dfw{display:flex;align-items:center;gap:5px;font-weight:600}
.dfs{font-size:12px;letter-spacing:-1px;text-shadow:0 0 7px currentColor}.dfr{font-size:11px;color:inherit;font-variant-numeric:tabular-nums;font-weight:700}
.clby{font-size:10px;color:var(--tt);margin-top:1px;opacity:.75;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.class-meta{display:flex;align-items:center;gap:5px;font-size:10px;color:var(--tt);margin-top:1px;min-width:0;white-space:nowrap}
.class-meta span{overflow:hidden;text-overflow:ellipsis}
.esc{color:var(--ab)}
.esc.no{color:var(--tt)}

/* ── Actions ── */
.acc{text-align:center}.acb{display:flex;align-items:center;justify-content:center;gap:6px}
.rcb{
  display:flex;align-items:center;justify-content:center;
  width:28px;height:28px;background:transparent;border:1px solid var(--bp);
  border-radius:var(--rsm);color:var(--tt);cursor:pointer;transition:all .2s;padding:0;
}
.rcb:hover{background:var(--bgt);border-color:var(--nzoi-green);color:var(--nzoi-green)}
.rcb svg{width:13px;height:13px}

/* ── Spinner ── */
.rspin{display:flex;align-items:center;justify-content:center;gap:6px;color:var(--ab);font-size:11px}
.sp{width:15px;height:15px;animation:spin 1s linear infinite}
.sp circle{stroke-dasharray:50;stroke-dashoffset:25;animation:sd 1.5s ease-in-out infinite}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes sd{
  0%{stroke-dasharray:1,150;stroke-dashoffset:0}
  50%{stroke-dasharray:90,150;stroke-dashoffset:-35}
  100%{stroke-dasharray:90,150;stroke-dashoffset:-124}
}
.empty-r td{text-align:center;color:var(--tt);padding:48px;font-size:13px}

/* ── Sidebar ── */
.dash-sidebar{width:252px;display:flex;flex-direction:column;gap:12px;height:100%;flex-shrink:0}
.sc{
  flex:1;min-height:0;display:flex;flex-direction:column;
  background:var(--bgs);border-radius:var(--rmd);
  border:1px solid var(--bp);box-shadow:var(--sm);overflow:hidden;
}
.ch{
  display:flex;align-items:center;gap:8px;padding:11px 14px;
  border-bottom:1px solid var(--bp);background:var(--bgs);flex-shrink:0;
}
.ch h2{margin:0;font-size:13px;font-weight:600;color:var(--tp);letter-spacing:.01em}
.ci{width:14px;height:14px;color:var(--nzoi-green);flex-shrink:0}
.cb{
  flex:1;min-height:0;overflow-y:auto;padding:6px;
  display:flex;flex-direction:column;gap:2px;
}
.cb::-webkit-scrollbar{width:6px}
.cb::-webkit-scrollbar-thumb{background:var(--bp);border-radius:3px}
.si3{
  display:flex;align-items:center;justify-content:space-between;
  padding:7px 10px;border-radius:var(--rsm);color:var(--ts)!important;
  text-decoration:none!important;transition:all .18s;
  border:1px solid transparent;font-size:13px;
}
.si3:hover{background:var(--bgh);border-color:var(--bp);color:var(--tp)!important}
.it{flex:1;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ia{width:13px;height:13px;color:var(--tt);transition:transform .18s;flex-shrink:0}
.si3:hover .ia{transform:translateX(2px);color:var(--ab)}
.ci2{flex-direction:column;align-items:flex-start}
.cit{font-weight:600;margin-bottom:3px;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;width:100%;color:var(--tp)}
.citi{font-size:11px;color:var(--tt)}
.emp{text-align:center;color:var(--tt);padding:18px;font-size:12px;line-height:1.6}

/* ── Modals ── */
.mo{
  position:fixed;inset:0;background:rgba(0,0,0,.8);
  display:flex;align-items:center;justify-content:center;
  z-index:10000;animation:fi .18s ease;
}
@keyframes fi{from{opacity:0}to{opacity:1}}
.mb{
  background:var(--bgs);border:1px solid var(--bp);border-radius:var(--rlg);
  box-shadow:var(--sl);max-width:580px;width:90%;max-height:82vh;
  display:flex;flex-direction:column;animation:su .25s ease;
}
.mb-sm{max-width:420px}
@keyframes su{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}
.mh{
  display:flex;align-items:center;justify-content:space-between;
  padding:14px 18px;border-bottom:1px solid var(--bp);
}
.mh h3{margin:0;font-size:16px;font-weight:600;color:var(--tp)}
.mc{
  background:transparent;border:none;color:var(--tt);font-size:20px;
  cursor:pointer;padding:0;width:26px;height:26px;
  display:flex;align-items:center;justify-content:center;border-radius:4px;
  transition:all .15s;line-height:1;
}
.mc:hover{background:var(--bgh);color:var(--tp)}
.mbd{padding:18px;overflow-y:auto;flex:1}
.mft{display:flex;justify-content:flex-end;gap:8px;padding:14px 18px;border-top:1px solid var(--bp)}
.mbt{padding:8px 16px;border-radius:var(--rsm);font-size:13px;font-weight:500;cursor:pointer;border:1px solid transparent;transition:all .15s}
.mbs{background:var(--bgp);color:var(--tp);border-color:var(--bp)}.mbs:hover{background:var(--bgh)}
.mbp{background:var(--nzoi-green);color:#fff}.mbp:hover{background:var(--nzoi-green-dk)}

/* ── Tag grid ── */
.tg{display:grid;grid-template-columns:repeat(auto-fill,minmax(165px,1fr));gap:8px}
.to{
  display:flex;align-items:center;gap:8px;padding:9px 12px;
  background:var(--bgp);border:1px solid var(--bp);border-radius:var(--rsm);
  cursor:pointer;transition:all .18s;user-select:none;
}
.to:hover{background:var(--bgh);border-color:var(--ts)}
.to.sel{background:rgba(45,157,120,.1);border-color:var(--nzoi-green)}
.to input{margin:0;cursor:pointer;accent-color:var(--nzoi-green)}
.to span{color:var(--tp);font-size:13px}

/* ── Rating editor ── */
.re{display:flex;flex-direction:column;gap:12px}
.re label{color:var(--tp);font-weight:500;font-size:14px}
.re input[type=number]{
  padding:10px 12px;background:var(--bgp);border:1px solid var(--bp);
  border-radius:var(--rsm);color:var(--tp);font-size:16px;font-weight:600;width:100%;
  transition:border-color .2s;
}
.re input[type=number]:focus{outline:none;border-color:var(--nzoi-green);box-shadow:0 0 0 3px rgba(45,157,120,.15)}
.rg{display:flex;flex-direction:column;gap:6px;padding:12px;background:var(--bgp);border-radius:var(--rsm);border:1px solid var(--bp)}
.gi{display:flex;gap:8px;font-size:13px}
.gr{color:var(--nzoi-green);font-weight:600;min-width:90px}
.gd{color:var(--ts)}

/* ── Hide original title box ── */
#main-page-title-box{display:none!important}
@media(max-width:1100px){
  .dbl{gap:10px;padding:10px}.dash-sidebar{width:220px}.tbw{padding-left:10px;padding-right:10px}
  .pt th,.pr td{padding-left:9px;padding-right:9px}
}
@media(max-width:800px){
  .dbl{gap:0;padding:6px}.dash-sidebar{display:none}.dbht{align-items:flex-start;flex-wrap:wrap}
  .cst{gap:5px}.pt th:first-child{width:30%}.pt th:nth-child(3),.pr td:nth-child(3){display:none}
  .pt th:nth-child(4){width:26%}.pt th:nth-child(5){width:20%}.pt th:last-child{width:12%}
}
@media(prefers-reduced-motion:reduce){
  *,*::before,*::after{animation-duration:.01ms!important;transition-duration:.01ms!important;scroll-behavior:auto!important}
}`;
    document.head.appendChild(s);
}


// ─── UI ───────────────────────────────────────────────────────────────────────

const ui = {
    init(tot, dashboardGroups=null) {
        injectDashboardStyles();
        const mg=dashboardGroups || scrapers.getMyGroups(), con=scrapers.getUpcomingContests();
        $('#main-container').html(this.getHTML(mg,con,tot));
        questionArchive.updateStatus();
        this.attachHandlers(); this.populateFilters();
    },

    // Icon shows the mode a click would switch TO (sun while dark = "go light",
    // moon while light = "go dark") — the convention used by GitHub/VSCode.
    themeIcon() {
        return state.theme === 'dark'
            ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>`
            : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>`;
    },
    eyeIcon() {
        return state.hideTags
            ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`
            : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`;
    },

    getHTML(grps, cons, tot) {
        const gh = grps.length ? grps.map(g=>`<a href="${g.href}" class="si3"><span class="it">${esc(g.name)}</span><svg class="ia" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg></a>`).join('') : '<div class="emp">No groups found</div>';
        const ch = cons.length ? cons.map(c=>`<a href="${c.href||'#'}" class="si3 ci2"><div class="cit">${esc(c.title)}</div><div class="citi">${c.startTime} — ${c.endTime}</div></a>`).join('') : '<div class="emp">No upcoming contests</div>';
        return `<div class="dbl">
<div class="dbm">
<header class="dbh">
<div class="dbht">
<div style="display:flex;align-items:center;gap:12px">
<h1 class="dbtitle">Problems</h1>
<div class="cst"><span class="csc"><span id="cached-count">0</span>/<span id="total-count">${tot}</span> classified</span><span class="csc" id="archive-status" title="questions.txt Gist archive progress" tabindex="0" role="status" aria-label="Question statement Gist archive status">0 archived</span><span class="csc cactivity" id="dashboard-activity" role="status" aria-live="polite" aria-atomic="true"><span id="dashboard-activity-label">Loading dashboard</span></span><span class="csc cprog" id="dashboard-classifier-progress" tabindex="0" role="group" aria-label="Background classifier progress" hidden><span id="dashboard-classifier-label">Queued</span><progress id="dashboard-classifier-bar" max="1" value="0"></progress><span id="dashboard-classifier-count">0/0</span></span>
<div class="csa">
<button id="theme-toggle" class="abt" title="Switch to ${state.theme === 'dark' ? 'light' : 'dark'} theme">${this.themeIcon()}</button>
<button id="hide-tags-toggle" class="abt${state.hideTags ? ' flt-btn--active' : ''}" title="${state.hideTags ? 'Show tags' : 'Hide tags'}">${this.eyeIcon()}</button>
<span class="csa-div"></span>
<button id="refresh-cache" class="abt" title="Re-classify all"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 0 1 3.51 15"/></svg></button>
<button id="clear-cache" class="abt danger" title="Clear cache"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></button>
</div></div></div></div>
<div class="dbct">
<div class="sw"><svg class="si" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg><input id="db-search" placeholder="Search problems, tags, ratings…" autocomplete="off"></div>
<div class="flt" id="flt-bar">
<button class="flt-btn" id="flt-tag-btn" type="button" aria-haspopup="true" aria-controls="flt-panel-tags" aria-expanded="false">Tags<span class="flt-ct" id="flt-tag-ct"></span></button>
<button class="flt-btn" id="flt-diff-btn" type="button" aria-haspopup="true" aria-controls="flt-panel-diffs" aria-expanded="false">Difficulty<span class="flt-ct" id="flt-diff-ct"></span></button>
<button class="flt-btn" id="flt-grp-btn" type="button" aria-haspopup="true" aria-controls="flt-panel-groups" aria-expanded="false">Group<span class="flt-ct" id="flt-grp-ct"></span></button>
<button class="flt-clear" id="flt-clear" style="display:none">✕ Clear</button>
<span class="flt-results" id="flt-results" aria-live="polite">${tot.toLocaleString()} results</span>
</div>
</div>
<!-- Multi-select dropdown panels (portal-positioned to #main-container) -->
<div class="flt-panel" id="flt-panel-tags" data-dim="tags" role="group" aria-label="Filter by tags"></div>
<div class="flt-panel" id="flt-panel-diffs" data-dim="diffs" role="group" aria-label="Filter by Codeforces difficulty">
  <label class="flt-opt"><input type="checkbox" value="1"> Newbie (&lt;1200)</label>
  <label class="flt-opt"><input type="checkbox" value="2"> Pupil (1200–1390)</label>
  <label class="flt-opt"><input type="checkbox" value="3"> Specialist (1400–1590)</label>
  <label class="flt-opt"><input type="checkbox" value="4"> Expert (1600–1890)</label>
  <label class="flt-opt"><input type="checkbox" value="5"> Candidate Master+ (1900–3000)</label>
</div>
<div class="flt-panel" id="flt-panel-groups" data-dim="groups" role="group" aria-label="Filter by group"></div>
</header>
<div class="tbs"><div class="tbw">
<table class="pt"><thead><tr>
<th id="th-name" class="sth" data-col="name"><span>Problem</span><span class="sort-badges" data-col="name"></span></th>
<th id="th-progress" class="sth" data-col="progress"><span>Progress</span><span class="sort-badges" data-col="progress"></span></th>
<th id="th-group" class="sth" data-col="group"><span>Group</span><span class="sort-badges" data-col="group"></span></th>
<th id="th-tags" class="sth" data-col="tags"><span>Tags</span><span class="sort-badges" data-col="tags"></span></th>
<th id="th-rating" class="sth" data-col="rating"><span>Difficulty</span><span class="sort-badges" data-col="rating"></span></th>
<th class="acc"><span>Actions</span></th>
</tr></thead><tbody id="prob-tbody"></tbody></table>
</div></div></div>
<aside class="dash-sidebar">
<div class="sc"><div class="ch"><svg class="ci" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg><h2>My Groups</h2></div><div class="cb">${gh}</div></div>
<div class="sc"><div class="ch"><svg class="ci" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/></svg><h2>Upcoming Contests</h2></div><div class="cb">${ch}</div></div>
</aside></div>`;
    },

    attachHandlers() {
        const wrap  = document.querySelector('.tbw');
        const tbody = document.getElementById('prob-tbody');

        $('#refresh-cache').on('click', () => cache.refreshAll());
        $('#clear-cache').on('click',   () => cache.clearAll());

        // ── Theme toggle ──────────────────────────────────────────────────────
        $('#theme-toggle').on('click', () => {
            state.theme = state.theme === 'dark' ? 'light' : 'dark';
            document.documentElement.setAttribute('data-theme', state.theme);
            window.__NZOI_SAFE_STORAGE__.local.set({ theme: state.theme });
            const btn = document.getElementById('theme-toggle');
            if (btn) { btn.innerHTML = this.themeIcon(); btn.title = `Switch to ${state.theme === 'dark' ? 'light' : 'dark'} theme`; }
        });

        // ── Hide tags toggle ──────────────────────────────────────────────────
        // Some competitive programmers consider visible tags a spoiler — they
        // give away the intended approach before the problem's been attempted.
        // This swaps every tag cell for a neutral "Hidden" placeholder; the
        // underlying data (and tag-based filtering) is unaffected.
        $('#hide-tags-toggle').on('click', () => {
            state.hideTags = !state.hideTags;
            if (state.hideTags) state.revealedTagRows.clear();
            window.__NZOI_SAFE_STORAGE__.local.set({ dashboardHideTags: state.hideTags });
            const btn = document.getElementById('hide-tags-toggle');
            if (btn) {
                btn.innerHTML = this.eyeIcon();
                btn.title = state.hideTags ? 'Show tags' : 'Hide tags';
                btn.classList.toggle('flt-btn--active', state.hideTags);
            }
            this.renderVirtual();
        });

        const resetScroll = () => { if (wrap) wrap.scrollTop = 0; };

        // ── Search ────────────────────────────────────────────────────────────
        const dbu = debounce(() => {
            state.filters.search = ($('#db-search').val() || '').toLowerCase().trim();
            resetScroll(); this.updateTable();
        }, 280);
        $('#db-search').on('input', dbu);

        // ── Multi-select filter panels ─────────────────────────────────────────
        // Each button toggles a floating panel anchored below it. Checkboxes
        // inside each panel set state.filters.<dim> (a Set). OR within each
        // dimension, AND across dimensions — standard faceted-filter behaviour
        // used by GitHub/Linear/Notion search/filter bars.

        const closePanels = () => {
            document.querySelectorAll('.flt-panel').forEach(p => p.classList.remove('open'));
            document.querySelectorAll('.flt-btn[aria-expanded="true"]').forEach(button => button.setAttribute('aria-expanded','false'));
        };

        const positionPanel = (panel, btn) => {
            const r = btn.getBoundingClientRect();
            const container = document.getElementById('main-container');
            const cr = container.getBoundingClientRect();
            panel.style.left = (r.left - cr.left) + 'px';
            panel.style.top  = (r.bottom - cr.top + 4) + 'px';
            panel.style.minWidth = Math.max(r.width, 200) + 'px';
        };

        [
            { btn: '#flt-tag-btn',  panel: '#flt-panel-tags',   dim: 'tags' },
            { btn: '#flt-diff-btn', panel: '#flt-panel-diffs',  dim: 'diffs' },
            { btn: '#flt-grp-btn',  panel: '#flt-panel-groups', dim: 'groups' },
        ].forEach(({ btn, panel, dim }) => {
            $(btn).on('click', (e) => {
                e.stopPropagation();
                const p = document.querySelector(panel);
                const b = document.querySelector(btn);
                const wasOpen = p.classList.contains('open');
                closePanels();
                if (!wasOpen) { positionPanel(p, b); p.classList.add('open'); b.setAttribute('aria-expanded','true'); }
            });

            // Checkbox changes update the filter Set and re-render immediately
            $(panel).on('change', 'input[type=checkbox]', () => {
                const checked = new Set([...document.querySelectorAll(panel + ' input:checked')].map(i => i.value));
                state.filters[dim] = checked;
                this._updateFilterBadge(dim);
                resetScroll(); this.updateTable();
            });
        });

        // Clear-all button
        $('#flt-clear').on('click', () => {
            ['tags','groups','diffs'].forEach(d => {
                state.filters[d] = new Set();
                document.querySelectorAll(`#flt-panel-${d} input`).forEach(i => i.checked = false);
            });
            this._updateFilterBadge('tags');
            this._updateFilterBadge('diffs');
            this._updateFilterBadge('groups');
            resetScroll(); this.updateTable();
        });

        // Close on outside click
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.flt-btn, .flt-panel')) closePanels();
        });
        document.addEventListener('keydown', e => { if (e.key === 'Escape') closePanels(); });

        // Column header sort
        ['name','progress','group','tags','rating'].forEach(col => {
            $(`#th-${col}`).on('click', () => {
                const wasPrimary = state.sorts[0]?.column === col;
                state.sorts = [{ column: col, ascending: wasPrimary ? !state.sorts[0].ascending : col !== 'rating' }];
                this._updateSortIndicators();
                resetScroll(); this.updateTable();
            });
        });

        // ── Delegated click handler on tbody ──────────────────────────────────
        if (tbody) tbody.addEventListener('click', async (e) => {
            const rcb = e.target.closest('.rcb');
            if (rcb) { e.stopPropagation(); await classifier.reclassify(rcb.dataset.pid); return; }
            const hiddenTag = e.target.closest('.tag-hidden');
            if (hiddenTag) { e.stopPropagation(); state.revealedTagRows.add(hiddenTag.dataset.pid); this.renderVirtual(); return; }
            const tagTrigger = e.target.closest('.et');
            if (tagTrigger) { e.stopPropagation(); this.showTagEditor(tagTrigger.dataset.pid); return; }
            const er = e.target.closest('.er');
            if (er) { e.stopPropagation(); this.showRatingEditor(er.dataset.pid); return; }
        });

        if (tbody) tbody.addEventListener('wheel', (e) => {
            const scroller = e.target.closest('.tag-scroll');
            if (!scroller || scroller.scrollWidth <= scroller.clientWidth || Math.abs(e.deltaY) <= Math.abs(e.deltaX)) return;
            scroller.scrollLeft += e.deltaY;
            e.preventDefault();
        }, { passive: false });

        $(document).on('click', e => {
        });

        if (wrap) {
            let raf = null;
            wrap.addEventListener('scroll', () => {
                if (raf) return;
                raf = requestAnimationFrame(() => { raf = null; this.renderVirtual(); });
            }, { passive: true });
            if (window.ResizeObserver) new ResizeObserver(() => this.renderVirtual()).observe(wrap);
        }

        // Set initial sort indicators
        this._updateSortIndicators();
    },

    // Update sort indicator badges on column headers
    _updateSortIndicators() {
        document.querySelectorAll('.sth').forEach(th => {
            const col = th.dataset.col;
            const badge = th.querySelector('.sort-badges');
            if (!badge) return;
            th.classList.remove('act', 'asc', 'desc');
            badge.innerHTML = '';
        });
        state.sorts.forEach((s, i) => {
            const th = document.querySelector(`[data-col="${s.column}"]`);
            if (!th) return;
            if (i === 0) th.classList.add('act', s.ascending ? 'asc' : 'desc');
            const badge = th.querySelector('.sort-badges');
            if (!badge) return;
            const arrow = s.ascending ? '▲' : '▼';
            badge.insertAdjacentHTML('beforeend',
                `<span class="sort-badge sort-badge-${i === 0 ? 'pri' : 'sec'}">${arrow}${i > 0 ? '<sup>2</sup>' : ''}</span>`
            );
        });
    },

    // Update the active-count badge on a filter button
    _updateFilterBadge(dim) {
        const ctMap = { tags: 'flt-tag-ct', diffs: 'flt-diff-ct', groups: 'flt-grp-ct' };
        const btnMap = { tags: 'flt-tag-btn', diffs: 'flt-diff-btn', groups: 'flt-grp-btn' };
        const size = state.filters[dim]?.size || 0;
        const ct = document.getElementById(ctMap[dim]);
        const btn = document.getElementById(btnMap[dim]);
        if (ct) { ct.textContent = size > 0 ? ` (${size})` : ''; ct.style.display = size > 0 ? '' : 'none'; }
        if (btn) btn.classList.toggle('flt-btn--active', size > 0);
        // Show/hide the global clear button — scoped to the three facet filters
        // it actually clears (search has its own box and isn't part of this control).
        const anyActive = ['tags','diffs','groups'].some(d => state.filters[d]?.size > 0);
        const clr = document.getElementById('flt-clear');
        if (clr) clr.style.display = anyActive ? '' : 'none';
    },

    populateFilters() {
        // Tags panel — add entries for newly-discovered tags only (idempotent)
        const tagPanel = document.getElementById('flt-panel-tags');
        if (tagPanel) {
            const existing = new Set([...tagPanel.querySelectorAll('input')].map(i => i.value));
            Array.from(state.allTags).sort().forEach(t => {
                if (existing.has(t)) return;
                const label = document.createElement('label');
                label.className = 'flt-opt';
                label.innerHTML = `<input type="checkbox" value="${esc(t)}"> ${esc(t.charAt(0).toUpperCase() + t.slice(1))}`;
                if (state.filters.tags.has(t)) label.querySelector('input').checked = true;
                tagPanel.appendChild(label);
            });
        }
        // Groups panel — checkbox VALUE is lowercased (matches the comparison in
        // updateTable below), display TEXT keeps the original casing. Bug fix:
        // previously the value was exact-case while updateTable compared against
        // a lowercased p.group, so the group filter never actually matched anything.
        const grpPanel = document.getElementById('flt-panel-groups');
        if (grpPanel) {
            const existing = new Set([...grpPanel.querySelectorAll('input')].map(i => i.value));
            Array.from(state.allGroups).sort((a,b) => a.localeCompare(b)).forEach(g => {
                const key = g.toLowerCase();
                if (existing.has(key)) return;
                const label = document.createElement('label');
                label.className = 'flt-opt';
                label.innerHTML = `<input type="checkbox" value="${esc(key)}"> ${esc(g)}`;
                if (state.filters.groups.has(key)) label.querySelector('input').checked = true;
                grpPanel.appendChild(label);
            });
        }
    },

    // Filter with OR-within-dimension, AND-across-dimensions; then multi-column
    // TimSort in O(N log N) with zero per-comparison allocation (precomputed keys).
    updateTable() {
        const { search, tags, groups, diffs } = state.filters;
        state.filtered = state.problems.filter(p => {
            if (search && !(p.searchIndex || '').includes(search)) return false;
            if (tags.size  > 0 && !([...tags].some(t => p._tagSet?.has(t)))) return false;
            if (groups.size > 0 && !groups.has((p.group||'').toLowerCase())) return false;
            if (diffs.size > 0 && (p.rating == null || !diffs.has(String(getStarCount(p.rating))))) return false;
            return true;
        });

        // Multi-level sort: iterate sort specs in order; first non-zero wins
        state.filtered.sort((a, b) => {
            for (const { column: col, ascending: asc } of state.sorts) {
                let c = 0;
                switch (col) {
                    case 'name':     c = (a._nameKey||'').localeCompare(b._nameKey||''); break;
                    case 'group':    c = (a._groupKey||'').localeCompare(b._groupKey||''); break;
                    case 'tags':     c = (a._tagsKey||'').localeCompare(b._tagsKey||''); break;
                    case 'progress': c = (a.progress||0) - (b.progress||0); break;
                    default:         c = (a.rating||0) - (b.rating||0); break;
                }
                if (c !== 0) return asc ? c : -c;
            }
            return 0;
        });

        const resultCount = document.getElementById('flt-results');
        if (resultCount) {
            const shown = state.filtered.length.toLocaleString();
            const total = state.problems.length.toLocaleString();
            resultCount.textContent = state.filtered.length === state.problems.length
                ? `${shown} results`
                : `${shown} of ${total} results`;
        }

        this.renderVirtual();
    },

    // Renders only the rows within (±OVERSCAN) of the current scroll viewport,
    // using top/bottom spacer rows to preserve correct scrollbar size/position.
    // At 800 rows this keeps the DOM at ~20-30 <tr> instead of ~800, which is
    // what actually made re-sorting feel instant (the sort itself was never the
    // bottleneck — rebuilding thousands of DOM nodes + listeners was).
    renderVirtual() {
        const wrap = document.querySelector('.tbw');
        const tbody = document.getElementById('prob-tbody');
        if (!wrap || !tbody) return;
        const probs = state.filtered;
        if (!probs.length) { tbody.innerHTML = '<tr class="empty-r"><td colspan="6">No problems match your filters</td></tr>'; return; }

        const total = probs.length;
        const viewH = wrap.clientHeight || 400;
        let start = Math.floor(wrap.scrollTop / ROW_H) - OVERSCAN;
        let end   = Math.ceil((wrap.scrollTop + viewH) / ROW_H) + OVERSCAN;
        start = Math.max(0, Math.min(start, total));
        end   = Math.max(start, Math.min(end, total));

        const topH = start * ROW_H, botH = (total - end) * ROW_H;
        let html = '';
        if (topH > 0) html += `<tr class="vsp"><td colspan="6" style="height:${topH}px;padding:0;border:0"></td></tr>`;
        for (let i = start; i < end; i++) html += this.rowHtml(probs[i]);
        if (botH > 0) html += `<tr class="vsp"><td colspan="6" style="height:${botH}px;padding:0;border:0"></td></tr>`;
        tbody.innerHTML = html;
    },

    rowHtml(p) {
        const classified = p.rating != null && p.tags && p.tags.length;
        const rank = classified ? getRatingRank(p.rating) : { label:'Unrated', color:'var(--ts)' };
        const col = rank.color;
        const progress = clamp(Number(p.progress) || 0, 0, 100);
        const progressColor = getProgressColor(progress);
        const stars = classified ? getStarRating(p.rating) : '·  ·  ·';
        const ratingTxt = classified ? p.rating : '—';
        const isRe=state.reclassifying.has(p.id);
        const act=isRe
            ?`<div class="rspin"><svg class="sp" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" stroke-width="2"/></svg>Working…</div>`
            :`<div class="acb"><button class="rcb" data-pid="${p.id}" title="Reclassify with the selected Google Gemini models"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 7 14"/><path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 0 1 3.51 15"/></svg></button></div>`;

        const tags = p.tags || [];
        let tagHtml;
        const hidden = state.hideTags && classified && !state.revealedTagRows.has(p.id);
        if (hidden) {
            tagHtml = `<span class="tb2 tag-hidden" data-pid="${p.id}" title="Click to reveal">${this.eyeIcon()} ${tags.length} tag${tags.length===1?'':'s'} hidden</span>`;
        } else if (p.classificationDeferred) {
            tagHtml = `<span class="tb2 unclassified-tag" title="${esc(p.deferReason || 'AI provider unavailable')}">AI retry pending</span>`;
        } else if (!classified) {
            tagHtml = `<span class="tb2 unclassified-tag">queued for AI…</span>`;
        } else {
            tagHtml = tags.map(t=>`<span class="tb2">${esc(t)}</span>`).join('');
        }

        const summary = classified ? (p.reasoning_summary || '') : '';
        const summaryHtml = summary ? `<div class="rsum" title="${esc(summary)}">${esc(summary)}</div>` : '';
        const diffLabel = classified ? `${labelDifficulty(p.difficulty || difficultyFromRating(p.rating))} · ${rank.label}` : '';
        const confTxt = classified && typeof p.confidence === 'number' ? `${Math.round(p.confidence * 100)}%` : '';
        const escTxt = classified ? 'batched AI classification after questions.txt commit' : '';
        const providerTxt = classified ? `${this.pvName(p.source_provider || p.classifiedBy)}${p.source_model ? ' / ' + p.source_model : ''}` : '';

        return `<tr class="pr${classified?'':' unclassified-row'}" data-pid="${p.id}">
<td class="pn"><a href="${p.href}" target="_blank" class="pl">${esc(p.name)}</a></td>
<td><div class="pgw"><div class="pgb" role="progressbar" aria-label="${esc(p.name)} completion" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${progress}"><div class="pgf" style="width:${progress}%;--progress-color:${progressColor}"></div></div><span class="pgt">${formatPct(progress)}</span></div></td>
<td><div class="gw"><span class="gb">${esc(p.group||'Public')}</span></div></td>
<td><div class="tag-cell"><div class="tw"><div class="tag-scroll">${tagHtml}</div><button class="ebt et" data-pid="${p.id}" title="Edit difficulty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg></button></div>${summaryHtml}</div></td>
<td><div class="dfw" style="color:${col}" title="${esc(rank.label)}"><span class="dfs" aria-hidden="true">${stars}</span><span class="dfr rating-value" title="${esc(rank.label)}">${ratingTxt}</span><button class="ebt er" data-pid="${p.id}" title="Edit difficulty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg></button></div>${classified?`<div class="class-meta" title="${esc(providerTxt)}"><span>${esc(diffLabel)}</span>${confTxt?`<span>${esc(confTxt)}</span>`:''}<span class="esc no" title="${esc(escTxt)}">AI</span></div><div class="clby">via ${esc(providerTxt)}</div>`:''}</td>
<td class="acc">${act}</td></tr>`;
    },

    // Faint autosave checkmark — appears in the header area, fades after 2s
    flashSaved() {
        let el = document.getElementById('gist-saved-check');
        if (!el) {
            el = document.createElement('span');
            el.id = 'gist-saved-check';
            el.innerHTML = `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.5" width="14" height="14"><polyline points="2 9 6 13 14 4"/></svg> Saved`;
            el.style.cssText = 'position:fixed;bottom:18px;right:22px;display:flex;align-items:center;gap:5px;font-size:11px;font-weight:500;color:var(--ab,#2ea043);opacity:0;transition:opacity .4s;z-index:99999;pointer-events:none;letter-spacing:.02em;';
            document.body.appendChild(el);
        }
        el.style.opacity = '1';
        clearTimeout(el._t);
        el._t = setTimeout(()=>{ el.style.opacity='0'; }, 2200);
    },

    // Reclassify-in-progress state lives in state.reclassifying and is read by
    // rowHtml() — with virtualization the target row may currently be scrolled
    // out of view, so just re-render the visible window rather than touching a
    // specific <tr> (the delegated click handler in attachHandlers already
    // covers any buttons in the freshly-rendered markup).
    updateRow(pid, loading) {
        this.renderVirtual();
    },

    updateCounter() {
        const classified = state.problems.filter(p => Array.isArray(p.tags) && p.tags.length && p.rating != null).length;
        $('#cached-count').text(classified);
        if (state.total > 0) $('#total-count').text(state.total);
    },
    pvName(pn) {
        if (pn === 'google') return 'Google Gemini';
        if (pn === 'fallback') return 'Fallback';
        if (pn === 'router') return 'Google Gemini model pool';
        return API_PROVIDERS.find(p=>p.name===pn)?.displayName || pn || 'Unknown';
    },

    showTagEditor(pid) {
        const p=state.problems.find(pr=>String(pr.id)===String(pid)); if(!p) return;
        const ct=p.tags||[], ata=Array.from(VALID_TAGS).sort();
        const modal=$(`<div class="mo"><div class="mb"><div class="mh"><h3>Edit Tags — ${esc(p.name)}</h3><button class="mc">&times;</button></div><div class="mbd"><div class="tg">${ata.map(t=>`<label class="to ${ct.includes(t)?'sel':''}"><input type="checkbox" value="${t}" ${ct.includes(t)?'checked':''}><span>${esc(t)}</span></label>`).join('')}</div></div><div class="mft"><button class="mbt mbs mc2">Cancel</button><button class="mbt mbp ms">Save</button></div></div></div>`);
        $('body').append(modal);
        modal.find('.to input').on('change',function(){ $(this).closest('.to').toggleClass('sel',this.checked); });
        modal.find('.mc,.mc2').on('click',()=>modal.remove());
        modal.find('.ms').on('click', async ()=>{
            const st=modal.find('.to input:checked').map(function(){ return $(this).val(); }).get();
            if(!st.length){ alert('Select at least one tag'); return; }
            p.tags=st;
            setSortKeys(p);
            const d={tags:st,rating:p.rating,classifiedBy:'manual',classifiedAt:Date.now()};
            await new Promise(r=>window.__NZOI_SAFE_STORAGE__.local.set({[`nztags_${p.id}`]:d},r));
            st.forEach(t=>state.allTags.add(t));
            LOG('Tags saved manually for', p.name, st);
            classifier.markDirty(p.id);
            classifier.requestSync();
            ui.updateTable(); modal.remove();
        });
    },

    showRatingEditor(pid) {
        const p=state.problems.find(pr=>String(pr.id)===String(pid)); if(!p) return;
        const modal=$(`<div class="mo"><div class="mb mb-sm"><div class="mh"><h3>Edit Difficulty — ${esc(p.name)}</h3><button class="mc">&times;</button></div><div class="mbd"><div class="re"><label>Codeforces-style rating (500–3000, nearest 100):</label><input type="number" id="ri" min="500" max="3000" step="100" value="${p.rating}"><div class="rg"><div class="gi"><span class="gr">500:</span><span class="gd">Pure basic I/O</span></div><div class="gi"><span class="gr">600–700:</span><span class="gd">Trivial</span></div><div class="gi"><span class="gr">800–900:</span><span class="gd">Easy</span></div><div class="gi"><span class="gr">1000–1500:</span><span class="gd">Medium</span></div><div class="gi"><span class="gr">1600–1700:</span><span class="gd">Difficult</span></div><div class="gi"><span class="gr">1800–2100:</span><span class="gd">Very hard</span></div><div class="gi"><span class="gr">2200–3000:</span><span class="gd">IOI-level</span></div></div></div></div><div class="mft"><button class="mbt mbs mc2">Cancel</button><button class="mbt mbp ms">Save</button></div></div></div>`);
        $('body').append(modal);
        modal.find('.mc,.mc2').on('click',()=>modal.remove());
        modal.find('.ms').on('click', async ()=>{
            const entered=parseInt(modal.find('#ri').val());
            if(isNaN(entered)||entered<500||entered>3000){ alert('Enter a valid rating 500–3000'); return; }
            const nr=roundRating(entered);
            p.rating=nr;
            p.difficulty=difficultyFromRating(nr); p.estimated_rating={...(p.estimated_rating||{}),nzoi:nr}; const d={tags:p.tags,rating:nr,difficulty:p.difficulty,estimated_rating:p.estimated_rating,classifiedBy:'manual',classifiedAt:Date.now()};
            await new Promise(r=>window.__NZOI_SAFE_STORAGE__.local.set({[`nztags_${p.id}`]:d},r));
            LOG('Rating saved manually for', p.name, nr);
            classifier.markDirty(p.id);
            classifier.requestSync();
            ui.updateTable(); modal.remove();
        });
    },
};

// ─── Bootstrap ────────────────────────────────────────────────────────────────

async function run() {
    LOG('Dashboard v12 init start');
    setDashboardActivity('Loading dashboard');

    // ── Load API keys + view preferences from storage (single round-trip) ────
    const storedKeys = await new Promise(r => window.__NZOI_SAFE_STORAGE__.local.get(
        ['mistralKeys', 'mistralKey', 'mistralModels', 'mistralModel', 'mistralTier1PromptTemplate',
          'classifierPromptTemplate', 'googleKeys', 'googleKey', 'geminiKey', 'googleModels', 'googleModel',
          'theme', 'dashboardHideTags'], r
    ));
    if (!storedKeys.classifierPromptTemplate && storedKeys.mistralTier1PromptTemplate) {
        await new Promise(resolve => window.__NZOI_SAFE_STORAGE__.local.set(
            { classifierPromptTemplate:storedKeys.mistralTier1PromptTemplate }, resolve
        ));
    }
    await new Promise(resolve => window.__NZOI_SAFE_STORAGE__.local.remove(
        ['mistralKeys', 'mistralKey', 'mistralModels', 'mistralModel', 'mistralTier1PromptTemplate', 'groqKeys', 'groqModels'], resolve
    ));

    // Apply theme immediately — before any HTML is rendered — so there is no
    // flash of the wrong theme. Default to 'dark' (the extension's original look).
    state.theme = (storedKeys.theme === 'light') ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', state.theme);
    document.documentElement.classList.add('nzoi-dashboard-page');
    const mainContainer = document.getElementById('main-container');
    let fitDashboardToViewport = () => {};
    if (mainContainer) {
        fitDashboardToViewport = () => {
            const dashboardScale = 0.9;
            const viewportHeight = window.visualViewport?.height || window.innerHeight;
            const top = Math.max(0, mainContainer.getBoundingClientRect().top / dashboardScale);
            const h = Math.max(180, viewportHeight / dashboardScale - top);
            mainContainer.style.setProperty('--nzoi-dashboard-top', `${top}px`);
            // The dashboard stylesheet declares these dimensions !important;
            // the runtime viewport measurement must use the same priority.
            mainContainer.style.setProperty('height', `${h}px`, 'important');
            mainContainer.style.setProperty('max-height', `${h}px`, 'important');
        };
        requestAnimationFrame(fitDashboardToViewport);
        window.addEventListener('resize', fitDashboardToViewport, { passive: true });
        window.addEventListener('orientationchange', fitDashboardToViewport, { passive: true });
        window.visualViewport?.addEventListener('resize', fitDashboardToViewport, { passive: true });
        if (typeof ResizeObserver === 'function') {
            const dashboardChromeObserver = new ResizeObserver(() => requestAnimationFrame(fitDashboardToViewport));
            [document.getElementById('main-menu'), mainContainer.previousElementSibling]
                .filter(Boolean).forEach(el => dashboardChromeObserver.observe(el));
            mainContainer._nzoiViewportObserver = dashboardChromeObserver;
        }
    }
    document.querySelectorAll('#right-menu ul,#right-menu .sf-sub-indicator').forEach(el => el.remove());
    document.querySelectorAll('#right-menu .sf-with-ul').forEach(el => el.classList.remove('sf-with-ul'));
    state.hideTags = !!storedKeys.dashboardHideTags;

    API_PROVIDERS = [];
    const canonicalModel = value => String(value || '').replace(/^models\//, '').trim();
    const storedModels = (value, legacy) => {
        const selected = [...new Set(
        (Array.isArray(value) && value.length ? value : (legacy ? [legacy] : GOOGLE_DEFAULT_MODEL_IDS))
            .map(canonicalModel)
            .filter(model => GOOGLE_MODEL_IDS.includes(model))
        )];
        return selected.length ? selected : [...GOOGLE_DEFAULT_MODEL_IDS];
    };
    const addProviderPool = (provider, label, keys, models, limits={}) => {
        models.forEach((model, modelIndex) => {
            keys.forEach((key, keyIndex) => {
                if (!key) return;
                API_PROVIDERS.push({
                    name:`${provider}-${modelIndex}-${keyIndex}`,
                    provider,
                    quotaGroup:`${provider}:${model}`,
                    displayName:`${label} · ${model}${keys.length > 1 ? ` · key ${keyIndex + 1}` : ''}`,
                    key,
                    model,
                    classificationEnabled:true,
                    ...limits,
                });
            });
        });
    };

    const googleKeys = storedKeys.googleKeys || (storedKeys.googleKey ? [storedKeys.googleKey] : (storedKeys.geminiKey ? [storedKeys.geminiKey] : []));
    const googleModels = storedModels(storedKeys.googleModels, storedKeys.googleModel);
    addProviderPool('google', 'Google Gemini', googleKeys, googleModels, {
        rpmLimit:GOOGLE_LIMITS.requestsPerMinute,
        dailyTimeZone:'America/Los_Angeles',
        contextWindowTokens:GOOGLE_LIMITS.contextWindowTokens,
    });

    LOG('Provider/model pool:', API_PROVIDERS.map(p=>p.displayName).join(', ')||'NONE');
    initApiStates();
    await apiMgr.loadPersisted();

    // ── PHASE 1: Wait only for the DOM we need for own-page scrape ───────────
    await new Promise(resolve => {
        if ($('.subheading').length || $('table tbody tr').length) { resolve(); return; }
        const ci = setInterval(() => {
            if ($('.subheading').length || $('h2').length) { clearInterval(ci); resolve(); }
        }, 100);
        setTimeout(() => { clearInterval(ci); resolve(); }, 4000); // hard cap
    });
    LOG('DOM ready for scraping');

    // Capture the server-rendered private-group links before ui.init replaces
    // #main-container with the enhanced dashboard.
    const myGrps = scrapers.getMyGroups();

    // ── PHASE 2: Instant own-page scrape — pure DOM, no network ─────────────
    const ownPage = scrapers.getOwnPageProblems();
    ownPage.forEach(p => { if (p.group) state.allGroups.add(p.group); });
    state.total = ownPage.length;

    // ── PHASE 3: Load from local window.__NZOI_SAFE_STORAGE__ — <5ms, no network ──────────
    const { cached: localCached, uncached: localUncached } = await cache.loadLocal(ownPage);

    // ── PHASE 4: FIRST PAINT — render immediately with whatever we have ──────
    ui.init(state.total, myGrps); // inject chrome with total count
    setDashboardActivity('Dashboard ready', 'success');
    window.__NZOI_SAFE_STORAGE__.local.get(['nzoiClassifierProgress','nzoiQuestionArchiveQueueStatus'], data => {
        renderClassifierProgress(data.nzoiClassifierProgress);
        const archiveStatus=data.nzoiQuestionArchiveQueueStatus||{};
        questionArchive._pendingCount=Number(archiveStatus.pending)||0;
        questionArchive._lastError=String(archiveStatus.lastError||'');
        questionArchive._activity=String(archiveStatus.activity||'');
        questionArchive.updateStatus();
    });
    fitDashboardToViewport();   // styles now include the dashboard-only 90% zoom
    // Show all known problems (classified + unclassified skeleton rows)
    const allKnown = [
        ...localCached,
        ...localUncached.map(p => ({ ...p, tags: null, rating: null }))
    ];
    upsertProblems(allKnown);
    ui.populateFilters();
    ui.updateTable();   // renders classified rows immediately; unclassified get skeleton
    ui.updateCounter();
    LOG(`First paint: ${localCached.length} classified + ${localUncached.length} skeleton rows`);

    const ingestNewProblems = async (newProbs, label, updatedProbs=[]) => {
        const freshProblems = [...new Map((newProbs||[])
            .filter(problem => /^\d+$/.test(String(problem?.id||'')))
            .filter(problem => !state.problemById.has(String(problem.id)) && !state.discoveredById.has(String(problem.id)))
            .map(problem => [String(problem.id), problem])).values()];
        freshProblems.forEach(problem=>state.discoveredById.set(String(problem.id),problem));
        const addedIds = new Set(freshProblems.map(problem => String(problem.id)));
        const updated = [...new Map(updatedProbs
            .filter(problem => !addedIds.has(String(problem.id)))
            .map(problem => [String(problem.id), problem])).values()];
        if (updated.length) {
            upsertProblems(updated);
            ui.populateFilters(); ui.updateTable(); ui.updateCounter();
            LOG(`${label}: refreshed ${updated.length} progress value(s)`);
        }
        if (!freshProblems.length) {
            if (!updated.length) LOG(`${label}: no new problems`);
            return;
        }
        state.total += freshProblems.length;
        $('#total-count').text(state.total);
        const { cached, uncached } = await cache.loadLocal(freshProblems);
        upsertProblems([
            ...cached,
            ...uncached.map(p => ({ ...p, tags: null, rating: null }))
        ]);
        ui.populateFilters(); ui.updateTable(); ui.updateCounter();
        if (uncached.length) {
            const { restored, stillUncached } = await cache.restoreFromGist(uncached);
            if (restored.length) {
                upsertProblems(restored);
                ui.populateFilters(); ui.updateTable(); ui.updateCounter();
            }
        }
        LOG(`${label}: picked up ${freshProblems.length} late problem(s); background queues own parsing, classification, and answer saving`);
    };

    let discoveryStatus = null;
    let reconciledDiscoveryRunId = '';
    const applyDiscoveryProgress = async value => {
        if (!value || value.runId === discoveryStatus?.runId && value.updatedAt === discoveryStatus?.updatedAt) return;
        discoveryStatus = value;
        if (value.activity && !/^(?:Found all available problems|Background discovery complete)$/i.test(value.activity)) {
            setDashboardActivity(value.status === 'needs-login' || value.status === 'complete-with-errors' ? 'Error' : value.activity,
                value.status === 'needs-login' || value.status === 'complete-with-errors' ? 'error' : 'working');
        }
        if (value.lastError && value.status !== 'complete' && value.status !== 'complete-with-errors')
            ERR('Background discovery status:', value.lastError);
        if (Array.isArray(value.newProblems) && value.newProblems.length) {
            const updates=value.newProblems.filter(problem=>state.problemById.has(String(problem.id)) && Number(problem.progress)>Number(state.problemById.get(String(problem.id))?.progress||0));
            await ingestNewProblems(value.newProblems,'Background discovery',updates);
        }
        if (Number.isFinite(Number(value.discoveredCount))) {
            state.total=Math.max(state.total,Number(value.discoveredCount));
            $('#total-count').text(state.total);
        }
        if(['complete','complete-with-errors'].includes(value.status)&&value.runId&&reconciledDiscoveryRunId!==value.runId){
            reconciledDiscoveryRunId=value.runId;
            try{
                const snapshot=await bg({type:'problem:discoverySnapshot'});
                if(Array.isArray(snapshot?.problems)){
                    await ingestNewProblems(snapshot.problems,'Final background discovery reconciliation');
                    state.total=Math.max(Number(snapshot.discoveredCount)||0,state.problems.length);
                    $('#total-count').text(state.total);
                }
            }catch(error){ERR('Final background discovery snapshot failed:',error.message);}
        }
        ui.updateCounter();
    };
    window.__NZOI_SAFE_STORAGE__.onChanged.addListener((changes,area)=>{
        if(area!=='local')return;
        if(changes.githubToken)gistClassificationSnapshotPromise=null;
        if(changes.nzoiProblemDiscoveryProgressV1)
            void applyDiscoveryProgress(changes.nzoiProblemDiscoveryProgressV1.newValue).catch(error=>ERR('Dashboard discovery update failed:',error.message));
        const work=changes.nzoiBackgroundProblemWorkProgressV1?.newValue;
        if(work?.activity&&!/complete/i.test(work.activity))
            setDashboardActivity(work.lastError?'Error':work.activity,work.lastError?'error':'working');
    });

    // Reuse the one bulk Gist read for this dashboard session; future pages
    // discovered by the worker can paint their cached ratings without making
    // one GitHub request per page.
    void cache.restoreFromGist(localUncached).then(({restored})=>{
        if(!restored.length)return;
        upsertProblems(restored);ui.populateFilters();ui.updateTable();ui.updateCounter();
        LOG(`Background scan painted ${restored.length} existing Gist classifications`);
    }).catch(error=>LOG('Initial Gist classification restore will retry on a later dashboard load:',error.message));

    // The dashboard only seeds and observes the persistent worker. Discovery,
    // parsing, classification, Gist uploads, and best-answer archives continue
    // when this tab closes.
    try {
        setDashboardActivity('Finding problems');
        const result=await bg({type:'problem:discoveryStart',homeUrl:`${location.origin}/`,groups:myGrps,problems:ownPage});
        if(Array.isArray(result?.problems))await ingestNewProblems(result.problems,'Resumed background scan');
        const progress=await new Promise(resolve=>window.__NZOI_SAFE_STORAGE__.local.get('nzoiProblemDiscoveryProgressV1',data=>resolve(data.nzoiProblemDiscoveryProgressV1||null)));
        if(progress)await applyDiscoveryProgress(progress);
        LOG(`Background discovery active: ${Number(result?.discoveredCount)||0} problems currently known`);
    } catch(error) {
        setDashboardActivity('Error','error');
        ERR('Could not start persistent background problem discovery:',error.message,error);
    }
    LOG('Bootstrap complete. Problems currently displayed:',state.problems.length);
}

run().catch(e => ERR('Fatal error:', e));

} // end initDashboard

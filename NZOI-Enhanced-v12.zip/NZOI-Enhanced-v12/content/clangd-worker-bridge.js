// Runs in the embedded clangd page's MAIN world before its app bundle. The
// iframe keeps the clangd WASM worker as a language service while the visible
// editor is the extension's local Monaco instance.
(() => {
  'use strict';

  const PARENT_ORIGIN = 'https://train.nzoi.org.nz';
  const marker = '__nzoiClangdWorker';
  const semanticTokenCapabilities = {
    tokenTypes:[
      'namespace','type','class','enum','interface','struct','typeParameter','parameter',
      'variable','property','enumMember','event','function','method','macro','keyword',
      'modifier','comment','string','number','regexp','operator','decorator',
    ],
    tokenModifiers:[
      'declaration','definition','readonly','static','deprecated','abstract','async',
      'modification','documentation','defaultLibrary',
    ],
  };
  const nonce = (() => {
    try { return new URLSearchParams(location.hash.slice(1)).get('nzoi') || ''; }
    catch { return ''; }
  })();
  if (!nonce || window.parent === window) return;

  const NativeWorker = window.Worker;
  let clangdWorker = null;
  const pending = [];
  const isClangdWorker = (url, options) => options?.name === 'Server Worker' ||
    /main\.worker(?:-[^/?]+)?\.js/i.test(String(url || ''));

  function advertiseSemanticTokens(message) {
    let wasString = false;
    let parsed = message;
    if (typeof parsed === 'string') {
      try { parsed = JSON.parse(parsed); wasString = true; }
      catch { return message; }
    }
    if (!parsed || typeof parsed !== 'object' || parsed.method !== 'initialize') return message;
    const params = parsed.params || {};
    const capabilities = params.capabilities || {};
    const textDocument = capabilities.textDocument || {};
    const existing = textDocument.semanticTokens || {};
    const existingRequests = existing.requests || {};
    const fullRequest = existingRequests.full && typeof existingRequests.full === 'object'
      ? existingRequests.full
      : {};
    const semanticTokens = {
      ...existing,
      dynamicRegistration:false,
      requests:{ ...existingRequests, range:false, full:{ ...fullRequest, delta:false } },
      tokenTypes:Array.isArray(existing.tokenTypes) && existing.tokenTypes.length
        ? existing.tokenTypes : semanticTokenCapabilities.tokenTypes,
      tokenModifiers:Array.isArray(existing.tokenModifiers) && existing.tokenModifiers.length
        ? existing.tokenModifiers : semanticTokenCapabilities.tokenModifiers,
      formats:Array.isArray(existing.formats) && existing.formats.length ? existing.formats : ['relative'],
      overlappingTokenSupport:existing.overlappingTokenSupport ?? false,
      multilineTokenSupport:existing.multilineTokenSupport ?? false,
    };
    const augmented = {
      ...parsed,
      params:{
        ...params,
        capabilities:{
          ...capabilities,
          textDocument:{ ...textDocument, semanticTokens },
        },
      },
    };
    return wasString ? JSON.stringify(augmented) : augmented;
  }

  function forwardToWorker(message) {
    if (!clangdWorker) { pending.push(message); return; }
    try { clangdWorker.postMessage(message); }
    catch (error) { console.warn('[NZOI clangd bridge] Worker postMessage failed:', error); }
  }

  function WrappedWorker(url, options) {
    const worker = new NativeWorker(url, options);
    if (isClangdWorker(url, options)) {
      clangdWorker = worker;
      worker.addEventListener('message', event => {
        window.parent.postMessage({ [marker]:'message', nonce, message:event.data }, PARENT_ORIGIN);
      });
      const nativePostMessage = worker.postMessage.bind(worker);
      worker.postMessage = (...args) => {
        const outbound = [...args];
        outbound[0] = advertiseSemanticTokens(outbound[0]);
        window.parent.postMessage({ [marker]:'request', nonce, message:outbound[0] }, PARENT_ORIGIN);
        return nativePostMessage(...outbound);
      };
      for (const message of pending.splice(0)) {
        try { worker.postMessage(message); } catch {}
      }
    }
    return worker;
  }
  Object.setPrototypeOf(WrappedWorker, NativeWorker);
  WrappedWorker.prototype = NativeWorker.prototype;
  window.Worker = WrappedWorker;

  window.addEventListener('message', event => {
    const data = event.data;
    if (event.source !== window.parent || event.origin !== PARENT_ORIGIN ||
      !data || data[marker] !== 'forward' || data.nonce !== nonce || !data.message) return;
    forwardToWorker(data.message);
  });
})();

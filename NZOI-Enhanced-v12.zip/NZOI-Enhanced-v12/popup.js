'use strict';

const DEFAULT_CLASSIFIER_PROMPT_TEMPLATE = `You are the sole competitive-programming classifier for NZOI Training.

Return ONLY one valid JSON object. Do not use markdown. Do not include extra keys.
Do not give a solution, algorithm walkthrough, pseudocode, or code.

Base the classification on the complete statement, input/output format, constraints, subtasks, and samples. Infer the intended efficient technique from the constraints rather than matching isolated keywords.

Your job:
- Classify difficulty using exactly one of: beginner, easy, medium, hard, very_hard, hardcore, olympiad_hard.
- Estimate Codeforces-style ratings for codeforces, atcoder, usaco, and nzoi on a shared 500–3000 scale. Each rating must be an integer rounded to the nearest 100.
- Use 500 only for the most basic I/O: the output follows directly from the input, with no problem-specific computation or extra solution logic.
- Use these non-overlapping bands: 600–700 trivial; 800–900 easy; 1000–1500 medium; 1600–1700 difficult; 1800–2100 very hard; 2200–3000 IOI-level. The boundaries are assigned to the band that starts at that value. Round half-way values up and never go below 500 or above 3000.
- A required observation, branch, loop, simulation, or case handling must score above 800 (at least 900 after rounding). Use 600 or higher when a correct solution needs more than a few straightforward lines. Do not let a short implementation hide a difficult insight.
- Derive difficulty from estimated_rating.nzoi: beginner for 500; easy for 600–900; medium for 1000–1500; hard for 1600–1700; very_hard for 1800–2100; hardcore for 2200–2500; olympiad_hard for 2600–3000. Both final categories are within the IOI-level rating band.
- Choose one to four skills that are genuinely required by the intended solution. Do not add tags merely because their words appear in the story.
- primary_skill must be the main algorithmic bottleneck. Use implementation only when no more specific algorithmic tag is justified.
- Judge difficulty from required insight, proof burden, implementation risk, and constraints—not statement length.
- Treat the previous classification only as a weak consistency hint; override it whenever the statement disagrees.
- If the statement or constraints are incomplete, lower confidence and raise risk_of_misclassification instead of inventing details.
- If the problem is ambiguous, advanced, or easy to misread, set confidence below 0.85 and risk_of_misclassification to medium or high.
- Keep reasoning_summary short and high-level. Do not reveal hidden chain-of-thought.

Risky topics that should lower confidence or mark the problem hard include: tricky DP, graph modeling, modified shortest path, flows, matching, geometry, number theory, combinatorics, game theory, string hashing, suffix structures, heavy data structures, proof-heavy greedy, and binary search on answer.

Allowed existing tags:
{{TAGS}}

Previous classification anchor, if any. Use it only if it still matches the statement and constraints:
{{PREVIOUS}}

Problem title:
{{TITLE}}

Problem URL:
{{URL}}

Problem statement:
{{TEXT}}

Required JSON shape:
{
  "difficulty": "beginner|easy|medium|hard|very_hard|hardcore|olympiad_hard",
  "estimated_rating": { "codeforces": 1200, "atcoder": 1200, "usaco": 1200, "nzoi": 1200 },
  "primary_skill": "one existing tag",
  "skills": ["one existing tag"],
  "reasoning_summary": "brief non-solution reason",
  "risk_of_misclassification": "low|medium|high",
  "confidence": 0.0
}`;

function migrateClassifierPromptScale(template) {
  const source=String(template||'');
  if (!/(?:nearest\s+10\b|divisible by 10\b|600\s*[–-]\s*790|800\s*[–-]\s*990|1000\s*[–-]\s*1590)/i.test(source)) return source;
  const rubric=DEFAULT_CLASSIFIER_PROMPT_TEMPLATE.split(/\r?\n/).filter(line=>
    /^- /.test(line) && /Estimate Codeforces-style ratings|Use 500 only|non-overlapping bands|observation, branch|Derive difficulty from estimated_rating\.nzoi/i.test(line)
  );
  const lines=source.split(/\r?\n/);
  const isOldRatingRule=line=>/^\s*-\s*(?:Estimate .*rating|Use 500 only|Use .*rating bands|Map the difficulty enum|Use \d+ or higher)/i.test(line);
  const first=lines.findIndex(isOldRatingRule);
  if (first<0) return source;
  const kept=lines.filter((line,index)=>!isOldRatingRule(line)||index<first);
  kept.splice(first,0,...rubric);
  return kept.join('\n');
}

// ── Key list helpers ──────────────────────────────────────────────────────────

function buildKeyRow(value, placeholder, onRemove) {
  const row = document.createElement('div');
  row.className = 'key-row';
  const inp = document.createElement('input');
  inp.type = 'password';
  inp.value = value || '';
  inp.placeholder = placeholder;
  const eye = document.createElement('button');
  eye.className = 'eye';
  eye.textContent = 'show';
  eye.addEventListener('click', () => {
    inp.type = inp.type === 'password' ? 'text' : 'password';
    eye.textContent = inp.type === 'password' ? 'show' : 'hide';
  });
  row.appendChild(inp);
  row.appendChild(eye);
  if (onRemove) {
    const rem = document.createElement('button');
    rem.className = 'rem';
    rem.textContent = '×';
    rem.addEventListener('click', onRemove);
    row.appendChild(rem);
  }
  return row;
}

function addKey(listId, placeholder) {
  const list = document.getElementById(listId);
  const row = buildKeyRow('', placeholder, () => row.remove());
  list.appendChild(row);
}

function getKeys(listId) {
  return [...new Set(Array.from(document.querySelectorAll(`#${listId} .key-row input`))
    .map(i => i.value.trim()).filter(Boolean))];
}

function renderKeys(listId, keys, placeholder) {
  const list = document.getElementById(listId);
  list.innerHTML = '';
  const all = keys.length ? keys : [''];
  all.forEach((k, i) => {
    const row = buildKeyRow(k, placeholder, i === 0 ? null : () => row.remove());
    list.appendChild(row);
  });
}

// Keep this catalog limited to models Google currently lists with free-tier
// Gemini API usage. The Pro preview is intentionally excluded because its
// Standard API tier is paid-only. Update this catalog only after checking the
// official pricing page; Find models verifies access, not billing eligibility.
const GOOGLE_MODEL_CHOICES = [
  { id:'gemini-3.8-flash', label:'Gemini 3.8 Flash', strength:'Strongest', default:true },
  { id:'gemini-3.7-flash', label:'Gemini 3.7 Flash', strength:'Strong', default:true },
  { id:'gemini-3.6-flash', label:'Gemini 3.6 Flash', strength:'Standard' },
  { id:'gemini-3.5-flash', label:'Gemini 3.5 Flash', strength:'Standard' },
  { id:'gemini-3.5-flash-lite', label:'Gemini 3.5 Flash-Lite', strength:'Fast / light' },
  { id:'gemini-3.1-flash-lite', label:'Gemini 3.1 Flash-Lite', strength:'Fast / light' },
];
const GOOGLE_MODEL_BY_ID = new Map(GOOGLE_MODEL_CHOICES.map(model => [model.id, model]));
const DEFAULT_GOOGLE_MODELS = GOOGLE_MODEL_CHOICES.filter(model => model.default).map(model => model.id);
const selectedModels = { google:[...DEFAULT_GOOGLE_MODELS] };
let availableGoogleModelIds = null;

function cleanGoogleModelIds(values) {
  const selected = [...new Set((Array.isArray(values) ? values : [])
    .map(value => String(value || '').replace(/^models\//, '').trim())
    .filter(value => GOOGLE_MODEL_BY_ID.has(value)))];
  return selected.length ? selected : [...DEFAULT_GOOGLE_MODELS];
}

function renderGoogleModelChoices() {
  const container = document.getElementById('google-model-tiers');
  if (!container) return;
  container.replaceChildren();
  for (const model of GOOGLE_MODEL_CHOICES) {
    const label = document.createElement('label');
    label.className = 'model-tier';
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.dataset.googleModel = model.id;
    input.checked = selectedModels.google.includes(model.id);
    input.disabled = availableGoogleModelIds !== null && !availableGoogleModelIds.has(model.id);
    input.addEventListener('change', () => {
      selectedModels.google = [...container.querySelectorAll('[data-google-model]:checked')]
        .map(item => item.dataset.googleModel);
      renderSelectedGoogleModels();
      updateAiStatus({ google:getKeys('google-keys').length > 0 });
    });
    const text = document.createElement('span');
    text.className = 'model-tier-label';
    const title = document.createElement('strong');
    title.textContent = model.label;
    const id = document.createElement('code');
    id.textContent = model.id;
    const detail = document.createElement('small');
    detail.textContent = input.disabled ? 'Not available to this key' : model.strength;
    text.append(title, id, detail);
    label.append(input, text);
    container.appendChild(label);
  }
}

function renderSelectedGoogleModels() {
  const target = document.getElementById('google-selected-models');
  if (!target) return;
  target.innerHTML = '';
  const selected = selectedModels.google;
  document.querySelectorAll('[data-google-model]').forEach(input => {
    input.checked = selected.includes(input.dataset.googleModel);
  });
  selected.forEach(model => {
    const chip = document.createElement('span');
    chip.className = 'model-chip';
    const label = document.createElement('span');
    label.textContent = GOOGLE_MODEL_BY_ID.get(model)?.label || model;
    label.title = model;
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.textContent = '×';
    remove.title = `Remove ${model}`;
    remove.addEventListener('click', () => {
      selectedModels.google = selectedModels.google.filter(value => value !== model);
      renderSelectedGoogleModels();
      updateAiStatus({ google:getKeys('google-keys').length > 0 });
    });
    chip.append(label, remove);
    target.appendChild(chip);
  });
  if (!selected.length) {
    const empty = document.createElement('span');
    empty.className = 'model-count';
    empty.textContent = 'No models selected';
    target.appendChild(empty);
  }
}

function setSelectedGoogleModels(models) {
  selectedModels.google = cleanGoogleModelIds(models);
  if (availableGoogleModelIds) {
    const available = selectedModels.google.filter(model => availableGoogleModelIds.has(model));
    selectedModels.google = available.length ? available : [...DEFAULT_GOOGLE_MODELS].filter(model => availableGoogleModelIds.has(model));
  }
  renderGoogleModelChoices();
  renderSelectedGoogleModels();
}

function findGoogleModels() {
  const keys = getKeys('google-keys');
  const key = keys[0] || '';
  const button = document.getElementById('google-find-models');
  const count = document.getElementById('google-model-count');
  if (!key) {
    count.textContent = 'Add a Google AI Studio key first.';
    return;
  }
  button.disabled = true;
  count.textContent = 'Checking your Gemini model access…';
  chrome.runtime.sendMessage({ type:'ai:listModels', provider:'google', apiKey:key }, response => {
    button.disabled = false;
    if (chrome.runtime.lastError || !response?.ok) {
      count.textContent = `Could not find models: ${chrome.runtime.lastError?.message || response?.error || 'unknown error'}`;
      return;
    }
    const modelIds = new Set((Array.isArray(response.data) ? response.data : [])
      .map(model => String(model?.id || '').replace(/^models\//, '').trim()));
    availableGoogleModelIds = new Set(GOOGLE_MODEL_CHOICES.filter(model => modelIds.has(model.id)).map(model => model.id));
    selectedModels.google = selectedModels.google.filter(model => availableGoogleModelIds.has(model));
    if (!selectedModels.google.length) selectedModels.google = DEFAULT_GOOGLE_MODELS.filter(model => availableGoogleModelIds.has(model));
    renderGoogleModelChoices();
    renderSelectedGoogleModels();
    count.textContent = `${availableGoogleModelIds.size} of ${GOOGLE_MODEL_CHOICES.length} free-tier Flash models found for this key`;
    updateAiStatus({ google:keys.length > 0 });
  });
}

document.getElementById('google-find-models')?.addEventListener('click', findGoogleModels);

// ── Load settings ─────────────────────────────────────────────────────────────

chrome.storage.local.get(
  ['githubToken','gistId','defaultLanguage','gistAutoSaveMs',
   'googleKeys','googleKey','geminiKey','googleModels','googleModel',
   'classifierPromptTemplate','mistralTier1PromptTemplate','nzoiClassifierProgress'],
  d => {
    if (d.githubToken)     document.getElementById('github-token').value = d.githubToken;
    if (d.gistId)          document.getElementById('gist-id').value = d.gistId;
    if (d.defaultLanguage) document.getElementById('default-lang').value = d.defaultLanguage;
    document.getElementById('autosave-delay').value = '5000';

    const gKeys = d.googleKeys || (d.googleKey ? [d.googleKey] : (d.geminiKey ? [d.geminiKey] : []));
    renderKeys('google-keys', gKeys, 'Google AI API key');
    setSelectedGoogleModels(d.googleModels || (d.googleModel ? [d.googleModel] : null));
    updateAiStatus({ google:gKeys.length > 0 });
    renderClassifierProgress(d.nzoiClassifierProgress);

    // Cerebras was removed because its endpoint did not provide a usable free
    // path for this extension. Delete obsolete secrets/settings during upgrade.
    chrome.storage.local.remove(['cerebrasKeys','cerebrasKey','cerebrasModel','googleTier2PromptTemplate',
      'bynaraKeys','bynaraKey','bynaraModels','bynaraModel',
      'groqKeys','groqModels','classifierConfidenceThreshold']);

    // Classification prompt — migrate the old tier-specific storage key once.
    const savedClassifierPrompt =
      (typeof d.classifierPromptTemplate === 'string' && d.classifierPromptTemplate.trim())
        ? d.classifierPromptTemplate
        : (typeof d.mistralTier1PromptTemplate === 'string' && d.mistralTier1PromptTemplate.trim())
          ? d.mistralTier1PromptTemplate
          : DEFAULT_CLASSIFIER_PROMPT_TEMPLATE;
    const classifierPrompt = migrateClassifierPromptScale(savedClassifierPrompt);
    document.getElementById('classifier-prompt-template').value = classifierPrompt;
    if (classifierPrompt !== savedClassifierPrompt && d.classifierPromptTemplate) {
      chrome.storage.local.set({ classifierPromptTemplate:classifierPrompt });
    }
    if (!d.classifierPromptTemplate && d.mistralTier1PromptTemplate) {
      chrome.storage.local.set({ classifierPromptTemplate:classifierPrompt }, () =>
        chrome.storage.local.remove('mistralTier1PromptTemplate')
      );
    } else if (d.classifierPromptTemplate && d.mistralTier1PromptTemplate) {
      chrome.storage.local.remove('mistralTier1PromptTemplate');
    }
    // Remove credentials and model preferences from the retired provider after
    // preserving a user's custom shared classification prompt above.
    chrome.storage.local.remove([
      'mistralKeys','mistralKey','mistralModels','mistralModel','mistralTier1PromptTemplate',
    ]);
  }
);

function updateAiStatus(active) {
  const s = document.getElementById('ai-status');
  const googleReady = !!active.google && selectedModels.google.length > 0;
  if (!googleReady) {
    s.textContent = active.google
      ? 'Select at least one Gemini model.'
      : 'Add a Google AI Studio key and select at least one Gemini model.';
    s.className = 'status err';
  } else {
    s.textContent = `Classification ready: Google Gemini · ${selectedModels.google.length} model${selectedModels.google.length === 1 ? '' : 's'}`;
    s.className = 'status ok';
  }
}

function renderClassifierProgress(progress) {
  const wrap = document.getElementById('classifier-progress');
  if (!wrap || !progress || !(Number(progress.total) > 0)) return;
  const total = Number(progress.total) || 0;
  const completed = Math.min(total, Number(progress.completed) || 0);
  const failed = Number(progress.failed) || 0;
  const hasError = !!progress.syncError || (progress.status === 'waiting' && !!progress.lastError) || failed > 0;
  wrap.hidden = false;
  document.getElementById('classifier-progress-label').textContent = hasError
    ? 'Error'
    : progress.status === 'complete'
      ? 'Classification complete'
    : `${progress.currentTier || 'Classification'} · ${completed} processed`;
  wrap.title = hasError ? 'An error occurred. Detailed diagnostics are available in the extension service worker console.' : '';
  document.getElementById('classifier-progress-count').textContent = `${completed}/${total}`;
  const bar = document.getElementById('classifier-progress-bar');
  bar.max = total; bar.value = completed;
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.nzoiClassifierProgress) renderClassifierProgress(changes.nzoiClassifierProgress.newValue);
});

// ── Add key buttons ───────────────────────────────────────────────────────────

// ── Token show/hide ───────────────────────────────────────────────────────────

document.getElementById('add-google-key')?.addEventListener('click', () => addKey('google-keys', 'Google AI API key'));

document.getElementById('toggle-token').addEventListener('click', () => {
  const inp = document.getElementById('github-token');
  inp.type = inp.type === 'password' ? 'text' : 'password';
  document.getElementById('toggle-token').textContent = inp.type === 'password' ? 'show' : 'hide';
});

// ── Save settings ─────────────────────────────────────────────────────────────

document.getElementById('save-settings').addEventListener('click', () => {
  const gistStatus = document.getElementById('gist-status');
  const token        = document.getElementById('github-token').value.trim();
  const gistId       = document.getElementById('gist-id').value.trim();
  const lang         = document.getElementById('default-lang').value;
  const delay        = 5000;
  const googleKeys = getKeys('google-keys');
  if (googleKeys.length && !selectedModels.google.length) {
    document.getElementById('ai-status').textContent = 'Select at least one Gemini model.';
    document.getElementById('ai-status').className = 'status err';
    return;
  }

  if (token && !token.startsWith('ghp_') && !token.startsWith('github_pat_')) {
    gistStatus.textContent = 'Token looks wrong — should start with ghp_ or github_pat_';
    gistStatus.className = 'status err';
    return;
  }
  const data = {
    githubToken: token,
    gistId,
    defaultLanguage: lang,
    gistAutoSaveMs:  delay,
    googleKeys,
    googleModels: selectedModels.google,
    googleModel: selectedModels.google[0] || '',
    googleKey: googleKeys[0] || '',
    geminiKey: googleKeys[0] || '',
  };

  chrome.storage.local.set(data, () => {
    gistStatus.textContent = 'Settings saved. Reload the NZOI page to apply AI provider changes.';
    gistStatus.className = 'status ok';
    setTimeout(() => { gistStatus.className = 'status'; }, 2500);
    updateAiStatus({ google:googleKeys.length > 0 });
  });
});

// ── Test Gist ─────────────────────────────────────────────────────────────────

document.getElementById('test-gist').addEventListener('click', () => {
  const token  = document.getElementById('github-token').value.trim();
  const status = document.getElementById('gist-status');
  if (!token) { status.textContent = 'Enter a token first.'; status.className = 'status err'; return; }
  status.textContent = 'Testing…'; status.className = 'status info';
  chrome.runtime.sendMessage({ type: 'gist:test', token }, res => {
    if (res?.ok) {
      const d = res.data;
      status.textContent = `Connected as ${d.login}${d.gistId ? ` — ${d.fileCount} files in Gist` : ' — no Gist linked yet'}`;
      status.className = 'status ok';
    } else {
      status.textContent = 'Failed: ' + (res?.error || 'unknown error');
      status.className = 'status err';
    }
  });
});

// ── Browse Gists ──────────────────────────────────────────────────────────────

document.getElementById('browse-gists').addEventListener('click', () => {
  const token  = document.getElementById('github-token').value.trim();
  const status = document.getElementById('gist-status');
  if (!token) { status.textContent = 'Enter a token first.'; status.className = 'status err'; return; }
  status.textContent = 'Fetching your gists…'; status.className = 'status info';

  chrome.runtime.sendMessage({ type: 'gist:list', token }, res => {
    status.className = 'status';
    if (!res?.ok) {
      status.textContent = 'Failed: ' + (res?.error || 'unknown');
      status.className = 'status err';
      return;
    }
    const picker = document.getElementById('gist-picker');
    const sel    = document.getElementById('gist-list');
    const gists  = res.data;
    if (!gists.length) {
      status.textContent = 'No gists found on this account.';
      status.className = 'status info';
      return;
    }
    sel.innerHTML = gists.map(g => {
      const date = new Date(g.updatedAt).toLocaleDateString();
      return `<option value="${g.id}">[${date}] ${g.description} (${g.fileCount} files: ${g.files})</option>`;
    }).join('');
    picker.style.display = 'block';
  });
});

document.getElementById('use-gist').addEventListener('click', () => {
  const id = document.getElementById('gist-list').value;
  if (!id) return;
  document.getElementById('gist-id').value = id;
  document.getElementById('gist-picker').style.display = 'none';
  const s = document.getElementById('gist-status');
  s.textContent = 'Gist linked — click Save All Settings to confirm.';
  s.className = 'status info';
});

// ── Data management ───────────────────────────────────────────────────────────

function savePrompt(textareaId, storageKey, required) {
  const val = document.getElementById(textareaId).value;
  const s = document.getElementById('prompt-status');
  const missing = required.filter(ph => !val.includes(ph));
  if (missing.length) {
    s.textContent = 'Prompt missing required placeholder(s): ' + missing.join(', ');
    s.className = 'status err';
    return;
  }
  chrome.storage.local.set({ [storageKey]: val }, () => {
    s.textContent = 'Prompt saved.';
    s.className = 'status ok';
    setTimeout(() => { s.className = 'status'; }, 2500);
  });
}

function resetPrompt(textareaId, storageKey, defaultValue) {
  document.getElementById(textareaId).value = defaultValue;
  chrome.storage.local.remove(storageKey, () => {
    const s = document.getElementById('prompt-status');
    s.textContent = 'Prompt reset to default.';
    s.className = 'status ok';
    setTimeout(() => { s.className = 'status'; }, 2500);
  });
}

document.getElementById('save-classifier-prompt').addEventListener('click', () => {
  savePrompt('classifier-prompt-template', 'classifierPromptTemplate', ['{{TEXT}}', '{{TAGS}}', '{{PREVIOUS}}']);
});
document.getElementById('reset-classifier-prompt').addEventListener('click', () => {
  resetPrompt('classifier-prompt-template', 'classifierPromptTemplate', DEFAULT_CLASSIFIER_PROMPT_TEMPLATE);
});
const LOCAL_CLEANUP_CATEGORIES = [
  'classificationCache', 'classifierWork', 'backgroundWork', 'questionArchiveQueue', 'editorRecovery',
  'pdfCache', 'bestAnswerMetadata', 'gistCache',
];
let storageInspection = null;
let storageInspectionRun = 0;

function showDataStatus(message, kind='info') {
  const status = document.getElementById('data-status');
  status.textContent = message;
  status.className = `status ${kind}`;
}

function sendStorageMessage(message, callback) {
  chrome.runtime.sendMessage(message, response => {
    const runtimeError = chrome.runtime.lastError?.message;
    if (runtimeError) callback(new Error(runtimeError));
    else if (!response?.ok) callback(new Error(response?.error || 'The extension did not return a result.'));
    else callback(null, response);
  });
}

function renderGistRecordList(elementId, records, emptyText, kind) {
  const list = document.getElementById(elementId);
  list.replaceChildren();
  if (!records.length) {
    const empty = document.createElement('span');
    empty.className = 'gist-empty';
    empty.textContent = emptyText;
    list.appendChild(empty);
    return;
  }
  records.forEach(record => {
    const row = document.createElement('label');
    row.className = 'cleanup-row';
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.dataset.gistRecordKind = kind;
    input.value = String(record.id);
    const title = document.createElement('span');
    title.className = 'cleanup-label';
    title.textContent = String(record.title || `Record ${record.id}`);
    title.title = title.textContent;
    const id = document.createElement('span');
    id.className = 'cleanup-count';
    id.textContent = String(record.id);
    row.append(input, title, id);
    list.appendChild(row);
  });
}

function renderLocalInspection(local) {
  LOCAL_CLEANUP_CATEGORIES.forEach(category => {
    const count = Number(local[category]) || 0;
    const target = document.querySelector(`[data-local-count="${category}"]`);
    if (target) target.textContent = `${count} item${count === 1 ? '' : 's'}`;
    const checkbox = document.querySelector(`[data-local-category="${category}"]`);
    if (checkbox) checkbox.disabled = count === 0;
  });
}

function renderGistInspection(gist) {
  const classifications = Array.isArray(gist.classifications) ? gist.classifications : [];
  const questions = Array.isArray(gist.questions) ? gist.questions : [];
  const protectedFiles = Array.isArray(gist.protectedAnswerFiles) ? gist.protectedAnswerFiles : [];
  document.getElementById('gist-classification-count').textContent = gist.error ? 'unavailable' : `${classifications.length} record${classifications.length === 1 ? '' : 's'}`;
  document.getElementById('gist-question-count').textContent = gist.error ? 'unavailable' : `${questions.length} record${questions.length === 1 ? '' : 's'}`;
  renderGistRecordList('gist-classifications-list', classifications, gist.error || 'No classification records found.', 'classification');
  renderGistRecordList('gist-questions-list', questions, gist.error || 'No question statements found.', 'question');
  const protectedTarget = document.getElementById('gist-protected-files');
  protectedTarget.replaceChildren();
  if (gist.error) {
    protectedTarget.textContent = 'Could not inspect protected files while Gist access is unavailable.';
  } else if (!protectedFiles.length) {
    protectedTarget.textContent = 'No answer/code files found.';
  } else {
    protectedFiles.forEach(filename => {
      const line = document.createElement('div');
      line.textContent = String(filename);
      protectedTarget.appendChild(line);
    });
  }
}

function renderInspectionStatus() {
  if (!storageInspection) return;
  const { local, gist, errors } = storageInspection;
  const localDone = !!local || !!errors.local;
  const gistDone = !!gist || !!errors.gist;
  if (errors.local && errors.gist) {
    showDataStatus(`Local inspection failed: ${errors.local} Gist inspection failed: ${errors.gist}`, 'err');
  } else if (errors.local) {
    showDataStatus(gistDone
      ? `Gist details refreshed. Local inspection failed: ${errors.local}`
      : `Gist details are loading. Local inspection failed: ${errors.local}`, 'err');
  } else if (errors.gist) {
    showDataStatus(localDone
      ? `Local counts refreshed. Gist inspection failed: ${errors.gist}`
      : `Local counts are loading. Gist inspection failed: ${errors.gist}`, 'err');
  } else if (!localDone || !gistDone) {
    showDataStatus(localDone ? 'Local counts refreshed. Loading Gist details…'
      : gistDone ? 'Gist details loaded. Refreshing local counts…'
        : 'Refreshing local counts and linked Gist details…');
  } else {
    showDataStatus('Local counts and Gist records refreshed. Select only the records you want to remove.', 'ok');
  }
}

function inspectStorage() {
  const run = ++storageInspectionRun;
  storageInspection = { local:null, gist:null, errors:{local:'',gist:''}, run };
  LOCAL_CLEANUP_CATEGORIES.forEach(category => {
    const target = document.querySelector(`[data-local-count="${category}"]`);
    if (target) target.textContent = 'Loading…';
    const checkbox = document.querySelector(`[data-local-category="${category}"]`);
    if (checkbox) checkbox.disabled = true;
  });
  document.getElementById('gist-classification-count').textContent = 'Loading…';
  document.getElementById('gist-question-count').textContent = 'Loading…';
  renderGistRecordList('gist-classifications-list', [], 'Loading Gist records…', 'classification');
  renderGistRecordList('gist-questions-list', [], 'Loading Gist records…', 'question');
  document.getElementById('gist-protected-files').textContent = 'Loading Gist files…';
  showDataStatus('Refreshing local counts and linked Gist details…');

  // Local totals resolve independently from GitHub, so cleanup remains usable
  // even when Gist access is slow or rate-limited.
  sendStorageMessage({ type:'storage:inspectLocal' }, (error, response) => {
    if (run !== storageInspectionRun) return;
    const data = !error ? (response.data || response) : null;
    const local = data && (data.local || data);
    if (error || !local) {
      storageInspection.errors.local = error?.message || 'The local storage count response was empty.';
      LOCAL_CLEANUP_CATEGORIES.forEach(category => {
        const target = document.querySelector(`[data-local-count="${category}"]`);
        if (target) target.textContent = 'unavailable';
      });
    } else {
      storageInspection.local = local;
      renderLocalInspection(local);
    }
    renderInspectionStatus();
  });

  sendStorageMessage({ type:'storage:inspectGist' }, (error, response) => {
    if (run !== storageInspectionRun) return;
    const data = !error ? (response.data || response) : null;
    const gist = data && (data.gist || data);
    if (error || !gist) {
      storageInspection.errors.gist = error?.message || 'The Gist inspection response was empty.';
      storageInspection.gist = { classifications:[], questions:[], protectedAnswerFiles:[], error:storageInspection.errors.gist };
    } else {
      storageInspection.gist = gist;
      if (gist.error) storageInspection.errors.gist = String(gist.error);
    }
    renderGistInspection(storageInspection.gist);
    renderInspectionStatus();
  });
}

document.getElementById('refresh-storage').addEventListener('click', inspectStorage);

document.getElementById('clear-selected-local').addEventListener('click', () => {
  if (!storageInspection?.local) {
    showDataStatus('Refresh storage counts before clearing data.', 'err');
    return;
  }
  const categories = [...document.querySelectorAll('[data-local-category]:checked')]
    .map(input => input.dataset.localCategory)
    .filter(category => LOCAL_CLEANUP_CATEGORIES.includes(category));
  if (!categories.length) {
    showDataStatus('Select at least one local data category to clear.', 'err');
    return;
  }
  const counts = storageInspection.local || {};
  const summary = categories.map(category => `${category}: ${Number(counts[category]) || 0}`).join('\n');
  if (!confirm(`Remove the selected local data categories?\n\n${summary}\n\nCredentials and settings are excluded.`)) return;
  showDataStatus('Removing selected local data…');
  sendStorageMessage({ type:'storage:clearLocal', categories }, (error, response) => {
    if (error) {
      showDataStatus(`Could not clear local data: ${error.message}`, 'err');
      return;
    }
    const removed = response.removed || response.data?.removed || {};
    const summaryText = categories.map(category => `${Number(removed[category]) || 0} ${category}`).join(', ');
    document.querySelectorAll('[data-local-category]:checked').forEach(input => { input.checked = false; });
    showDataStatus(`Removed selected local data (${summaryText}).`, 'ok');
    inspectStorage();
  });
});

function clearSelectedGistRecords(kind) {
  if (!storageInspection?.gist || storageInspection.gist.error) {
    showDataStatus('Refresh Gist details successfully before deleting records.', 'err');
    return;
  }
  const selector = `[data-gist-record-kind="${kind}"]:checked`;
  const ids = [...document.querySelectorAll(selector)].map(input => input.value).filter(Boolean);
  const label = kind === 'classification' ? 'classification records' : 'question statements';
  if (!ids.length) {
    showDataStatus(`Select at least one ${label} to clear.`, 'err');
    return;
  }
  const preview = ids.slice(0, 8).join(', ') + (ids.length > 8 ? `, and ${ids.length - 8} more` : '');
  const pendingNote = kind === 'question'
    ? '\n\nMatching pending local archive entries will also be removed so they are not uploaded again.'
    : '';
  if (!confirm(`Delete ${ids.length} selected ${label} from the linked Gist?\n\nIDs: ${preview}\n\nSaved answer and code files will be preserved.${pendingNote}`)) return;
  showDataStatus(`Deleting ${ids.length} ${label} from Gist…`);
  const type = kind === 'classification' ? 'gist:deleteClassificationRecords' : 'gist:deleteQuestionRecords';
  sendStorageMessage({ type, ids }, (error, response) => {
    if (error) {
      showDataStatus(`Could not delete Gist records: ${error.message}`, 'err');
      return;
    }
    const deleted = Number(response.deleted ?? response.data?.deleted) || 0;
    showDataStatus(`Deleted ${deleted} selected ${label}. Answer and code files remain protected.`, 'ok');
    inspectStorage();
  });
}

document.getElementById('clear-selected-classifications').addEventListener('click', () => clearSelectedGistRecords('classification'));
document.getElementById('clear-selected-questions').addEventListener('click', () => clearSelectedGistRecords('question'));

inspectStorage();
